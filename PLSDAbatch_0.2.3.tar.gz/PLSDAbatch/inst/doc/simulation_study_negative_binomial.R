## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(dpi = 300, echo = TRUE, warning = FALSE, message = FALSE, 
                      eval = TRUE, fig.show = TRUE, fig.width = 6, 
                      fig.height = 5, fig.align ='center', 
                      out.width = '70%', cache = FALSE)

## -----------------------------------------------------------------------------
library(PLSDAbatch)
library(mixOmics)
library(sva) #ComBat
library(limma) #removeBatchEffect
library(vegan) #RDA
library(pROC) #roc

## ---- eval = F----------------------------------------------------------------
#  nitr <- 50
#  N = 40
#  p_total = 300
#  p_trt_relevant = 100
#  p_bat_relevant = 200
#  
#  # global variance (RDA)
#  gvar.before <- gvar.clean <-
#    gvar.rbe <- gvar.combat <-
#    gvar.plsdab <- gvar.splsdab <- data.frame(treatment = NA, batch = NA,
#                                              intersection = NA,
#                                              residual = NA)
#  
#  # individual variance (R2)
#  r2.trt.before <- r2.trt.clean <-
#    r2.trt.rbe  <- r2.trt.combat <-
#    r2.trt.plsdab <- r2.trt.splsdab <- data.frame(matrix(NA, nrow = p_total,
#                                                         ncol = nitr))
#  r2.batch.before <- r2.batch.clean <-
#    r2.batch.rbe  <- r2.batch.combat <-
#    r2.batch.plsdab <- r2.batch.splsdab <- data.frame(matrix(NA, nrow = p_total,
#                                                             ncol = nitr))
#  
#  # precision & recall & F1 (ANOVA)
#  precision_limma <- recall_limma <- F1_limma <-
#    data.frame(before = NA, clean = NA,
#               rbe = NA, combat = NA,
#               plsda_batch = NA, splsda_batch = NA,
#               sva = NA)
#  
#  # auc (splsda)
#  auc_splsda <-
#    data.frame(before = NA, clean = NA,
#               rbe = NA, combat = NA,
#               plsda_batch = NA, splsda_batch = NA)
#  
#  
#  set.seed(70)
#  data.cor.res = corStruct(p = 300, zero_prob = 0.7)
#  
#  for(i in 1: nitr){
#    ### initial setup ###
#    simulation <- simData_mnegbinom(batch.group = 2,
#                                    mean.batch = 7,
#                                    sd.batch = 8,
#                                    mean.trt = 3,
#                                    sd.trt = 2,
#                                    mean.bg = 0,
#                                    sd.bg = 0.2,
#                                    N = 40,
#                                    p_total = 300,
#                                    p_trt_relevant = 100,
#                                    p_bat_relevant = 200,
#                                    percentage_overlap_samples = 0.5,
#                                    percentage_overlap_variables = 0.5,
#                                    data.cor = data.cor.res$data.cor,
#                                    disp = 10, prob_zero = 0,
#                                    seeds = i)
#  
#    set.seed(i)
#    raw_count <- simulation$data
#    raw_count_clean <- simulation$cleanData
#  
#    ## log transformation
#    data_log <- log(raw_count + 1)
#    data_log_clean <- log(raw_count_clean + 1)
#  
#    trt <- simulation$Y.trt
#    batch <- simulation$Y.bat
#  
#    true.trt <- simulation$true.trt
#    true.batch <- simulation$true.batch
#  
#    Batch_Trt.factors <- data.frame(Batch = batch, Treatment = trt)
#  
#    ### Original ###
#    X <- data_log
#  
#    ### Clean data ###
#    X.clean <- data_log_clean
#  
#    #####
#    rownames(X) = rownames(X.clean) = names(trt) = names(batch) =
#      paste0('sample', 1:N)
#  
#    colnames(X) = colnames(X.clean) = paste0('otu', 1:p_total)
#  
#    ### Before correction ###
#    # global variance (RDA)
#    rda.before = varpart(scale(X), ~ Treatment, ~ Batch,
#                         data = Batch_Trt.factors)
#    gvar.before[i,] <- rda.before$part$indfract$Adj.R.squared
#  
#    # precision & recall & F1 (ANOVA)
#    fit.before <- lmFit(t(scale(X)), design = model.matrix(~ as.factor(trt)))
#    fit.result.before <- topTable(eBayes(fit.before), coef = 2, number = p_total)
#    otu.sig.before <-
#      rownames(fit.result.before)[fit.result.before$adj.P.Val <= 0.05]
#  
#    precision_limma.before <-
#      length(intersect(colnames(X)[true.trt], otu.sig.before))/
#      length(otu.sig.before)
#    recall_limma.before <-
#      length(intersect(colnames(X)[true.trt], otu.sig.before))/length(true.trt)
#    F1_limma.before <-
#      (2*precision_limma.before*recall_limma.before)/
#      (precision_limma.before + recall_limma.before)
#  
#    ## replace NA value with 0
#    if(precision_limma.before == 'NaN'){
#      precision_limma.before = 0
#    }
#    if(F1_limma.before == 'NaN'){
#      F1_limma.before = 0
#    }
#  
#    # individual variance (R2)
#    indiv.trt.before <- c()
#    indiv.batch.before <- c()
#    for(c in seq_len(ncol(X))){
#      fit.res1 <- lm(scale(X)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.before <- c(indiv.trt.before, fit.summary1$r.squared)
#      indiv.batch.before <- c(indiv.batch.before, fit.summary2$r.squared)
#    }
#    r2.trt.before[ ,i] <-  indiv.trt.before
#    r2.batch.before[ ,i] <-  indiv.batch.before
#  
#  
#    # auc (sPLSDA)
#    fit.before_plsda <- splsda(X = X, Y = trt, ncomp = 1)
#  
#    true.response <- rep(0, p_total)
#    true.response[true.trt] = 1
#    before.predictor <- as.numeric(abs(fit.before_plsda$loadings$X))
#    roc.before_splsda <- roc(true.response, before.predictor, auc = TRUE)
#    auc.before_splsda <- roc.before_splsda$auc
#  
#  
#    ##############################################################################
#    ### Ground-truth data ###
#    # global variance (RDA)
#    rda.clean = varpart(scale(X.clean), ~ Treatment, ~ Batch,
#                        data = Batch_Trt.factors)
#    gvar.clean[i, ] <- rda.clean$part$indfract$Adj.R.squared
#  
#  
#    # precision & recall & F1 (ANOVA)
#    fit.clean <- lmFit(t(scale(X.clean)), design = model.matrix(~ as.factor(trt)))
#    fit.result.clean <- topTable(eBayes(fit.clean), coef = 2, number = p_total)
#    otu.sig.clean <-
#      rownames(fit.result.clean)[fit.result.clean$adj.P.Val <= 0.05]
#  
#    precision_limma.clean<-
#      length(intersect(colnames(X)[true.trt], otu.sig.clean))/
#      length(otu.sig.clean)
#    recall_limma.clean<-
#      length(intersect(colnames(X)[true.trt], otu.sig.clean))/
#      length(true.trt)
#    F1_limma.clean <-
#      (2*precision_limma.clean*recall_limma.clean)/
#      (precision_limma.clean + recall_limma.clean)
#  
#    ## replace NA value with 0
#    if(precision_limma.clean == 'NaN'){
#      precision_limma.clean = 0
#    }
#    if(F1_limma.clean == 'NaN'){
#      F1_limma.clean = 0
#    }
#  
#    # individual variance (R2)
#    indiv.trt.clean <- c()
#    indiv.batch.clean <- c()
#    for(c in seq_len(ncol(X.clean))){
#      fit.res1 <- lm(scale(X.clean)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X.clean)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.clean <- c(indiv.trt.clean, fit.summary1$r.squared)
#      indiv.batch.clean <- c(indiv.batch.clean, fit.summary2$r.squared)
#    }
#    r2.trt.clean[ ,i] <-  indiv.trt.clean
#    r2.batch.clean[ ,i] <-  indiv.batch.clean
#  
#    # auc (sPLSDA)
#    fit.clean_plsda <- splsda(X = X.clean, Y = trt, ncomp = 1)
#  
#    clean.predictor <- as.numeric(abs(fit.clean_plsda$loadings$X))
#    roc.clean_splsda <- roc(true.response, clean.predictor, auc = TRUE)
#    auc.clean_splsda <- roc.clean_splsda$auc
#  
#    ##############################################################################
#    ### removeBatchEffect corrected data ###
#    X.rbe <-t(removeBatchEffect(t(X), batch = batch,
#                                design = model.matrix(~ as.factor(trt))))
#  
#    # global variance (RDA)
#    rda.rbe = varpart(scale(X.rbe), ~ Treatment, ~ Batch,
#                      data = Batch_Trt.factors)
#    gvar.rbe[i, ] <- rda.rbe$part$indfract$Adj.R.squared
#  
#    # precision & recall & F1 (ANOVA)
#    fit.rbe <- lmFit(t(scale(X.rbe)),
#                     design = model.matrix( ~ as.factor(trt)))
#    fit.result.rbe <- topTable(eBayes(fit.rbe), coef = 2, number = p_total)
#    otu.sig.rbe <- rownames(fit.result.rbe)[fit.result.rbe$adj.P.Val <= 0.05]
#  
#    precision_limma.rbe <- length(intersect(colnames(X)[true.trt], otu.sig.rbe))/
#      length(otu.sig.rbe)
#    recall_limma.rbe <- length(intersect(colnames(X)[true.trt], otu.sig.rbe))/
#      length(true.trt)
#    F1_limma.rbe <- (2*precision_limma.rbe*recall_limma.rbe)/
#      (precision_limma.rbe + recall_limma.rbe)
#  
#    ## replace NA value with 0
#    if(precision_limma.rbe == 'NaN'){
#      precision_limma.rbe = 0
#    }
#    if(F1_limma.rbe == 'NaN'){
#      F1_limma.rbe = 0
#    }
#  
#    # individual variance (R2)
#    indiv.trt.rbe <- c()
#    indiv.batch.rbe <- c()
#    for(c in seq_len(ncol(X.rbe))){
#      fit.res1 <- lm(scale(X.rbe)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X.rbe)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.rbe <- c(indiv.trt.rbe, fit.summary1$r.squared)
#      indiv.batch.rbe <- c(indiv.batch.rbe, fit.summary2$r.squared)
#    }
#    r2.trt.rbe[ ,i] <-  indiv.trt.rbe
#    r2.batch.rbe[ ,i] <-  indiv.batch.rbe
#  
#  
#    # auc (sPLSDA)
#    fit.rbe_plsda <- splsda(X = X.rbe, Y = trt, ncomp = 1)
#  
#    rbe.predictor <- as.numeric(abs(fit.rbe_plsda$loadings$X))
#    roc.rbe_splsda <- roc(true.response, rbe.predictor, auc = TRUE)
#    auc.rbe_splsda <- roc.rbe_splsda$auc
#  
#    ##############################################################################
#    ### ComBat corrected data ###
#    X.combat <- t(ComBat(dat = t(X), batch = batch,
#                         mod = model.matrix( ~ as.factor(trt))))
#  
#    # global variance (RDA)
#    rda.combat = varpart(scale(X.combat), ~ Treatment, ~ Batch,
#                         data = Batch_Trt.factors)
#    gvar.combat[i, ] <- rda.combat$part$indfract$Adj.R.squared
#  
#    # precision & recall & F1 (ANOVA)
#    fit.combat <- lmFit(t(scale(X.combat)),
#                        design = model.matrix( ~ as.factor(trt)))
#    fit.result.combat <- topTable(eBayes(fit.combat), coef = 2, number = p_total)
#    otu.sig.combat <- rownames(fit.result.combat)[fit.result.combat$adj.P.Val <=
#                                                    0.05]
#  
#    precision_limma.combat <-
#      length(intersect(colnames(X)[true.trt], otu.sig.combat))/
#      length(otu.sig.combat)
#    recall_limma.combat <-
#      length(intersect(colnames(X)[true.trt], otu.sig.combat))/
#      length(true.trt)
#    F1_limma.combat <- (2*precision_limma.combat*recall_limma.combat)/
#      (precision_limma.combat + recall_limma.combat)
#  
#    ## replace NA value with 0
#    if(precision_limma.combat == 'NaN'){
#      precision_limma.combat = 0
#    }
#    if(F1_limma.combat == 'NaN'){
#      F1_limma.combat = 0
#    }
#  
#    # individual variance (R2)
#    indiv.trt.combat <- c()
#    indiv.batch.combat <- c()
#    for(c in seq_len(ncol(X.combat))){
#      fit.res1 <- lm(scale(X.combat)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X.combat)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.combat <- c(indiv.trt.combat, fit.summary1$r.squared)
#      indiv.batch.combat <- c(indiv.batch.combat, fit.summary2$r.squared)
#    }
#    r2.trt.combat[ ,i] <-  indiv.trt.combat
#    r2.batch.combat[ ,i] <-  indiv.batch.combat
#  
#  
#    # auc (sPLSDA)
#    fit.combat_plsda <- splsda(X = X.combat, Y = trt, ncomp = 1)
#  
#    combat.predictor <- as.numeric(abs(fit.combat_plsda$loadings$X))
#    roc.combat_splsda <- roc(true.response, combat.predictor, auc = TRUE)
#    auc.combat_splsda <- roc.combat_splsda$auc
#  
#  
#    ##############################################################################
#    ### PLSDA-batch corrected data ###
#    X.plsda_batch.correct <- PLSDA_batch(X = X,
#                                         Y.trt = trt, Y.bat = batch,
#                                         ncomp.trt = 1, ncomp.bat = 1)
#    X.plsda_batch <- X.plsda_batch.correct$X.nobatch
#  
#    # global variance (RDA)
#    rda.plsda_batch = varpart(scale(X.plsda_batch), ~ Treatment, ~ Batch,
#                              data = Batch_Trt.factors)
#    gvar.plsdab[i, ] <- rda.plsda_batch$part$indfract$Adj.R.squared
#  
#    # precision & recall & F1 (ANOVA)
#    fit.plsda_batch <- lmFit(t(scale(X.plsda_batch)),
#                             design = model.matrix( ~ as.factor(trt)))
#    fit.result.plsda_batch <- topTable(eBayes(fit.plsda_batch),
#                                       coef = 2, number = p_total)
#    otu.sig.plsda_batch <- rownames(fit.result.plsda_batch)[
#      fit.result.plsda_batch$adj.P.Val <= 0.05]
#  
#    precision_limma.plsda_batch <-
#      length(intersect(colnames(X)[true.trt], otu.sig.plsda_batch))/
#      length(otu.sig.plsda_batch)
#    recall_limma.plsda_batch <-
#      length(intersect(colnames(X)[true.trt], otu.sig.plsda_batch))/
#      length(true.trt)
#    F1_limma.plsda_batch <-
#      (2*precision_limma.plsda_batch*recall_limma.plsda_batch)/
#      (precision_limma.plsda_batch + recall_limma.plsda_batch)
#  
#    ## replace NA value with 0
#    if(precision_limma.plsda_batch == 'NaN'){
#      precision_limma.plsda_batch = 0
#    }
#    if(F1_limma.plsda_batch == 'NaN'){
#      F1_limma.plsda_batch = 0
#    }
#  
#    # individual variance (R2)
#    indiv.trt.plsda_batch <- c()
#    indiv.batch.plsda_batch <- c()
#    for(c in seq_len(ncol(X.plsda_batch))){
#      fit.res1 <- lm(scale(X.plsda_batch)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X.plsda_batch)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.plsda_batch <- c(indiv.trt.plsda_batch,
#                                 fit.summary1$r.squared)
#      indiv.batch.plsda_batch <- c(indiv.batch.plsda_batch,
#                                   fit.summary2$r.squared)
#    }
#    r2.trt.plsdab[ ,i] <-  indiv.trt.plsda_batch
#    r2.batch.plsdab[ ,i] <-  indiv.batch.plsda_batch
#  
#    # auc (sPLSDA)
#    fit.plsda_batch_plsda <- splsda(X = X.plsda_batch, Y = trt, ncomp = 1)
#  
#    plsda_batch.predictor <- as.numeric(abs(fit.plsda_batch_plsda$loadings$X))
#    roc.plsda_batch_splsda <- roc(true.response,
#                                  plsda_batch.predictor, auc = TRUE)
#    auc.plsda_batch_splsda <- roc.plsda_batch_splsda$auc
#  
#    ##############################################################################
#    ### sPLSDA-batch corrected data ###
#    X.splsda_batch.correct <- PLSDA_batch(X = X,
#                                          Y.trt = trt,
#                                          Y.bat = batch,
#                                          ncomp.trt = 1,
#                                          keepX.trt = length(true.trt),
#                                          ncomp.bat = 1)
#    X.splsda_batch <- X.splsda_batch.correct$X.nobatch
#  
#    # global variance (RDA)
#    rda.splsda_batch = varpart(scale(X.splsda_batch), ~ Treatment, ~ Batch,
#                               data = Batch_Trt.factors)
#    gvar.splsdab[i, ] <- rda.splsda_batch$part$indfract$Adj.R.squared
#  
#    # precision & recall & F1 (ANOVA)
#    fit.splsda_batch <- lmFit(t(scale(X.splsda_batch)),
#                              design = model.matrix( ~ as.factor(trt)))
#    fit.result.splsda_batch <- topTable(eBayes(fit.splsda_batch), coef = 2,
#                                        number = p_total)
#    otu.sig.splsda_batch <- rownames(fit.result.splsda_batch)[
#      fit.result.splsda_batch$adj.P.Val <= 0.05]
#  
#    precision_limma.splsda_batch <-
#      length(intersect(colnames(X)[true.trt], otu.sig.splsda_batch))/
#      length(otu.sig.splsda_batch)
#    recall_limma.splsda_batch <-
#      length(intersect(colnames(X)[true.trt], otu.sig.splsda_batch))/
#      length(true.trt)
#    F1_limma.splsda_batch <-
#      (2*precision_limma.splsda_batch*recall_limma.splsda_batch)/
#      (precision_limma.splsda_batch + recall_limma.splsda_batch)
#  
#    ## replace NA value with 0
#    if(precision_limma.splsda_batch == 'NaN'){
#      precision_limma.splsda_batch = 0
#    }
#    if(F1_limma.splsda_batch == 'NaN'){
#      F1_limma.splsda_batch = 0
#    }
#  
#  
#    # individual variance (R2)
#    indiv.trt.splsda_batch <- c()
#    indiv.batch.splsda_batch <- c()
#    for(c in seq_len(ncol(X.splsda_batch))){
#      fit.res1 <- lm(scale(X.splsda_batch)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X.splsda_batch)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.splsda_batch <- c(indiv.trt.splsda_batch,
#                                  fit.summary1$r.squared)
#      indiv.batch.splsda_batch <- c(indiv.batch.splsda_batch,
#                                    fit.summary2$r.squared)
#    }
#    r2.trt.splsdab[ ,i] <-  indiv.trt.splsda_batch
#    r2.batch.splsdab[ ,i] <-  indiv.batch.splsda_batch
#  
#    # auc (sPLSDA)
#    fit.splsda_batch_plsda <- splsda(X = X.splsda_batch, Y = trt, ncomp = 1)
#  
#    splsda_batch.predictor <- as.numeric(abs(fit.splsda_batch_plsda$loadings$X))
#    roc.splsda_batch_splsda <- roc(true.response,
#                                   splsda_batch.predictor, auc = TRUE)
#    auc.splsda_batch_splsda <- roc.splsda_batch_splsda$auc
#  
#    ##############################################################################
#    ### SVA ###
#    X.mod <- model.matrix(~ as.factor(trt))
#    X.mod0 <- model.matrix(~ 1, data = as.factor(trt))
#    X.sva.n <- num.sv(dat = t(X), mod = X.mod, method = 'leek')
#    X.sva <- sva(t(X), X.mod, X.mod0, n.sv = X.sva.n)
#  
#    X.mod.batch <- cbind(X.mod, X.sva$sv)
#    X.mod0.batch <- cbind(X.mod0, X.sva$sv)
#    X.sva.p <- f.pvalue(t(X), X.mod.batch, X.mod0.batch)
#    X.sva.p.adj <- p.adjust(X.sva.p, method = 'fdr')
#  
#    otu.sig.sva <- which(X.sva.p.adj <= 0.05)
#  
#    # precision & recall & F1 (ANOVA)
#    precision_limma.sva <-
#      length(intersect(true.trt, otu.sig.sva))/length(otu.sig.sva)
#    recall_limma.sva <-
#      length(intersect(true.trt, otu.sig.sva))/length(true.trt)
#    F1_limma.sva <-
#      (2*precision_limma.sva*recall_limma.sva)/
#      (precision_limma.sva + recall_limma.sva)
#  
#    ## replace NA value with 0
#    if(precision_limma.sva == 'NaN'){
#      precision_limma.sva = 0
#    }
#    if(F1_limma.sva == 'NaN'){
#      F1_limma.sva = 0
#    }
#  
#  
#    # summary
#    # precision & recall & F1 (ANOVA)
#    precision_limma[i, ] <- c(`Before correction` = precision_limma.before,
#                              `Ground-truth data` = precision_limma.clean,
#                              `removeBatchEffect` = precision_limma.rbe,
#                              ComBat = precision_limma.combat,
#                              `PLSDA-batch` = precision_limma.plsda_batch,
#                              `sPLSDA-batch` = precision_limma.splsda_batch,
#                              SVA = precision_limma.sva)
#  
#    recall_limma[i, ] <- c(`Before correction` = recall_limma.before,
#                           `Ground-truth data` = recall_limma.clean,
#                           `removeBatchEffect` = recall_limma.rbe,
#                           ComBat = recall_limma.combat,
#                           `PLSDA-batch` = recall_limma.plsda_batch,
#                           `sPLSDA-batch` = recall_limma.splsda_batch,
#                           SVA = recall_limma.sva)
#  
#    F1_limma[i, ] <- c(`Before correction` = F1_limma.before,
#                       `Ground-truth data` = F1_limma.clean,
#                       `removeBatchEffect` = F1_limma.rbe,
#                       ComBat = F1_limma.combat,
#                       `PLSDA-batch` = F1_limma.plsda_batch,
#                       `sPLSDA-batch` = F1_limma.splsda_batch,
#                       SVA = F1_limma.sva)
#  
#    # auc (splsda)
#    auc_splsda[i, ] <- c(`Before correction` = auc.before_splsda,
#                         `Ground-truth data` = auc.clean_splsda,
#                         `removeBatchEffect` = auc.rbe_splsda,
#                         ComBat = auc.combat_splsda,
#                         `PLSDA-batch` = auc.plsda_batch_splsda,
#                         `sPLSDA-batch` = auc.splsda_batch_splsda)
#  
#    # print(i)
#  
#  }
#  

## ---- echo = F----------------------------------------------------------------
# save(gvar.before, gvar.clean, gvar.rbe, gvar.combat, gvar.plsdab, gvar.splsdab, nitr, p_total, p_trt_relevant, p_bat_relevant, true.trt, true.batch, r2.trt.before, r2.batch.before, r2.trt.clean, r2.batch.clean, r2.trt.rbe, r2.batch.rbe, r2.trt.combat, r2.batch.combat, r2.trt.plsdab, r2.batch.plsdab, r2.trt.splsdab, r2.batch.splsdab, precision_limma, recall_limma, F1_limma, auc_splsda, file = './SimulationData/balanced_mnegbinom_2batches.rda')

# As the simulation step takes time, so we use the saved data into visulisation.
load(file = './SimulationData/balanced_mnegbinom_2batches.rda')

## ---- fig.cap = 'Figure 1: Simulation studies (two batch groups): comparison of explained variance before and after batch effect correction for the balanced batch × treatment design.'----
# global variance (RDA)
prop.gvar.all <- rbind(`Before correction` = colMeans(gvar.before),
                       `Ground-truth data` = colMeans(gvar.clean),
                       removeBatchEffect = colMeans(gvar.rbe),
                       ComBat = colMeans(gvar.combat),
                       `PLSDA-batch` = colMeans(gvar.plsdab),
                       `sPLSDA-batch` = colMeans(gvar.splsdab))

prop.gvar.all[prop.gvar.all < 0] = 0
prop.gvar.all <- t(apply(prop.gvar.all, 1, function(x){x/sum(x)}))
colnames(prop.gvar.all) <- c('Treatment', 'Intersection', 'Batch', 'Residuals')

partVar_plot(prop.df = prop.gvar.all)


## ---- fig.width = 14, fig.height = 12, out.width = '100%', fig.cap = 'Figure 2: Simulation studies (two batch groups): R2 values for each microbial variable before and after batch effect correction for the balanced batch × treatment design.'----
################################################################################
# individual variance (R2)
## boxplot
# class
gclass <- c(rep('Treatment only', p_trt_relevant), 
            rep('Batch only', (p_total - p_trt_relevant)))
gclass[intersect(true.trt, true.batch)] = 'Treatment & batch'
gclass[setdiff(1:p_total, union(true.trt, true.batch))] = 'No effect'

gclass <- factor(gclass, levels = c('Treatment & batch', 
                                    'Treatment only', 
                                    'Batch only', 
                                    'No effect'))

before.r2.df.ggp <- data.frame(r2 = c(rowMeans(r2.trt.before), 
                                      rowMeans(r2.batch.before)), 
                               type = as.factor(rep(c('Treatment','Batch'), 
                                                    each = 300)),
                               class = rep(gclass,2))
clean.r2.df.ggp <- data.frame(r2 = c(rowMeans(r2.trt.clean), 
                                     rowMeans(r2.batch.clean)), 
                              type = as.factor(rep(c('Treatment','Batch'), 
                                                   each = 300)),
                              class = rep(gclass,2))
rbe.r2.df.ggp <- data.frame(r2 = c(rowMeans(r2.trt.rbe), 
                                   rowMeans(r2.batch.rbe)), 
                            type = as.factor(rep(c('Treatment','Batch'), 
                                                 each = 300)),
                            class = rep(gclass,2))
combat.r2.df.ggp <- data.frame(r2 = c(rowMeans(r2.trt.combat), 
                                      rowMeans(r2.batch.combat)), 
                               type = as.factor(rep(c('Treatment','Batch'), 
                                                    each = 300)),
                               class = rep(gclass,2))
plsda_batch.r2.df.ggp <- data.frame(r2 = c(rowMeans(r2.trt.plsdab), 
                                           rowMeans(r2.batch.plsdab)), 
                                    type = as.factor(rep(c('Treatment','Batch'), 
                                                         each = 300)),
                                    class = rep(gclass,2))
splsda_batch.r2.df.ggp <- 
  data.frame(r2 = c(rowMeans(r2.trt.splsdab), 
                    rowMeans(r2.batch.splsdab)), 
             type = as.factor(rep(c('Treatment','Batch'), 
                                  each = 300)),
             class = rep(gclass,2))

all.r2.df.ggp <- rbind(before.r2.df.ggp, clean.r2.df.ggp,
                       rbe.r2.df.ggp, combat.r2.df.ggp,
                       plsda_batch.r2.df.ggp, splsda_batch.r2.df.ggp)

all.r2.df.ggp$methods <- rep(c('Before correction', 
                               'Ground-truth data', 
                               'removeBatchEffect', 
                               'ComBat',
                               'PLSDA-batch', 
                               'sPLSDA-batch'), each = 600)

all.r2.df.ggp$methods <- factor(all.r2.df.ggp$methods, 
                                levels = unique(all.r2.df.ggp$methods))

ggplot(all.r2.df.ggp, aes(x = type, y = r2, fill = class)) +
  geom_boxplot(alpha = 0.80) +
  theme_bw() + 
  theme(text = element_text(size = 18),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        panel.grid.minor.x = element_blank(),
        panel.grid.major.x = element_blank(),
        legend.position = "right") + facet_grid(class ~ methods) + 
  scale_fill_manual(values=c('dark gray', color.mixo(4), 
                             color.mixo(5), color.mixo(9)))

## ---- fig.width = 14, fig.height = 12, out.width = '100%', fig.cap = 'Figure 3: Simulation studies (two batch groups): the sum of R2 values for each microbial variable before and after batch effect correction for the balanced batch × treatment design.'----
################################################################################
## barplot
# class
before.r2.df.bp <- 
  data.frame(r2 = c(tapply(rowMeans(r2.trt.before), gclass, sum), 
                    tapply(rowMeans(r2.batch.before), gclass, sum)), 
             type = as.factor(rep(c('Treatment','Batch'), each = 4)),
             class = factor(rep(levels(gclass),2), levels = levels(gclass)))

clean.r2.df.bp <- 
  data.frame(r2 = c(tapply(rowMeans(r2.trt.clean), gclass, sum), 
                    tapply(rowMeans(r2.batch.clean), gclass, sum)), 
             type = as.factor(rep(c('Treatment','Batch'), each = 4)),
             class = factor(rep(levels(gclass),2), levels = levels(gclass)))

rbe.r2.df.bp <- 
  data.frame(r2 = c(tapply(rowMeans(r2.trt.rbe), gclass, sum), 
                    tapply(rowMeans(r2.batch.rbe), gclass, sum)), 
             type = as.factor(rep(c('Treatment','Batch'), each = 4)),
             class = factor(rep(levels(gclass),2), levels = levels(gclass)))

combat.r2.df.bp <- 
  data.frame(r2 = c(tapply(rowMeans(r2.trt.combat), gclass, sum), 
                    tapply(rowMeans(r2.batch.combat), gclass, sum)), 
             type = as.factor(rep(c('Treatment','Batch'), each = 4)),
             class = factor(rep(levels(gclass),2), levels = levels(gclass)))

plsda_batch.r2.df.bp <- 
  data.frame(r2 = c(tapply(rowMeans(r2.trt.plsdab), gclass, sum), 
                    tapply(rowMeans(r2.batch.plsdab), gclass, sum)), 
             type = as.factor(rep(c('Treatment','Batch'), each = 4)),
             class = factor(rep(levels(gclass),2), levels = levels(gclass)))

splsda_batch.r2.df.bp <- 
  data.frame(r2 = c(tapply(rowMeans(r2.trt.splsdab), gclass, sum), 
                    tapply(rowMeans(r2.batch.splsdab), gclass, sum)), 
             type = as.factor(rep(c('Treatment','Batch'), each = 4)),
             class = factor(rep(levels(gclass),2), levels = levels(gclass)))


all.r2.df.bp <- rbind(before.r2.df.bp, clean.r2.df.bp,
                      rbe.r2.df.bp, combat.r2.df.bp,
                      plsda_batch.r2.df.bp, splsda_batch.r2.df.bp)


all.r2.df.bp$methods <- rep(c('Before correction', 
                              'Ground-truth data', 
                              'removeBatchEffect', 'ComBat',
                              'PLSDA-batch', 'sPLSDA-batch'), each = 8)

all.r2.df.bp$methods <- factor(all.r2.df.bp$methods, 
                               levels = unique(all.r2.df.bp$methods))

ggplot(all.r2.df.bp, aes(x = type, y = r2, fill = class)) +
  geom_bar(stat="identity") + 
  theme_bw() + 
  theme(text = element_text(size = 18),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        panel.grid.minor.x = element_blank(),
        panel.grid.major.x = element_blank(),
        legend.position = "right") + facet_grid(class ~ methods) + 
  scale_fill_manual(values=c('dark gray', color.mixo(4), 
                             color.mixo(5), color.mixo(9)))


## -----------------------------------------------------------------------------
# precision & recall & F1 (ANOVA & sPLSDA)
## mean
acc_mean <- rbind(colMeans(precision_limma), colMeans(recall_limma), 
                  colMeans(F1_limma), c(colMeans(auc_splsda), sva = NA))
rownames(acc_mean) <- c('Precision', 'Recall', 'F1', 'AUC')
colnames(acc_mean) <- c('Before correction', 'Ground-truth data', 
                        'removeBatchEffect', 'ComBat', 
                        'PLSDA-batch', 'sPLSDA-batch', 'SVA')
acc_mean <- format(acc_mean, digits = 3)
knitr::kable(acc_mean, caption = 'Table 3: Simulation studies (two batch groups): summary of accuracy measurements before and after batch effect correction for the balanced batch × treatment design (mean).')

## -----------------------------------------------------------------------------
## sd
acc_sd <- rbind(apply(precision_limma, 2, sd), apply(recall_limma, 2, sd), 
                apply(F1_limma, 2, sd), c(apply(auc_splsda, 2, sd), NA))
rownames(acc_sd) <- c('Precision', 'Recall', 'F1', 'AUC')
colnames(acc_sd) <- c('Before correction', 'Ground-truth data', 
                      'removeBatchEffect', 'ComBat', 
                      'PLSDA-batch', 'sPLSDA-batch', 'SVA')
acc_sd <- format(acc_sd, digits = 1)
knitr::kable(acc_sd, caption = 'Table 4: Simulation studies (two batch groups): summary of accuracy measurements before and after batch effect correction for the balanced batch × treatment design (standard deviation).')

## ---- eval = F----------------------------------------------------------------
#  nitr <- 50
#  N = 40
#  p_total = 300
#  p_trt_relevant = 100
#  p_bat_relevant = 200
#  
#  # global variance (RDA)
#  gvar.before <- gvar.clean <-
#    gvar.rbe <- gvar.combat <-
#    gvar.wplsdab <- gvar.swplsdab <-
#    gvar.plsdab <- gvar.splsdab <- data.frame(treatment = NA, batch = NA,
#                                              intersection = NA,
#                                              residual = NA)
#  
#  # individual variance (R2)
#  r2.trt.before <- r2.trt.clean <-
#    r2.trt.rbe  <- r2.trt.combat <-
#    r2.trt.wplsdab <- r2.trt.swplsdab <-
#    r2.trt.plsdab <- r2.trt.splsdab <- data.frame(matrix(NA, nrow = p_total,
#                                                         ncol = nitr))
#  r2.batch.before <- r2.batch.clean <-
#    r2.batch.rbe  <- r2.batch.combat <-
#    r2.batch.wplsdab <- r2.batch.swplsdab <-
#    r2.batch.plsdab <- r2.batch.splsdab <- data.frame(matrix(NA, nrow = p_total,
#                                                             ncol = nitr))
#  
#  # precision & recall & F1 (ANOVA)
#  precision_limma <- recall_limma <- F1_limma <-
#    data.frame(before = NA, clean = NA,
#               rbe = NA, combat = NA,
#               wplsda_batch = NA, swplsda_batch = NA,
#               sva = NA)
#  
#  # auc (splsda)
#  auc_splsda <-
#    data.frame(before = NA, clean = NA,
#               rbe = NA, combat = NA,
#               wplsda_batch = NA, swplsda_batch = NA)
#  
#  
#  set.seed(70)
#  data.cor.res = corStruct(p = 300, zero_prob = 0.7)
#  
#  for(i in 1: nitr){
#    ### initial setup ###
#    simulation <- simData_mnegbinom(batch.group = 2,
#                                    mean.batch = 7,
#                                    sd.batch = 8,
#                                    mean.trt = 3,
#                                    sd.trt = 2,
#                                    mean.bg = 0,
#                                    sd.bg = 0.2,
#                                    N = 40,
#                                    p_total = 300,
#                                    p_trt_relevant = 100,
#                                    p_bat_relevant = 200,
#                                    percentage_overlap_samples = 0.2,
#                                    percentage_overlap_variables = 0.5,
#                                    data.cor = data.cor.res$data.cor,
#                                    disp = 10, prob_zero = 0,
#                                    seeds = i)
#  
#    set.seed(i)
#    raw_count <- simulation$data
#    raw_count_clean <- simulation$cleanData
#  
#    ## log transformation
#    data_log <- log(raw_count + 1)
#    data_log_clean <- log(raw_count_clean + 1)
#  
#    trt <- simulation$Y.trt
#    batch <- simulation$Y.bat
#  
#    true.trt <- simulation$true.trt
#    true.batch <- simulation$true.batch
#  
#    Batch_Trt.factors <- data.frame(Batch = batch, Treatment = trt)
#  
#    ### Original ###
#    X <- data_log
#  
#    ### Clean data ###
#    X.clean <- data_log_clean
#  
#    #####
#    rownames(X) = rownames(X.clean) = names(trt) = names(batch) =
#      paste0('sample', 1:N)
#  
#    colnames(X) = colnames(X.clean) = paste0('otu', 1:p_total)
#  
#    ### Before correction ###
#    # global variance (RDA)
#    rda.before = varpart(scale(X), ~ Treatment, ~ Batch,
#                         data = Batch_Trt.factors)
#    gvar.before[i,] <- rda.before$part$indfract$Adj.R.squared
#  
#    # precision & recall & F1 (ANOVA)
#    fit.before <- lmFit(t(scale(X)), design = model.matrix(~ as.factor(trt)))
#    fit.result.before <- topTable(eBayes(fit.before), coef = 2, number = p_total)
#    otu.sig.before <-
#      rownames(fit.result.before)[fit.result.before$adj.P.Val <= 0.05]
#  
#    precision_limma.before <-
#      length(intersect(colnames(X)[true.trt], otu.sig.before))/
#      length(otu.sig.before)
#    recall_limma.before <-
#      length(intersect(colnames(X)[true.trt], otu.sig.before))/
#      length(true.trt)
#    F1_limma.before <-
#      (2*precision_limma.before*recall_limma.before)/
#      (precision_limma.before + recall_limma.before)
#  
#    ## replace NA value with 0
#    if(precision_limma.before == 'NaN'){
#      precision_limma.before = 0
#    }
#    if(F1_limma.before == 'NaN'){
#      F1_limma.before = 0
#    }
#  
#    # individual variance (R2)
#    indiv.trt.before <- c()
#    indiv.batch.before <- c()
#    for(c in seq_len(ncol(X))){
#      fit.res1 <- lm(scale(X)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.before <- c(indiv.trt.before, fit.summary1$r.squared)
#      indiv.batch.before <- c(indiv.batch.before, fit.summary2$r.squared)
#    }
#    r2.trt.before[ ,i] <-  indiv.trt.before
#    r2.batch.before[ ,i] <-  indiv.batch.before
#  
#  
#    # auc (sPLSDA)
#    fit.before_plsda <- splsda(X = X, Y = trt, ncomp = 1)
#  
#    true.response <- rep(0, p_total)
#    true.response[true.trt] = 1
#    before.predictor <- as.numeric(abs(fit.before_plsda$loadings$X))
#    roc.before_splsda <- roc(true.response, before.predictor, auc = TRUE)
#    auc.before_splsda <- roc.before_splsda$auc
#  
#  
#    ##############################################################################
#    ### Ground-truth data ###
#    # global variance (RDA)
#    rda.clean = varpart(scale(X.clean), ~ Treatment, ~ Batch,
#                        data = Batch_Trt.factors)
#    gvar.clean[i, ] <- rda.clean$part$indfract$Adj.R.squared
#  
#  
#    # precision & recall & F1 (ANOVA)
#    fit.clean <- lmFit(t(scale(X.clean)), design = model.matrix(~ as.factor(trt)))
#    fit.result.clean <- topTable(eBayes(fit.clean), coef = 2, number = p_total)
#    otu.sig.clean <-
#      rownames(fit.result.clean)[fit.result.clean$adj.P.Val <= 0.05]
#  
#    precision_limma.clean <-
#      length(intersect(colnames(X)[true.trt], otu.sig.clean))/
#      length(otu.sig.clean)
#    recall_limma.clean <-
#      length(intersect(colnames(X)[true.trt], otu.sig.clean))/length(true.trt)
#    F1_limma.clean <-
#      (2*precision_limma.clean*recall_limma.clean)/
#      (precision_limma.clean + recall_limma.clean)
#  
#    ## replace NA value with 0
#    if(precision_limma.clean == 'NaN'){
#      precision_limma.clean = 0
#    }
#    if(F1_limma.clean == 'NaN'){
#      F1_limma.clean = 0
#    }
#  
#    # individual variance (R2)
#    indiv.trt.clean <- c()
#    indiv.batch.clean <- c()
#    for(c in seq_len(ncol(X.clean))){
#      fit.res1 <- lm(scale(X.clean)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X.clean)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.clean <- c(indiv.trt.clean, fit.summary1$r.squared)
#      indiv.batch.clean <- c(indiv.batch.clean, fit.summary2$r.squared)
#    }
#    r2.trt.clean[ ,i] <-  indiv.trt.clean
#    r2.batch.clean[ ,i] <-  indiv.batch.clean
#  
#    # auc (sPLSDA)
#    fit.clean_plsda <- splsda(X = X.clean, Y = trt, ncomp = 1)
#  
#    clean.predictor <- as.numeric(abs(fit.clean_plsda$loadings$X))
#    roc.clean_splsda <- roc(true.response, clean.predictor, auc = TRUE)
#    auc.clean_splsda <- roc.clean_splsda$auc
#  
#    ##############################################################################
#    ### removeBatchEffect corrected data ###
#    X.rbe <-t(removeBatchEffect(t(X), batch = batch,
#                                design = model.matrix(~ as.factor(trt))))
#  
#    # global variance (RDA)
#    rda.rbe = varpart(scale(X.rbe), ~ Treatment, ~ Batch,
#                      data = Batch_Trt.factors)
#    gvar.rbe[i, ] <- rda.rbe$part$indfract$Adj.R.squared
#  
#    # precision & recall & F1 (ANOVA)
#    fit.rbe <- lmFit(t(scale(X.rbe)),
#                     design = model.matrix( ~ as.factor(trt)))
#    fit.result.rbe <- topTable(eBayes(fit.rbe), coef = 2, number = p_total)
#    otu.sig.rbe <- rownames(fit.result.rbe)[fit.result.rbe$adj.P.Val <= 0.05]
#  
#    precision_limma.rbe <- length(intersect(colnames(X)[true.trt], otu.sig.rbe))/
#      length(otu.sig.rbe)
#    recall_limma.rbe <- length(intersect(colnames(X)[true.trt], otu.sig.rbe))/
#      length(true.trt)
#    F1_limma.rbe <- (2*precision_limma.rbe*recall_limma.rbe)/
#      (precision_limma.rbe + recall_limma.rbe)
#  
#    ## replace NA value with 0
#    if(precision_limma.rbe == 'NaN'){
#      precision_limma.rbe = 0
#    }
#    if(F1_limma.rbe == 'NaN'){
#      F1_limma.rbe = 0
#    }
#  
#    # individual variance (R2)
#    indiv.trt.rbe <- c()
#    indiv.batch.rbe <- c()
#    for(c in seq_len(ncol(X.rbe))){
#      fit.res1 <- lm(scale(X.rbe)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X.rbe)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.rbe <- c(indiv.trt.rbe, fit.summary1$r.squared)
#      indiv.batch.rbe <- c(indiv.batch.rbe, fit.summary2$r.squared)
#    }
#    r2.trt.rbe[ ,i] <-  indiv.trt.rbe
#    r2.batch.rbe[ ,i] <-  indiv.batch.rbe
#  
#  
#    # auc (sPLSDA)
#    fit.rbe_plsda <- splsda(X = X.rbe, Y = trt, ncomp = 1)
#  
#    rbe.predictor <- as.numeric(abs(fit.rbe_plsda$loadings$X))
#    roc.rbe_splsda <- roc(true.response, rbe.predictor, auc = TRUE)
#    auc.rbe_splsda <- roc.rbe_splsda$auc
#  
#    ##############################################################################
#    ### ComBat corrected data ###
#    X.combat <- t(ComBat(dat = t(X), batch = batch,
#                         mod = model.matrix( ~ as.factor(trt))))
#  
#    # global variance (RDA)
#    rda.combat = varpart(scale(X.combat), ~ Treatment, ~ Batch,
#                         data = Batch_Trt.factors)
#    gvar.combat[i, ] <- rda.combat$part$indfract$Adj.R.squared
#  
#    # precision & recall & F1 (ANOVA)
#    fit.combat <- lmFit(t(scale(X.combat)),
#                        design = model.matrix( ~ as.factor(trt)))
#    fit.result.combat <- topTable(eBayes(fit.combat), coef = 2, number = p_total)
#    otu.sig.combat <-
#      rownames(fit.result.combat)[fit.result.combat$adj.P.Val <= 0.05]
#  
#    precision_limma.combat <-
#      length(intersect(colnames(X)[true.trt], otu.sig.combat))/
#      length(otu.sig.combat)
#    recall_limma.combat <-
#      length(intersect(colnames(X)[true.trt], otu.sig.combat))/
#      length(true.trt)
#    F1_limma.combat <- (2*precision_limma.combat*recall_limma.combat)/
#      (precision_limma.combat + recall_limma.combat)
#  
#    ## replace NA value with 0
#    if(precision_limma.combat == 'NaN'){
#      precision_limma.combat = 0
#    }
#    if(F1_limma.combat == 'NaN'){
#      F1_limma.combat = 0
#    }
#  
#    # individual variance (R2)
#    indiv.trt.combat <- c()
#    indiv.batch.combat <- c()
#    for(c in seq_len(ncol(X.combat))){
#      fit.res1 <- lm(scale(X.combat)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X.combat)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.combat <- c(indiv.trt.combat, fit.summary1$r.squared)
#      indiv.batch.combat <- c(indiv.batch.combat, fit.summary2$r.squared)
#    }
#    r2.trt.combat[ ,i] <-  indiv.trt.combat
#    r2.batch.combat[ ,i] <-  indiv.batch.combat
#  
#  
#    # auc (sPLSDA)
#    fit.combat_plsda <- splsda(X = X.combat, Y = trt, ncomp = 1)
#  
#    combat.predictor <- as.numeric(abs(fit.combat_plsda$loadings$X))
#    roc.combat_splsda <- roc(true.response, combat.predictor, auc = TRUE)
#    auc.combat_splsda <- roc.combat_splsda$auc
#  
#  
#    ##############################################################################
#    ### wPLSDA-batch corrected data ###
#    X.wplsda_batch.correct <- PLSDA_batch(X = X,
#                                          Y.trt = trt, Y.bat = batch,
#                                          ncomp.trt = 1, ncomp.bat = 1,
#                                          balance = FALSE)
#    X.wplsda_batch <- X.wplsda_batch.correct$X.nobatch
#  
#    # global variance (RDA)
#    rda.wplsda_batch = varpart(scale(X.wplsda_batch), ~ Treatment, ~ Batch,
#                               data = Batch_Trt.factors)
#    gvar.wplsdab[i, ] <- rda.wplsda_batch$part$indfract$Adj.R.squared
#  
#    # precision & recall & F1 (ANOVA)
#    fit.wplsda_batch <- lmFit(t(scale(X.wplsda_batch)),
#                              design = model.matrix( ~ as.factor(trt)))
#    fit.result.wplsda_batch <- topTable(eBayes(fit.wplsda_batch),
#                                        coef = 2, number = p_total)
#    otu.sig.wplsda_batch <- rownames(fit.result.wplsda_batch)[
#      fit.result.wplsda_batch$adj.P.Val <= 0.05]
#  
#    precision_limma.wplsda_batch <-
#      length(intersect(colnames(X)[true.trt], otu.sig.wplsda_batch))/
#      length(otu.sig.wplsda_batch)
#    recall_limma.wplsda_batch <-
#      length(intersect(colnames(X)[true.trt], otu.sig.wplsda_batch))/
#      length(true.trt)
#    F1_limma.wplsda_batch <-
#      (2*precision_limma.wplsda_batch*recall_limma.wplsda_batch)/
#      (precision_limma.wplsda_batch + recall_limma.wplsda_batch)
#  
#    ## replace NA value with 0
#    if(precision_limma.wplsda_batch == 'NaN'){
#      precision_limma.wplsda_batch = 0
#    }
#    if(F1_limma.wplsda_batch == 'NaN'){
#      F1_limma.wplsda_batch = 0
#    }
#  
#    # individual variance (R2)
#    indiv.trt.wplsda_batch <- c()
#    indiv.batch.wplsda_batch <- c()
#    for(c in seq_len(ncol(X.wplsda_batch))){
#      fit.res1 <- lm(scale(X.wplsda_batch)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X.wplsda_batch)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.wplsda_batch <- c(indiv.trt.wplsda_batch,
#                                  fit.summary1$r.squared)
#      indiv.batch.wplsda_batch <- c(indiv.batch.wplsda_batch,
#                                    fit.summary2$r.squared)
#    }
#    r2.trt.wplsdab[ ,i] <-  indiv.trt.wplsda_batch
#    r2.batch.wplsdab[ ,i] <-  indiv.batch.wplsda_batch
#  
#    # auc (sPLSDA)
#    fit.wplsda_batch_plsda <- splsda(X = X.wplsda_batch, Y = trt, ncomp = 1)
#  
#    wplsda_batch.predictor <- as.numeric(abs(fit.wplsda_batch_plsda$loadings$X))
#    roc.wplsda_batch_splsda <- roc(true.response,
#                                   wplsda_batch.predictor, auc = TRUE)
#    auc.wplsda_batch_splsda <- roc.wplsda_batch_splsda$auc
#  
#    ##############################################################################
#    ### sPLSDA-batch corrected data ###
#    X.swplsda_batch.correct <- PLSDA_batch(X = X,
#                                           Y.trt = trt,
#                                           Y.bat = batch,
#                                           ncomp.trt = 1,
#                                           keepX.trt = length(true.trt),
#                                           ncomp.bat = 1,
#                                           balance = FALSE)
#    X.swplsda_batch <- X.swplsda_batch.correct$X.nobatch
#  
#    # global variance (RDA)
#    rda.swplsda_batch = varpart(scale(X.swplsda_batch), ~ Treatment, ~ Batch,
#                                data = Batch_Trt.factors)
#    gvar.swplsdab[i, ] <- rda.swplsda_batch$part$indfract$Adj.R.squared
#  
#    # precision & recall & F1 (ANOVA)
#    fit.swplsda_batch <- lmFit(t(scale(X.swplsda_batch)),
#                               design = model.matrix( ~ as.factor(trt)))
#    fit.result.swplsda_batch <- topTable(eBayes(fit.swplsda_batch), coef = 2,
#                                         number = p_total)
#    otu.sig.swplsda_batch <- rownames(fit.result.swplsda_batch)[
#      fit.result.swplsda_batch$adj.P.Val <= 0.05]
#  
#    precision_limma.swplsda_batch <-
#      length(intersect(colnames(X)[true.trt], otu.sig.swplsda_batch))/
#      length(otu.sig.swplsda_batch)
#    recall_limma.swplsda_batch <-
#      length(intersect(colnames(X)[true.trt], otu.sig.swplsda_batch))/
#      length(true.trt)
#    F1_limma.swplsda_batch <-
#      (2*precision_limma.swplsda_batch*recall_limma.swplsda_batch)/
#      (precision_limma.swplsda_batch + recall_limma.swplsda_batch)
#  
#    ## replace NA value with 0
#    if(precision_limma.swplsda_batch == 'NaN'){
#      precision_limma.swplsda_batch = 0
#    }
#    if(F1_limma.swplsda_batch == 'NaN'){
#      F1_limma.swplsda_batch = 0
#    }
#  
#  
#    # individual variance (R2)
#    indiv.trt.swplsda_batch <- c()
#    indiv.batch.swplsda_batch <- c()
#    for(c in seq_len(ncol(X.swplsda_batch))){
#      fit.res1 <- lm(scale(X.swplsda_batch)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X.swplsda_batch)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.swplsda_batch <- c(indiv.trt.swplsda_batch,
#                                   fit.summary1$r.squared)
#      indiv.batch.swplsda_batch <- c(indiv.batch.swplsda_batch,
#                                     fit.summary2$r.squared)
#    }
#    r2.trt.swplsdab[ ,i] <-  indiv.trt.swplsda_batch
#    r2.batch.swplsdab[ ,i] <-  indiv.batch.swplsda_batch
#  
#    # auc (sPLSDA)
#    fit.swplsda_batch_plsda <- splsda(X = X.swplsda_batch, Y = trt, ncomp = 1)
#  
#    swplsda_batch.predictor <- as.numeric(abs(fit.swplsda_batch_plsda$loadings$X))
#    roc.swplsda_batch_splsda <- roc(true.response,
#                                    swplsda_batch.predictor, auc = TRUE)
#    auc.swplsda_batch_splsda <- roc.swplsda_batch_splsda$auc
#  
#    ##############################################################################
#    ### PLSDA-batch corrected data ###
#    X.plsda_batch.correct <- PLSDA_batch(X = X,
#                                         Y.trt = trt, Y.bat = batch,
#                                         ncomp.trt = 1, ncomp.bat = 1)
#    X.plsda_batch <- X.plsda_batch.correct$X.nobatch
#  
#    # global variance (RDA)
#    rda.plsda_batch = varpart(scale(X.plsda_batch), ~ Treatment, ~ Batch,
#                              data = Batch_Trt.factors)
#    gvar.plsdab[i, ] <- rda.plsda_batch$part$indfract$Adj.R.squared
#  
#    # precision & recall & F1 (ANOVA)
#    fit.plsda_batch <- lmFit(t(scale(X.plsda_batch)),
#                             design = model.matrix( ~ as.factor(trt)))
#    fit.result.plsda_batch <- topTable(eBayes(fit.plsda_batch),
#                                       coef = 2, number = p_total)
#    otu.sig.plsda_batch <- rownames(fit.result.plsda_batch)[
#      fit.result.plsda_batch$adj.P.Val <= 0.05]
#  
#    precision_limma.plsda_batch <-
#      length(intersect(colnames(X)[true.trt], otu.sig.plsda_batch))/
#      length(otu.sig.plsda_batch)
#    recall_limma.plsda_batch <-
#      length(intersect(colnames(X)[true.trt], otu.sig.plsda_batch))/
#      length(true.trt)
#    F1_limma.plsda_batch <-
#      (2*precision_limma.plsda_batch*recall_limma.plsda_batch)/
#      (precision_limma.plsda_batch + recall_limma.plsda_batch)
#  
#    ## replace NA value with 0
#    if(precision_limma.plsda_batch == 'NaN'){
#      precision_limma.plsda_batch = 0
#    }
#    if(F1_limma.plsda_batch == 'NaN'){
#      F1_limma.plsda_batch = 0
#    }
#  
#    # individual variance (R2)
#    indiv.trt.plsda_batch <- c()
#    indiv.batch.plsda_batch <- c()
#    for(c in seq_len(ncol(X.plsda_batch))){
#      fit.res1 <- lm(scale(X.plsda_batch)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X.plsda_batch)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.plsda_batch <- c(indiv.trt.plsda_batch,
#                                 fit.summary1$r.squared)
#      indiv.batch.plsda_batch <- c(indiv.batch.plsda_batch,
#                                   fit.summary2$r.squared)
#    }
#    r2.trt.plsdab[ ,i] <-  indiv.trt.plsda_batch
#    r2.batch.plsdab[ ,i] <-  indiv.batch.plsda_batch
#  
#    # auc (sPLSDA)
#    fit.plsda_batch_plsda <- splsda(X = X.plsda_batch, Y = trt, ncomp = 1)
#  
#    plsda_batch.predictor <- as.numeric(abs(fit.plsda_batch_plsda$loadings$X))
#    roc.plsda_batch_splsda <- roc(true.response,
#                                  plsda_batch.predictor, auc = TRUE)
#    auc.plsda_batch_splsda <- roc.plsda_batch_splsda$auc
#  
#    ##############################################################################
#    ### sPLSDA-batch corrected data ###
#    X.splsda_batch.correct <- PLSDA_batch(X = X,
#                                          Y.trt = trt,
#                                          Y.bat = batch,
#                                          ncomp.trt = 1,
#                                          keepX.trt = length(true.trt),
#                                          ncomp.bat = 1)
#    X.splsda_batch <- X.splsda_batch.correct$X.nobatch
#  
#    # global variance (RDA)
#    rda.splsda_batch = varpart(scale(X.splsda_batch), ~ Treatment, ~ Batch,
#                               data = Batch_Trt.factors)
#    gvar.splsdab[i, ] <- rda.splsda_batch$part$indfract$Adj.R.squared
#  
#    # precision & recall & F1 (ANOVA)
#    fit.splsda_batch <- lmFit(t(scale(X.splsda_batch)),
#                              design = model.matrix( ~ as.factor(trt)))
#    fit.result.splsda_batch <- topTable(eBayes(fit.splsda_batch), coef = 2,
#                                        number = p_total)
#    otu.sig.splsda_batch <- rownames(fit.result.splsda_batch)[
#      fit.result.splsda_batch$adj.P.Val <= 0.05]
#  
#    precision_limma.splsda_batch <-
#      length(intersect(colnames(X)[true.trt], otu.sig.splsda_batch))/
#      length(otu.sig.splsda_batch)
#    recall_limma.splsda_batch <-
#      length(intersect(colnames(X)[true.trt], otu.sig.splsda_batch))/
#      length(true.trt)
#    F1_limma.splsda_batch <-
#      (2*precision_limma.splsda_batch*recall_limma.splsda_batch)/
#      (precision_limma.splsda_batch + recall_limma.splsda_batch)
#  
#    ## replace NA value with 0
#    if(precision_limma.splsda_batch == 'NaN'){
#      precision_limma.splsda_batch = 0
#    }
#    if(F1_limma.splsda_batch == 'NaN'){
#      F1_limma.splsda_batch = 0
#    }
#  
#  
#    # individual variance (R2)
#    indiv.trt.splsda_batch <- c()
#    indiv.batch.splsda_batch <- c()
#    for(c in seq_len(ncol(X.splsda_batch))){
#      fit.res1 <- lm(scale(X.splsda_batch)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X.splsda_batch)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.splsda_batch <- c(indiv.trt.splsda_batch,
#                                  fit.summary1$r.squared)
#      indiv.batch.splsda_batch <- c(indiv.batch.splsda_batch,
#                                    fit.summary2$r.squared)
#    }
#    r2.trt.splsdab[ ,i] <-  indiv.trt.splsda_batch
#    r2.batch.splsdab[ ,i] <-  indiv.batch.splsda_batch
#  
#    # auc (sPLSDA)
#    fit.splsda_batch_plsda <- splsda(X = X.splsda_batch, Y = trt, ncomp = 1)
#  
#    splsda_batch.predictor <- as.numeric(abs(fit.splsda_batch_plsda$loadings$X))
#    roc.splsda_batch_splsda <- roc(true.response,
#                                   splsda_batch.predictor, auc = TRUE)
#    auc.splsda_batch_splsda <- roc.splsda_batch_splsda$auc
#  
#    ##############################################################################
#    ### SVA ###
#    X.mod <- model.matrix(~ as.factor(trt))
#    X.mod0 <- model.matrix(~ 1, data = as.factor(trt))
#    X.sva.n <- num.sv(dat = t(X), mod = X.mod, method = 'leek')
#    X.sva <- sva(t(X), X.mod, X.mod0, n.sv = X.sva.n)
#  
#    X.mod.batch <- cbind(X.mod, X.sva$sv)
#    X.mod0.batch <- cbind(X.mod0, X.sva$sv)
#    X.sva.p <- f.pvalue(t(X), X.mod.batch, X.mod0.batch)
#    X.sva.p.adj <- p.adjust(X.sva.p, method = 'fdr')
#  
#    otu.sig.sva <- which(X.sva.p.adj <= 0.05)
#  
#    # precision & recall & F1 (ANOVA)
#    precision_limma.sva <-
#      length(intersect(true.trt, otu.sig.sva))/length(otu.sig.sva)
#    recall_limma.sva <-
#      length(intersect(true.trt, otu.sig.sva))/length(true.trt)
#    F1_limma.sva <-
#      (2*precision_limma.sva*recall_limma.sva)/
#      (precision_limma.sva + recall_limma.sva)
#  
#    ## replace NA value with 0
#    if(precision_limma.sva == 'NaN'){
#      precision_limma.sva = 0
#    }
#    if(F1_limma.sva == 'NaN'){
#      F1_limma.sva = 0
#    }
#  
#  
#    # summary
#    # precision & recall & F1 (ANOVA)
#    precision_limma[i, ] <- c(`Before correction` = precision_limma.before,
#                              `Ground-truth data` = precision_limma.clean,
#                              `removeBatchEffect` = precision_limma.rbe,
#                              ComBat = precision_limma.combat,
#                              `wPLSDA-batch` = precision_limma.wplsda_batch,
#                              `swPLSDA-batch` = precision_limma.swplsda_batch,
#                              SVA = precision_limma.sva)
#  
#    recall_limma[i, ] <- c(`Before correction` = recall_limma.before,
#                           `Ground-truth data` = recall_limma.clean,
#                           `removeBatchEffect` = recall_limma.rbe,
#                           ComBat = recall_limma.combat,
#                           `wPLSDA-batch` = recall_limma.wplsda_batch,
#                           `swPLSDA-batch` = recall_limma.swplsda_batch,
#                           SVA = recall_limma.sva)
#  
#    F1_limma[i, ] <- c(`Before correction` = F1_limma.before,
#                       `Ground-truth data` = F1_limma.clean,
#                       `removeBatchEffect` = F1_limma.rbe,
#                       ComBat = F1_limma.combat,
#                       `wPLSDA-batch` = F1_limma.wplsda_batch,
#                       `swPLSDA-batch` = F1_limma.swplsda_batch,
#                       SVA = F1_limma.sva)
#  
#    # auc (splsda)
#    auc_splsda[i, ] <- c(`Before correction` = auc.before_splsda,
#                         `Ground-truth data` = auc.clean_splsda,
#                         `removeBatchEffect` = auc.rbe_splsda,
#                         ComBat = auc.combat_splsda,
#                         `wPLSDA-batch` = auc.wplsda_batch_splsda,
#                         `swPLSDA-batch` = auc.swplsda_batch_splsda)
#  
#    #print(i)
#  
#  }
#  

## ---- echo = F----------------------------------------------------------------
# save(gvar.before, gvar.clean, gvar.rbe, gvar.combat, gvar.wplsdab, gvar.swplsdab, gvar.plsdab, gvar.splsdab, nitr, p_total, p_trt_relevant, p_bat_relevant, true.trt, true.batch, r2.trt.before, r2.batch.before, r2.trt.clean, r2.batch.clean, r2.trt.rbe, r2.batch.rbe, r2.trt.combat, r2.batch.combat, r2.trt.wplsdab, r2.batch.wplsdab, r2.trt.swplsdab, r2.batch.swplsdab, r2.trt.plsdab, r2.batch.plsdab, r2.trt.splsdab, r2.batch.splsdab, precision_limma, recall_limma, F1_limma, auc_splsda, file = './SimulationData/unbalanced_mnegbinom_2batches.rda')

load(file = './SimulationData/unbalanced_mnegbinom_2batches.rda')

## ---- fig.cap = 'Figure 4: Simulation studies (two batch groups): comparison of explained variance before and after batch effect correction for the unbalanced batch × treatment design.'----
# global variance (RDA)
prop.gvar.all <- rbind(`Before correction` = colMeans(gvar.before),
                       `Ground-truth data` = colMeans(gvar.clean),
                       removeBatchEffect = colMeans(gvar.rbe),
                       ComBat = colMeans(gvar.combat),
                       `wPLSDA-batch` = colMeans(gvar.wplsdab),
                       `swPLSDA-batch` = colMeans(gvar.swplsdab),
                       `PLSDA-batch` = colMeans(gvar.plsdab),
                       `sPLSDA-batch` = colMeans(gvar.splsdab))

prop.gvar.all[prop.gvar.all < 0] = 0
prop.gvar.all <- t(apply(prop.gvar.all, 1, function(x){x/sum(x)}))
colnames(prop.gvar.all) <- c('Treatment', 'Intersection', 'Batch', 'Residuals')

partVar_plot(prop.df = prop.gvar.all)


## ---- fig.width = 14, fig.height = 12, out.width = '100%', fig.cap = 'Figure 5: Simulation studies (two batch groups): R2 values for each microbial variable before and after batch effect correction for the unbalanced batch × treatment design.'----
###############################################################################
# individual variance (R2)
## boxplot
# class
gclass <- c(rep('Treatment only', p_trt_relevant), 
            rep('Batch only', (p_total - p_trt_relevant)))
gclass[intersect(true.trt, true.batch)] = 'Treatment & batch'
gclass[setdiff(1:p_total, union(true.trt, true.batch))] = 'No effect'

gclass <- factor(gclass, levels = c('Treatment & batch', 
                                    'Treatment only', 
                                    'Batch only', 
                                    'No effect'))

before.r2.df.ggp <- data.frame(r2 = c(rowMeans(r2.trt.before), 
                                      rowMeans(r2.batch.before)), 
                               type = as.factor(rep(c('Treatment','Batch'), 
                                                    each = 300)),
                               class = rep(gclass,2))
clean.r2.df.ggp <- data.frame(r2 = c(rowMeans(r2.trt.clean), 
                                     rowMeans(r2.batch.clean)), 
                              type = as.factor(rep(c('Treatment','Batch'), 
                                                   each = 300)),
                              class = rep(gclass,2))
rbe.r2.df.ggp <- data.frame(r2 = c(rowMeans(r2.trt.rbe), 
                                   rowMeans(r2.batch.rbe)), 
                            type = as.factor(rep(c('Treatment','Batch'), 
                                                 each = 300)),
                            class = rep(gclass,2))
combat.r2.df.ggp <- data.frame(r2 = c(rowMeans(r2.trt.combat), 
                                      rowMeans(r2.batch.combat)), 
                               type = as.factor(rep(c('Treatment','Batch'), 
                                                    each = 300)),
                               class = rep(gclass,2))
wplsda_batch.r2.df.ggp <- 
  data.frame(r2 = c(rowMeans(r2.trt.wplsdab), 
                    rowMeans(r2.batch.wplsdab)), 
             type = as.factor(rep(c('Treatment','Batch'), 
                                  each = 300)),
             class = rep(gclass,2))
swplsda_batch.r2.df.ggp <- 
  data.frame(r2 = c(rowMeans(r2.trt.swplsdab), 
                    rowMeans(r2.batch.swplsdab)), 
             type = as.factor(rep(c('Treatment','Batch'),
                                  each = 300)),
             class = rep(gclass,2))

all.r2.df.ggp <- rbind(before.r2.df.ggp, clean.r2.df.ggp,
                       rbe.r2.df.ggp, combat.r2.df.ggp,
                       wplsda_batch.r2.df.ggp, swplsda_batch.r2.df.ggp)

all.r2.df.ggp$methods <- rep(c('Before correction', 
                               'Ground-truth data', 
                               'removeBatchEffect', 
                               'ComBat',
                               'wPLSDA-batch', 
                               'swPLSDA-batch'), each = 600)

all.r2.df.ggp$methods <- factor(all.r2.df.ggp$methods, 
                                levels = unique(all.r2.df.ggp$methods))

ggplot(all.r2.df.ggp, aes(x = type, y = r2, fill = class)) +
  geom_boxplot(alpha = 0.80) +
  theme_bw() + 
  theme(text = element_text(size = 18),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        panel.grid.minor.x = element_blank(),
        panel.grid.major.x = element_blank(),
        legend.position = "right") + facet_grid(class ~ methods) + 
  scale_fill_manual(values=c('dark gray', color.mixo(4), 
                             color.mixo(5), color.mixo(9)))

## ---- fig.width = 14, fig.height = 12, out.width = '100%', fig.cap = 'Figure 6: Simulation studies (two batch groups): the sum of R2 values for each microbial variable before and after batch effect correction for the unbalanced batch × treatment design.'----
################################################################################
## barplot
# class
before.r2.df.bp <- 
  data.frame(r2 = c(tapply(rowMeans(r2.trt.before), gclass, sum), 
                    tapply(rowMeans(r2.batch.before), gclass, sum)), 
             type = as.factor(rep(c('Treatment','Batch'), each = 4)),
             class = factor(rep(levels(gclass),2), levels = levels(gclass)))

clean.r2.df.bp <- 
  data.frame(r2 = c(tapply(rowMeans(r2.trt.clean), gclass, sum), 
                    tapply(rowMeans(r2.batch.clean), gclass, sum)), 
             type = as.factor(rep(c('Treatment','Batch'), each = 4)),
             class = factor(rep(levels(gclass),2), levels = levels(gclass)))

rbe.r2.df.bp <- 
  data.frame(r2 = c(tapply(rowMeans(r2.trt.rbe), gclass, sum), 
                    tapply(rowMeans(r2.batch.rbe), gclass, sum)), 
             type = as.factor(rep(c('Treatment','Batch'), each = 4)),
             class = factor(rep(levels(gclass),2), levels = levels(gclass)))

combat.r2.df.bp <- 
  data.frame(r2 = c(tapply(rowMeans(r2.trt.combat), gclass, sum), 
                    tapply(rowMeans(r2.batch.combat), gclass, sum)), 
             type = as.factor(rep(c('Treatment','Batch'), each = 4)),
             class = factor(rep(levels(gclass),2), levels = levels(gclass)))

wplsda_batch.r2.df.bp <- 
  data.frame(r2 = c(tapply(rowMeans(r2.trt.wplsdab), gclass, sum), 
                    tapply(rowMeans(r2.batch.wplsdab), gclass, sum)), 
             type = as.factor(rep(c('Treatment','Batch'), each = 4)),
             class = factor(rep(levels(gclass),2), levels = levels(gclass)))

swplsda_batch.r2.df.bp <- 
  data.frame(r2 = c(tapply(rowMeans(r2.trt.swplsdab), gclass, sum), 
                    tapply(rowMeans(r2.batch.swplsdab), gclass, sum)), 
             type = as.factor(rep(c('Treatment','Batch'), each = 4)),
             class = factor(rep(levels(gclass),2), levels = levels(gclass)))


all.r2.df.bp <- rbind(before.r2.df.bp, clean.r2.df.bp,
                      rbe.r2.df.bp, combat.r2.df.bp,
                      wplsda_batch.r2.df.bp, swplsda_batch.r2.df.bp)


all.r2.df.bp$methods <- rep(c('Before correction', 
                              'Ground-truth data', 
                              'removeBatchEffect', 
                              'ComBat',
                              'wPLSDA-batch', 
                              'swPLSDA-batch'), each = 8)

all.r2.df.bp$methods <- factor(all.r2.df.bp$methods, 
                               levels = unique(all.r2.df.bp$methods))

ggplot(all.r2.df.bp, aes(x = type, y = r2, fill = class)) +
  geom_bar(stat="identity") + 
  theme_bw() + 
  theme(text = element_text(size = 18),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        panel.grid.minor.x = element_blank(),
        panel.grid.major.x = element_blank(),
        legend.position = "right") + facet_grid(class ~ methods) + 
  scale_fill_manual(values=c('dark gray', color.mixo(4), 
                             color.mixo(5), color.mixo(9)))


## -----------------------------------------------------------------------------
# precision & recall & F1 (ANOVA & sPLSDA)
## mean
acc_mean <- rbind(colMeans(precision_limma), colMeans(recall_limma), 
                  colMeans(F1_limma), c(colMeans(auc_splsda), sva = NA))
rownames(acc_mean) <- c('Precision', 'Recall', 'F1', 'AUC')
colnames(acc_mean) <- c('Before correction', 'Ground-truth data', 
                        'removeBatchEffect', 'ComBat', 
                        'wPLSDA-batch', 'swPLSDA-batch', 'SVA')
acc_mean <- format(acc_mean, digits = 3)
knitr::kable(acc_mean, caption = 'Table 6 Simulation studies (two batch groups): summary of accuracy measurements before and after batch effect correction for the unbalanced batch × treatment design (mean).')

## -----------------------------------------------------------------------------
## sd
acc_sd <- rbind(apply(precision_limma, 2, sd), apply(recall_limma, 2, sd), 
                apply(F1_limma, 2, sd), c(apply(auc_splsda, 2, sd), NA))
rownames(acc_sd) <- c('Precision', 'Recall', 'F1', 'AUC')
colnames(acc_sd) <- c('Before correction', 'Ground-truth data', 
                      'removeBatchEffect', 'ComBat', 
                      'wPLSDA-batch', 'swPLSDA-batch', 'SVA')
acc_sd <- format(acc_sd, digits = 1)
knitr::kable(acc_sd, caption = 'Table 7 Simulation studies (two batch groups): summary of accuracy measurements before and after batch effect correction for the unbalanced batch × treatment design (standard deviation).')

## ---- eval = F----------------------------------------------------------------
#  nitr <- 50
#  N = 36
#  p_total = 300
#  p_trt_relevant = 100
#  p_bat_relevant = 200
#  
#  # global variance (RDA)
#  gvar.before <- gvar.clean <-
#    gvar.rbe <- gvar.combat <-
#    gvar.plsdab <- gvar.splsdab <- data.frame(treatment = NA, batch = NA,
#                                              intersection = NA,
#                                              residual = NA)
#  
#  # individual variance (R2)
#  r2.trt.before <- r2.trt.clean <-
#    r2.trt.rbe  <- r2.trt.combat <-
#    r2.trt.plsdab <- r2.trt.splsdab <- data.frame(matrix(NA, nrow = p_total,
#                                                         ncol = nitr))
#  r2.batch.before <- r2.batch.clean <-
#    r2.batch.rbe  <- r2.batch.combat <-
#    r2.batch.plsdab <- r2.batch.splsdab <- data.frame(matrix(NA, nrow = p_total,
#                                                             ncol = nitr))
#  
#  # precision & recall & F1 (ANOVA)
#  precision_limma <- recall_limma <- F1_limma <-
#    data.frame(before = NA, clean = NA,
#               rbe = NA, combat = NA,
#               plsda_batch = NA, splsda_batch = NA,
#               sva = NA)
#  
#  # auc (splsda)
#  auc_splsda <-
#    data.frame(before = NA, clean = NA,
#               rbe = NA, combat = NA,
#               plsda_batch = NA, splsda_batch = NA)
#  
#  
#  set.seed(70)
#  data.cor.res = corStruct(p = 300, zero_prob = 0.7)
#  
#  for(i in 1: nitr){
#    ### initial setup ###
#    simulation <- simData_mnegbinom(batch.group = 3,
#                                    mean.batch = 7,
#                                    sd.batch = 8,
#                                    mean.trt = 3,
#                                    sd.trt = 2,
#                                    mean.bg = 0,
#                                    sd.bg = 0.2,
#                                    N = 36,
#                                    p_total = 300,
#                                    p_trt_relevant = 100,
#                                    p_bat_relevant = 200,
#                                    percentage_overlap_samples = 0.5,
#                                    percentage_overlap_variables = 0.5,
#                                    data.cor = data.cor.res$data.cor,
#                                    disp = 10, prob_zero = 0,
#                                    seeds = i)
#  
#    set.seed(i)
#    raw_count <- simulation$data
#    raw_count_clean <- simulation$cleanData
#  
#    ## log transformation
#    data_log <- log(raw_count + 1)
#    data_log_clean <- log(raw_count_clean + 1)
#  
#    trt <- simulation$Y.trt
#    batch <- simulation$Y.bat
#  
#    true.trt <- simulation$true.trt
#    true.batch <- simulation$true.batch
#  
#    Batch_Trt.factors <- data.frame(Batch = batch, Treatment = trt)
#  
#    ### Original ###
#    X <- data_log
#  
#    ### Clean data ###
#    X.clean <- data_log_clean
#  
#    #####
#    rownames(X) = rownames(X.clean) = names(trt) = names(batch) =
#      paste0('sample', 1:N)
#  
#    colnames(X) = colnames(X.clean) = paste0('otu', 1:p_total)
#  
#    ### Before correction ###
#    # global variance (RDA)
#    rda.before = varpart(scale(X), ~ Treatment, ~ Batch,
#                         data = Batch_Trt.factors)
#    gvar.before[i,] <- rda.before$part$indfract$Adj.R.squared
#  
#    # precision & recall & F1 (ANOVA)
#    fit.before <- lmFit(t(scale(X)), design = model.matrix(~ as.factor(trt)))
#    fit.result.before <- topTable(eBayes(fit.before), coef = 2, number = p_total)
#    otu.sig.before <-
#      rownames(fit.result.before)[fit.result.before$adj.P.Val <= 0.05]
#  
#    precision_limma.before <-
#      length(intersect(colnames(X)[true.trt], otu.sig.before))/
#      length(otu.sig.before)
#    recall_limma.before <-
#      length(intersect(colnames(X)[true.trt], otu.sig.before))/length(true.trt)
#    F1_limma.before <-
#      (2*precision_limma.before*recall_limma.before)/
#      (precision_limma.before + recall_limma.before)
#  
#    ## replace NA value with 0
#    if(precision_limma.before == 'NaN'){
#      precision_limma.before = 0
#    }
#    if(F1_limma.before == 'NaN'){
#      F1_limma.before = 0
#    }
#  
#    # individual variance (R2)
#    indiv.trt.before <- c()
#    indiv.batch.before <- c()
#    for(c in seq_len(ncol(X))){
#      fit.res1 <- lm(scale(X)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.before <- c(indiv.trt.before, fit.summary1$r.squared)
#      indiv.batch.before <- c(indiv.batch.before, fit.summary2$r.squared)
#    }
#    r2.trt.before[ ,i] <-  indiv.trt.before
#    r2.batch.before[ ,i] <-  indiv.batch.before
#  
#  
#    # auc (sPLSDA)
#    fit.before_plsda <- splsda(X = X, Y = trt, ncomp = 1)
#  
#    true.response <- rep(0, p_total)
#    true.response[true.trt] = 1
#    before.predictor <- as.numeric(abs(fit.before_plsda$loadings$X))
#    roc.before_splsda <- roc(true.response, before.predictor, auc = TRUE)
#    auc.before_splsda <- roc.before_splsda$auc
#  
#  
#    ##############################################################################
#    ### Ground-truth data ###
#    # global variance (RDA)
#    rda.clean = varpart(scale(X.clean), ~ Treatment, ~ Batch,
#                        data = Batch_Trt.factors)
#    gvar.clean[i, ] <- rda.clean$part$indfract$Adj.R.squared
#  
#  
#    # precision & recall & F1 (ANOVA)
#    fit.clean <- lmFit(t(scale(X.clean)), design = model.matrix(~ as.factor(trt)))
#    fit.result.clean <- topTable(eBayes(fit.clean), coef = 2, number = p_total)
#    otu.sig.clean <-
#      rownames(fit.result.clean)[fit.result.clean$adj.P.Val <= 0.05]
#  
#    precision_limma.clean <-
#      length(intersect(colnames(X)[true.trt], otu.sig.clean))/
#      length(otu.sig.clean)
#    recall_limma.clean<-
#      length(intersect(colnames(X)[true.trt], otu.sig.clean))/length(true.trt)
#    F1_limma.clean <-
#      (2*precision_limma.clean*recall_limma.clean)/
#      (precision_limma.clean + recall_limma.clean)
#  
#    ## replace NA value with 0
#    if(precision_limma.clean == 'NaN'){
#      precision_limma.clean = 0
#    }
#    if(F1_limma.clean == 'NaN'){
#      F1_limma.clean = 0
#    }
#  
#    # individual variance (R2)
#    indiv.trt.clean <- c()
#    indiv.batch.clean <- c()
#    for(c in seq_len(ncol(X.clean))){
#      fit.res1 <- lm(scale(X.clean)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X.clean)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.clean <- c(indiv.trt.clean, fit.summary1$r.squared)
#      indiv.batch.clean <- c(indiv.batch.clean, fit.summary2$r.squared)
#    }
#    r2.trt.clean[ ,i] <-  indiv.trt.clean
#    r2.batch.clean[ ,i] <-  indiv.batch.clean
#  
#    # auc (sPLSDA)
#    fit.clean_plsda <- splsda(X = X.clean, Y = trt, ncomp = 1)
#  
#    clean.predictor <- as.numeric(abs(fit.clean_plsda$loadings$X))
#    roc.clean_splsda <- roc(true.response, clean.predictor, auc = TRUE)
#    auc.clean_splsda <- roc.clean_splsda$auc
#  
#    ##############################################################################
#    ### removeBatchEffect corrected data ###
#    X.rbe <-t(removeBatchEffect(t(X), batch = batch,
#                                design = model.matrix(~ as.factor(trt))))
#  
#    # global variance (RDA)
#    rda.rbe = varpart(scale(X.rbe), ~ Treatment, ~ Batch,
#                      data = Batch_Trt.factors)
#    gvar.rbe[i, ] <- rda.rbe$part$indfract$Adj.R.squared
#  
#    # precision & recall & F1 (ANOVA)
#    fit.rbe <- lmFit(t(scale(X.rbe)),
#                     design = model.matrix( ~ as.factor(trt)))
#    fit.result.rbe <- topTable(eBayes(fit.rbe), coef = 2, number = p_total)
#    otu.sig.rbe <- rownames(fit.result.rbe)[fit.result.rbe$adj.P.Val <= 0.05]
#  
#    precision_limma.rbe <- length(intersect(colnames(X)[true.trt], otu.sig.rbe))/
#      length(otu.sig.rbe)
#    recall_limma.rbe <- length(intersect(colnames(X)[true.trt], otu.sig.rbe))/
#      length(true.trt)
#    F1_limma.rbe <- (2*precision_limma.rbe*recall_limma.rbe)/
#      (precision_limma.rbe + recall_limma.rbe)
#  
#    ## replace NA value with 0
#    if(precision_limma.rbe == 'NaN'){
#      precision_limma.rbe = 0
#    }
#    if(F1_limma.rbe == 'NaN'){
#      F1_limma.rbe = 0
#    }
#  
#    # individual variance (R2)
#    indiv.trt.rbe <- c()
#    indiv.batch.rbe <- c()
#    for(c in seq_len(ncol(X.rbe))){
#      fit.res1 <- lm(scale(X.rbe)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X.rbe)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.rbe <- c(indiv.trt.rbe, fit.summary1$r.squared)
#      indiv.batch.rbe <- c(indiv.batch.rbe, fit.summary2$r.squared)
#    }
#    r2.trt.rbe[ ,i] <-  indiv.trt.rbe
#    r2.batch.rbe[ ,i] <-  indiv.batch.rbe
#  
#  
#    # auc (sPLSDA)
#    fit.rbe_plsda <- splsda(X = X.rbe, Y = trt, ncomp = 1)
#  
#    rbe.predictor <- as.numeric(abs(fit.rbe_plsda$loadings$X))
#    roc.rbe_splsda <- roc(true.response, rbe.predictor, auc = TRUE)
#    auc.rbe_splsda <- roc.rbe_splsda$auc
#  
#    ##############################################################################
#    ### ComBat corrected data ###
#    X.combat <- t(ComBat(dat = t(X), batch = batch,
#                         mod = model.matrix( ~ as.factor(trt))))
#  
#    # global variance (RDA)
#    rda.combat = varpart(scale(X.combat), ~ Treatment, ~ Batch,
#                         data = Batch_Trt.factors)
#    gvar.combat[i, ] <- rda.combat$part$indfract$Adj.R.squared
#  
#    # precision & recall & F1 (ANOVA)
#    fit.combat <- lmFit(t(scale(X.combat)),
#                        design = model.matrix( ~ as.factor(trt)))
#    fit.result.combat <- topTable(eBayes(fit.combat), coef = 2, number = p_total)
#    otu.sig.combat <- rownames(fit.result.combat)[fit.result.combat$adj.P.Val <=
#                                                    0.05]
#  
#    precision_limma.combat <-
#      length(intersect(colnames(X)[true.trt], otu.sig.combat))/
#      length(otu.sig.combat)
#    recall_limma.combat <-
#      length(intersect(colnames(X)[true.trt], otu.sig.combat))/
#      length(true.trt)
#    F1_limma.combat <- (2*precision_limma.combat*recall_limma.combat)/
#      (precision_limma.combat + recall_limma.combat)
#  
#    ## replace NA value with 0
#    if(precision_limma.combat == 'NaN'){
#      precision_limma.combat = 0
#    }
#    if(F1_limma.combat == 'NaN'){
#      F1_limma.combat = 0
#    }
#  
#    # individual variance (R2)
#    indiv.trt.combat <- c()
#    indiv.batch.combat <- c()
#    for(c in seq_len(ncol(X.combat))){
#      fit.res1 <- lm(scale(X.combat)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X.combat)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.combat <- c(indiv.trt.combat, fit.summary1$r.squared)
#      indiv.batch.combat <- c(indiv.batch.combat, fit.summary2$r.squared)
#    }
#    r2.trt.combat[ ,i] <-  indiv.trt.combat
#    r2.batch.combat[ ,i] <-  indiv.batch.combat
#  
#  
#    # auc (sPLSDA)
#    fit.combat_plsda <- splsda(X = X.combat, Y = trt, ncomp = 1)
#  
#    combat.predictor <- as.numeric(abs(fit.combat_plsda$loadings$X))
#    roc.combat_splsda <- roc(true.response, combat.predictor, auc = TRUE)
#    auc.combat_splsda <- roc.combat_splsda$auc
#  
#  
#    ##############################################################################
#    ### PLSDA-batch corrected data ###
#    X.plsda_batch.correct <- PLSDA_batch(X = X,
#                                         Y.trt = trt, Y.bat = batch,
#                                         ncomp.trt = 1, ncomp.bat = 2)
#    X.plsda_batch <- X.plsda_batch.correct$X.nobatch
#  
#    # global variance (RDA)
#    rda.plsda_batch = varpart(scale(X.plsda_batch), ~ Treatment, ~ Batch,
#                              data = Batch_Trt.factors)
#    gvar.plsdab[i, ] <- rda.plsda_batch$part$indfract$Adj.R.squared
#  
#    # precision & recall & F1 (ANOVA)
#    fit.plsda_batch <- lmFit(t(scale(X.plsda_batch)),
#                             design = model.matrix( ~ as.factor(trt)))
#    fit.result.plsda_batch <- topTable(eBayes(fit.plsda_batch),
#                                       coef = 2, number = p_total)
#    otu.sig.plsda_batch <- rownames(fit.result.plsda_batch)[
#      fit.result.plsda_batch$adj.P.Val <= 0.05]
#  
#    precision_limma.plsda_batch <-
#      length(intersect(colnames(X)[true.trt], otu.sig.plsda_batch))/
#      length(otu.sig.plsda_batch)
#    recall_limma.plsda_batch <-
#      length(intersect(colnames(X)[true.trt], otu.sig.plsda_batch))/
#      length(true.trt)
#    F1_limma.plsda_batch <-
#      (2*precision_limma.plsda_batch*recall_limma.plsda_batch)/
#      (precision_limma.plsda_batch + recall_limma.plsda_batch)
#  
#    ## replace NA value with 0
#    if(precision_limma.plsda_batch == 'NaN'){
#      precision_limma.plsda_batch = 0
#    }
#    if(F1_limma.plsda_batch == 'NaN'){
#      F1_limma.plsda_batch = 0
#    }
#  
#    # individual variance (R2)
#    indiv.trt.plsda_batch <- c()
#    indiv.batch.plsda_batch <- c()
#    for(c in seq_len(ncol(X.plsda_batch))){
#      fit.res1 <- lm(scale(X.plsda_batch)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X.plsda_batch)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.plsda_batch <- c(indiv.trt.plsda_batch,
#                                 fit.summary1$r.squared)
#      indiv.batch.plsda_batch <- c(indiv.batch.plsda_batch,
#                                   fit.summary2$r.squared)
#    }
#    r2.trt.plsdab[ ,i] <-  indiv.trt.plsda_batch
#    r2.batch.plsdab[ ,i] <-  indiv.batch.plsda_batch
#  
#    # auc (sPLSDA)
#    fit.plsda_batch_plsda <- splsda(X = X.plsda_batch, Y = trt, ncomp = 1)
#  
#    plsda_batch.predictor <- as.numeric(abs(fit.plsda_batch_plsda$loadings$X))
#    roc.plsda_batch_splsda <- roc(true.response,
#                                  plsda_batch.predictor, auc = TRUE)
#    auc.plsda_batch_splsda <- roc.plsda_batch_splsda$auc
#  
#    ##############################################################################
#    ### sPLSDA-batch corrected data ###
#    X.splsda_batch.correct <- PLSDA_batch(X = X,
#                                          Y.trt = trt,
#                                          Y.bat = batch,
#                                          ncomp.trt = 1,
#                                          keepX.trt = length(true.trt),
#                                          ncomp.bat = 2)
#    X.splsda_batch <- X.splsda_batch.correct$X.nobatch
#  
#    # global variance (RDA)
#    rda.splsda_batch = varpart(scale(X.splsda_batch), ~ Treatment, ~ Batch,
#                               data = Batch_Trt.factors)
#    gvar.splsdab[i, ] <- rda.splsda_batch$part$indfract$Adj.R.squared
#  
#    # precision & recall & F1 (ANOVA)
#    fit.splsda_batch <- lmFit(t(scale(X.splsda_batch)),
#                              design = model.matrix( ~ as.factor(trt)))
#    fit.result.splsda_batch <- topTable(eBayes(fit.splsda_batch), coef = 2,
#                                        number = p_total)
#    otu.sig.splsda_batch <- rownames(fit.result.splsda_batch)[
#      fit.result.splsda_batch$adj.P.Val <= 0.05]
#  
#    precision_limma.splsda_batch <-
#      length(intersect(colnames(X)[true.trt], otu.sig.splsda_batch))/
#      length(otu.sig.splsda_batch)
#    recall_limma.splsda_batch <-
#      length(intersect(colnames(X)[true.trt], otu.sig.splsda_batch))/
#      length(true.trt)
#    F1_limma.splsda_batch <-
#      (2*precision_limma.splsda_batch*recall_limma.splsda_batch)/
#      (precision_limma.splsda_batch + recall_limma.splsda_batch)
#  
#    ## replace NA value with 0
#    if(precision_limma.splsda_batch == 'NaN'){
#      precision_limma.splsda_batch = 0
#    }
#    if(F1_limma.splsda_batch == 'NaN'){
#      F1_limma.splsda_batch = 0
#    }
#  
#  
#    # individual variance (R2)
#    indiv.trt.splsda_batch <- c()
#    indiv.batch.splsda_batch <- c()
#    for(c in seq_len(ncol(X.splsda_batch))){
#      fit.res1 <- lm(scale(X.splsda_batch)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X.splsda_batch)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.splsda_batch <- c(indiv.trt.splsda_batch,
#                                  fit.summary1$r.squared)
#      indiv.batch.splsda_batch <- c(indiv.batch.splsda_batch,
#                                    fit.summary2$r.squared)
#    }
#    r2.trt.splsdab[ ,i] <-  indiv.trt.splsda_batch
#    r2.batch.splsdab[ ,i] <-  indiv.batch.splsda_batch
#  
#    # auc (sPLSDA)
#    fit.splsda_batch_plsda <- splsda(X = X.splsda_batch, Y = trt, ncomp = 1)
#  
#    splsda_batch.predictor <- as.numeric(abs(fit.splsda_batch_plsda$loadings$X))
#    roc.splsda_batch_splsda <- roc(true.response,
#                                   splsda_batch.predictor, auc = TRUE)
#    auc.splsda_batch_splsda <- roc.splsda_batch_splsda$auc
#  
#    ##############################################################################
#    ### SVA ###
#    X.mod <- model.matrix(~ as.factor(trt))
#    X.mod0 <- model.matrix(~ 1, data = as.factor(trt))
#    X.sva.n <- num.sv(dat = t(X), mod = X.mod, method = 'leek')
#    X.sva <- sva(t(X), X.mod, X.mod0, n.sv = X.sva.n)
#  
#    X.mod.batch <- cbind(X.mod, X.sva$sv)
#    X.mod0.batch <- cbind(X.mod0, X.sva$sv)
#    X.sva.p <- f.pvalue(t(X), X.mod.batch, X.mod0.batch)
#    X.sva.p.adj <- p.adjust(X.sva.p, method = 'fdr')
#  
#    otu.sig.sva <- which(X.sva.p.adj <= 0.05)
#  
#    # precision & recall & F1 (ANOVA)
#    precision_limma.sva <-
#      length(intersect(true.trt, otu.sig.sva))/length(otu.sig.sva)
#    recall_limma.sva <-
#      length(intersect(true.trt, otu.sig.sva))/length(true.trt)
#    F1_limma.sva <- (2*precision_limma.sva*recall_limma.sva)/
#      (precision_limma.sva + recall_limma.sva)
#  
#    ## replace NA value with 0
#    if(precision_limma.sva == 'NaN'){
#      precision_limma.sva = 0
#    }
#    if(F1_limma.sva == 'NaN'){
#      F1_limma.sva = 0
#    }
#  
#  
#    # summary
#    # precision & recall & F1 (ANOVA)
#    precision_limma[i, ] <- c(`Before correction` = precision_limma.before,
#                              `Ground-truth data` = precision_limma.clean,
#                              `removeBatchEffect` = precision_limma.rbe,
#                              ComBat = precision_limma.combat,
#                              `PLSDA-batch` = precision_limma.plsda_batch,
#                              `sPLSDA-batch` = precision_limma.splsda_batch,
#                              SVA = precision_limma.sva)
#  
#    recall_limma[i, ] <- c(`Before correction` = recall_limma.before,
#                           `Ground-truth data` = recall_limma.clean,
#                           `removeBatchEffect` = recall_limma.rbe,
#                           ComBat = recall_limma.combat,
#                           `PLSDA-batch` = recall_limma.plsda_batch,
#                           `sPLSDA-batch` = recall_limma.splsda_batch,
#                           SVA = recall_limma.sva)
#  
#    F1_limma[i, ] <- c(`Before correction` = F1_limma.before,
#                       `Ground-truth data` = F1_limma.clean,
#                       `removeBatchEffect` = F1_limma.rbe,
#                       ComBat = F1_limma.combat,
#                       `PLSDA-batch` = F1_limma.plsda_batch,
#                       `sPLSDA-batch` = F1_limma.splsda_batch,
#                       SVA = F1_limma.sva)
#  
#    # auc (splsda)
#    auc_splsda[i, ] <- c(`Before correction` = auc.before_splsda,
#                         `Ground-truth data` = auc.clean_splsda,
#                         `removeBatchEffect` = auc.rbe_splsda,
#                         ComBat = auc.combat_splsda,
#                         `PLSDA-batch` = auc.plsda_batch_splsda,
#                         `sPLSDA-batch` = auc.splsda_batch_splsda)
#  
#    # print(i)
#  
#  }
#  

## ---- echo = F----------------------------------------------------------------
# save(gvar.before, gvar.clean, gvar.rbe, gvar.combat, gvar.plsdab, gvar.splsdab, nitr, p_total, p_trt_relevant, p_bat_relevant, true.trt, true.batch, r2.trt.before, r2.batch.before, r2.trt.clean, r2.batch.clean, r2.trt.rbe, r2.batch.rbe, r2.trt.combat, r2.batch.combat, r2.trt.plsdab, r2.batch.plsdab, r2.trt.splsdab, r2.batch.splsdab, precision_limma, recall_limma, F1_limma, auc_splsda, file = './SimulationData/balanced_mnegbinom_3batches.rda')

load(file = './SimulationData/balanced_mnegbinom_3batches.rda')

## ---- fig.cap = 'Figure 7: Simulation studies (three batch groups): comparison of explained variance before and after batch effect correction for the balanced batch × treatment design.'----
# global variance (RDA)
prop.gvar.all <- rbind(`Before correction` = colMeans(gvar.before),
                       `Ground-truth data` = colMeans(gvar.clean),
                       removeBatchEffect = colMeans(gvar.rbe),
                       ComBat = colMeans(gvar.combat),
                       `PLSDA-batch` = colMeans(gvar.plsdab),
                       `sPLSDA-batch` = colMeans(gvar.splsdab))

prop.gvar.all[prop.gvar.all < 0] = 0
prop.gvar.all <- t(apply(prop.gvar.all, 1, function(x){x/sum(x)}))
colnames(prop.gvar.all) <- c('Treatment', 'Intersection', 'Batch', 'Residuals')

partVar_plot(prop.df = prop.gvar.all)


## ---- fig.width = 14, fig.height = 12, out.width = '100%', fig.cap = 'Figure 8: Simulation studies (three batch groups): R2 values for each microbial variable before and after batch effect correction for the balanced batch × treatment design.'----
################################################################################
# individual variance (R2)
## boxplot
# class
gclass <- c(rep('Treatment only', p_trt_relevant), 
            rep('Batch only', (p_total - p_trt_relevant)))
gclass[intersect(true.trt, true.batch)] = 'Treatment & batch'
gclass[setdiff(1:p_total, union(true.trt, true.batch))] = 'No effect'

gclass <- factor(gclass, levels = c('Treatment & batch', 
                                    'Treatment only', 
                                    'Batch only', 
                                    'No effect'))

before.r2.df.ggp <- data.frame(r2 = c(rowMeans(r2.trt.before), 
                                      rowMeans(r2.batch.before)), 
                               type = as.factor(rep(c('Treatment','Batch'), 
                                                    each = 300)),
                               class = rep(gclass,2))
clean.r2.df.ggp <- data.frame(r2 = c(rowMeans(r2.trt.clean), 
                                     rowMeans(r2.batch.clean)), 
                              type = as.factor(rep(c('Treatment','Batch'), 
                                                   each = 300)),
                              class = rep(gclass,2))
rbe.r2.df.ggp <- data.frame(r2 = c(rowMeans(r2.trt.rbe), 
                                   rowMeans(r2.batch.rbe)), 
                            type = as.factor(rep(c('Treatment','Batch'), 
                                                 each = 300)),
                            class = rep(gclass,2))
combat.r2.df.ggp <- data.frame(r2 = c(rowMeans(r2.trt.combat), 
                                      rowMeans(r2.batch.combat)), 
                               type = as.factor(rep(c('Treatment','Batch'), 
                                                    each = 300)),
                               class = rep(gclass,2))
plsda_batch.r2.df.ggp <- 
  data.frame(r2 = c(rowMeans(r2.trt.plsdab), 
                    rowMeans(r2.batch.plsdab)), 
             type = as.factor(rep(c('Treatment','Batch'), 
                                  each = 300)),
             class = rep(gclass,2))
splsda_batch.r2.df.ggp <- 
  data.frame(r2 = c(rowMeans(r2.trt.splsdab), 
                    rowMeans(r2.batch.splsdab)), 
             type = as.factor(rep(c('Treatment','Batch'), 
                                  each = 300)),
             class = rep(gclass,2))

all.r2.df.ggp <- rbind(before.r2.df.ggp, clean.r2.df.ggp,
                       rbe.r2.df.ggp, combat.r2.df.ggp,
                       plsda_batch.r2.df.ggp, splsda_batch.r2.df.ggp)

all.r2.df.ggp$methods <- rep(c('Before correction', 
                               'Ground-truth data', 
                               'removeBatchEffect', 
                               'ComBat',
                               'PLSDA-batch', 
                               'sPLSDA-batch'), each = 600)

all.r2.df.ggp$methods <- factor(all.r2.df.ggp$methods, 
                                levels = unique(all.r2.df.ggp$methods))

ggplot(all.r2.df.ggp, aes(x = type, y = r2, fill = class)) +
  geom_boxplot(alpha = 0.80) +
  theme_bw() + 
  theme(text = element_text(size = 18),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        panel.grid.minor.x = element_blank(),
        panel.grid.major.x = element_blank(),
        legend.position = "right") + facet_grid(class ~ methods) + 
  scale_fill_manual(values=c('dark gray', color.mixo(4), 
                             color.mixo(5), color.mixo(9)))

## ---- fig.width = 14, fig.height = 12, out.width = '100%', fig.cap = 'Figure 9: Simulation studies (three batch groups): the sum of R2 values for each microbial variable before and after batch effect correction for the balanced batch × treatment design.'----
################################################################################
## barplot
# class
before.r2.df.bp <- 
  data.frame(r2 = c(tapply(rowMeans(r2.trt.before), gclass, sum),
                    tapply(rowMeans(r2.batch.before), gclass, sum)), 
             type = as.factor(rep(c('Treatment','Batch'), each = 4)),
             class = factor(rep(levels(gclass),2), levels = levels(gclass)))

clean.r2.df.bp <- 
  data.frame(r2 = c(tapply(rowMeans(r2.trt.clean), gclass, sum),
                    tapply(rowMeans(r2.batch.clean), gclass, sum)), 
             type = as.factor(rep(c('Treatment','Batch'), each = 4)),
             class = factor(rep(levels(gclass),2), levels = levels(gclass)))

rbe.r2.df.bp <- 
  data.frame(r2 = c(tapply(rowMeans(r2.trt.rbe), gclass, sum), 
                    tapply(rowMeans(r2.batch.rbe), gclass, sum)), 
             type = as.factor(rep(c('Treatment','Batch'), each = 4)),
             class = factor(rep(levels(gclass),2), levels = levels(gclass)))

combat.r2.df.bp <- 
  data.frame(r2 = c(tapply(rowMeans(r2.trt.combat), gclass, sum),
                    tapply(rowMeans(r2.batch.combat), gclass, sum)), 
             type = as.factor(rep(c('Treatment','Batch'), each = 4)),
             class = factor(rep(levels(gclass),2), levels = levels(gclass)))

plsda_batch.r2.df.bp <- 
  data.frame(r2 = c(tapply(rowMeans(r2.trt.plsdab), gclass, sum), 
                    tapply(rowMeans(r2.batch.plsdab), gclass, sum)), 
             type = as.factor(rep(c('Treatment','Batch'), each = 4)),
             class = factor(rep(levels(gclass),2), levels = levels(gclass)))

splsda_batch.r2.df.bp <- 
  data.frame(r2 = c(tapply(rowMeans(r2.trt.splsdab), gclass, sum), 
                    tapply(rowMeans(r2.batch.splsdab), gclass, sum)), 
             type = as.factor(rep(c('Treatment','Batch'), each = 4)),
             class = factor(rep(levels(gclass),2), levels = levels(gclass)))


all.r2.df.bp <- rbind(before.r2.df.bp, clean.r2.df.bp,
                      rbe.r2.df.bp, combat.r2.df.bp,
                      plsda_batch.r2.df.bp, splsda_batch.r2.df.bp)


all.r2.df.bp$methods <- rep(c('Before correction', 
                              'Ground-truth data', 
                              'removeBatchEffect', 
                              'ComBat',
                              'PLSDA-batch', 
                              'sPLSDA-batch'), each = 8)

all.r2.df.bp$methods <- factor(all.r2.df.bp$methods, 
                               levels = unique(all.r2.df.bp$methods))

ggplot(all.r2.df.bp, aes(x = type, y = r2, fill = class)) +
  geom_bar(stat="identity") + 
  theme_bw() + 
  theme(text = element_text(size = 18),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        panel.grid.minor.x = element_blank(),
        panel.grid.major.x = element_blank(),
        legend.position = "right") + facet_grid(class ~ methods) +
  scale_fill_manual(values=c('dark gray', color.mixo(4), 
                             color.mixo(5), color.mixo(9)))


## -----------------------------------------------------------------------------
# precision & recall & F1 (ANOVA & sPLSDA)
## mean
acc_mean <- rbind(colMeans(precision_limma), colMeans(recall_limma), 
                  colMeans(F1_limma), c(colMeans(auc_splsda), sva = NA))
rownames(acc_mean) <- c('Precision', 'Recall', 'F1', 'AUC')
colnames(acc_mean) <- c('Before correction', 'Ground-truth data', 
                        'removeBatchEffect', 'ComBat', 
                        'PLSDA-batch', 'sPLSDA-batch', 'SVA')
acc_mean <- format(acc_mean, digits = 3)
knitr::kable(acc_mean, caption = 'Table 9: Simulation studies (three batch groups): summary of accuracy measurements before and after batch effect correction for the balanced batch × treatment design (mean).')

## -----------------------------------------------------------------------------
## sd
acc_sd <- rbind(apply(precision_limma, 2, sd), apply(recall_limma, 2, sd), 
                apply(F1_limma, 2, sd), c(apply(auc_splsda, 2, sd), NA))
rownames(acc_sd) <- c('Precision', 'Recall', 'F1', 'AUC')
colnames(acc_sd) <- c('Before correction', 'Ground-truth data', 
                      'removeBatchEffect', 'ComBat', 
                      'PLSDA-batch', 'sPLSDA-batch', 'SVA')
acc_sd <- format(acc_sd, digits = 1)
knitr::kable(acc_sd, caption = 'Table 10: Simulation studies (three batch groups): summary of accuracy measurements before and after batch effect correction for the balanced batch × treatment design (standard deviation).')

## ---- eval = F----------------------------------------------------------------
#  nitr <- 50
#  N = 36
#  p_total = 300
#  p_trt_relevant = 100
#  p_bat_relevant = 200
#  
#  # global variance (RDA)
#  gvar.before <- gvar.clean <-
#    gvar.rbe <- gvar.combat <-
#    gvar.wplsdab <- gvar.swplsdab <-
#    gvar.plsdab <- gvar.splsdab <- data.frame(treatment = NA, batch = NA,
#                                              intersection = NA,
#                                              residual = NA)
#  
#  # individual variance (R2)
#  r2.trt.before <- r2.trt.clean <-
#    r2.trt.rbe  <- r2.trt.combat <-
#    r2.trt.wplsdab <- r2.trt.swplsdab <-
#    r2.trt.plsdab <- r2.trt.splsdab <- data.frame(matrix(NA, nrow = p_total,
#                                                         ncol = nitr))
#  r2.batch.before <- r2.batch.clean <-
#    r2.batch.rbe  <- r2.batch.combat <-
#    r2.batch.wplsdab <- r2.batch.swplsdab <-
#    r2.batch.plsdab <- r2.batch.splsdab <- data.frame(matrix(NA, nrow = p_total,
#                                                             ncol = nitr))
#  
#  # precision & recall & F1 (ANOVA)
#  precision_limma <- recall_limma <- F1_limma <-
#    data.frame(before = NA, clean = NA,
#               rbe = NA, combat = NA,
#               wplsda_batch = NA, swplsda_batch = NA,
#               sva = NA)
#  
#  # auc (splsda)
#  auc_splsda <-
#    data.frame(before = NA, clean = NA,
#               rbe = NA, combat = NA,
#               wplsda_batch = NA, swplsda_batch = NA)
#  
#  
#  set.seed(70)
#  data.cor.res = corStruct(p = 300, zero_prob = 0.7)
#  
#  for(i in 1: nitr){
#    ### initial setup ###
#    simulation <- simData_mnegbinom(batch.group = 3,
#                                    mean.batch = 7,
#                                    sd.batch = 8,
#                                    mean.trt = 3,
#                                    sd.trt = 2,
#                                    mean.bg = 0,
#                                    sd.bg = 0.2,
#                                    N = 36,
#                                    p_total = 300,
#                                    p_trt_relevant = 100,
#                                    p_bat_relevant = 200,
#                                    percentage_overlap_samples = 1/6,
#                                    percentage_overlap_variables = 0.5,
#                                    data.cor = data.cor.res$data.cor,
#                                    disp = 10, prob_zero = 0,
#                                    seeds = i)
#  
#    set.seed(i)
#    raw_count <- simulation$data
#    raw_count_clean <- simulation$cleanData
#  
#    ## log transformation
#    data_log <- log(raw_count + 1)
#    data_log_clean <- log(raw_count_clean + 1)
#  
#    trt <- simulation$Y.trt
#    batch <- simulation$Y.bat
#  
#    true.trt <- simulation$true.trt
#    true.batch <- simulation$true.batch
#  
#    Batch_Trt.factors <- data.frame(Batch = batch, Treatment = trt)
#  
#    ### Original ###
#    X <- data_log
#  
#    ### Clean data ###
#    X.clean <- data_log_clean
#  
#    #####
#    rownames(X) = rownames(X.clean) = names(trt) = names(batch) =
#      paste0('sample', 1:N)
#  
#    colnames(X) = colnames(X.clean) = paste0('otu', 1:p_total)
#  
#    ### Before correction ###
#    # global variance (RDA)
#    rda.before = varpart(scale(X), ~ Treatment, ~ Batch,
#                         data = Batch_Trt.factors)
#    gvar.before[i,] <- rda.before$part$indfract$Adj.R.squared
#  
#    # precision & recall & F1 (ANOVA)
#    fit.before <- lmFit(t(scale(X)), design = model.matrix(~ as.factor(trt)))
#    fit.result.before <- topTable(eBayes(fit.before), coef = 2, number = p_total)
#    otu.sig.before <-
#      rownames(fit.result.before)[fit.result.before$adj.P.Val <= 0.05]
#  
#    precision_limma.before <-
#      length(intersect(colnames(X)[true.trt], otu.sig.before))/
#      length(otu.sig.before)
#    recall_limma.before <-
#      length(intersect(colnames(X)[true.trt], otu.sig.before))/length(true.trt)
#    F1_limma.before <-
#      (2*precision_limma.before*recall_limma.before)/
#      (precision_limma.before + recall_limma.before)
#  
#    ## replace NA value with 0
#    if(precision_limma.before == 'NaN'){
#      precision_limma.before = 0
#    }
#    if(F1_limma.before == 'NaN'){
#      F1_limma.before = 0
#    }
#  
#    # individual variance (R2)
#    indiv.trt.before <- c()
#    indiv.batch.before <- c()
#    for(c in seq_len(ncol(X))){
#      fit.res1 <- lm(scale(X)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.before <- c(indiv.trt.before, fit.summary1$r.squared)
#      indiv.batch.before <- c(indiv.batch.before, fit.summary2$r.squared)
#    }
#    r2.trt.before[ ,i] <-  indiv.trt.before
#    r2.batch.before[ ,i] <-  indiv.batch.before
#  
#  
#    # auc (sPLSDA)
#    fit.before_plsda <- splsda(X = X, Y = trt, ncomp = 1)
#  
#    true.response <- rep(0, p_total)
#    true.response[true.trt] = 1
#    before.predictor <- as.numeric(abs(fit.before_plsda$loadings$X))
#    roc.before_splsda <- roc(true.response, before.predictor, auc = TRUE)
#    auc.before_splsda <- roc.before_splsda$auc
#  
#  
#    ##############################################################################
#    ### Ground-truth data ###
#    # global variance (RDA)
#    rda.clean = varpart(scale(X.clean), ~ Treatment, ~ Batch,
#                        data = Batch_Trt.factors)
#    gvar.clean[i, ] <- rda.clean$part$indfract$Adj.R.squared
#  
#  
#    # precision & recall & F1 (ANOVA)
#    fit.clean <- lmFit(t(scale(X.clean)), design = model.matrix(~ as.factor(trt)))
#    fit.result.clean <- topTable(eBayes(fit.clean), coef = 2, number = p_total)
#    otu.sig.clean <-
#      rownames(fit.result.clean)[fit.result.clean$adj.P.Val <= 0.05]
#  
#    precision_limma.clean <-
#      length(intersect(colnames(X)[true.trt], otu.sig.clean))/
#      length(otu.sig.clean)
#    recall_limma.clean <-
#      length(intersect(colnames(X)[true.trt], otu.sig.clean))/length(true.trt)
#    F1_limma.clean <-
#      (2*precision_limma.clean*recall_limma.clean)/
#      (precision_limma.clean + recall_limma.clean)
#  
#    ## replace NA value with 0
#    if(precision_limma.clean == 'NaN'){
#      precision_limma.clean = 0
#    }
#    if(F1_limma.clean == 'NaN'){
#      F1_limma.clean = 0
#    }
#  
#    # individual variance (R2)
#    indiv.trt.clean <- c()
#    indiv.batch.clean <- c()
#    for(c in seq_len(ncol(X.clean))){
#      fit.res1 <- lm(scale(X.clean)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X.clean)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.clean <- c(indiv.trt.clean, fit.summary1$r.squared)
#      indiv.batch.clean <- c(indiv.batch.clean, fit.summary2$r.squared)
#    }
#    r2.trt.clean[ ,i] <-  indiv.trt.clean
#    r2.batch.clean[ ,i] <-  indiv.batch.clean
#  
#    # auc (sPLSDA)
#    fit.clean_plsda <- splsda(X = X.clean, Y = trt, ncomp = 1)
#  
#    clean.predictor <- as.numeric(abs(fit.clean_plsda$loadings$X))
#    roc.clean_splsda <- roc(true.response, clean.predictor, auc = TRUE)
#    auc.clean_splsda <- roc.clean_splsda$auc
#  
#    ##############################################################################
#    ### removeBatchEffect corrected data ###
#    X.rbe <-t(removeBatchEffect(t(X), batch = batch,
#                                design = model.matrix(~ as.factor(trt))))
#  
#    # global variance (RDA)
#    rda.rbe = varpart(scale(X.rbe), ~ Treatment, ~ Batch,
#                      data = Batch_Trt.factors)
#    gvar.rbe[i, ] <- rda.rbe$part$indfract$Adj.R.squared
#  
#    # precision & recall & F1 (ANOVA)
#    fit.rbe <- lmFit(t(scale(X.rbe)),
#                     design = model.matrix( ~ as.factor(trt)))
#    fit.result.rbe <- topTable(eBayes(fit.rbe), coef = 2, number = p_total)
#    otu.sig.rbe <- rownames(fit.result.rbe)[fit.result.rbe$adj.P.Val <= 0.05]
#  
#    precision_limma.rbe <- length(intersect(colnames(X)[true.trt], otu.sig.rbe))/
#      length(otu.sig.rbe)
#    recall_limma.rbe <- length(intersect(colnames(X)[true.trt], otu.sig.rbe))/
#      length(true.trt)
#    F1_limma.rbe <- (2*precision_limma.rbe*recall_limma.rbe)/
#      (precision_limma.rbe + recall_limma.rbe)
#  
#    ## replace NA value with 0
#    if(precision_limma.rbe == 'NaN'){
#      precision_limma.rbe = 0
#    }
#    if(F1_limma.rbe == 'NaN'){
#      F1_limma.rbe = 0
#    }
#  
#    # individual variance (R2)
#    indiv.trt.rbe <- c()
#    indiv.batch.rbe <- c()
#    for(c in seq_len(ncol(X.rbe))){
#      fit.res1 <- lm(scale(X.rbe)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X.rbe)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.rbe <- c(indiv.trt.rbe, fit.summary1$r.squared)
#      indiv.batch.rbe <- c(indiv.batch.rbe, fit.summary2$r.squared)
#    }
#    r2.trt.rbe[ ,i] <-  indiv.trt.rbe
#    r2.batch.rbe[ ,i] <-  indiv.batch.rbe
#  
#  
#    # auc (sPLSDA)
#    fit.rbe_plsda <- splsda(X = X.rbe, Y = trt, ncomp = 1)
#  
#    rbe.predictor <- as.numeric(abs(fit.rbe_plsda$loadings$X))
#    roc.rbe_splsda <- roc(true.response, rbe.predictor, auc = TRUE)
#    auc.rbe_splsda <- roc.rbe_splsda$auc
#  
#    ##############################################################################
#    ### ComBat corrected data ###
#    X.combat <- t(ComBat(dat = t(X), batch = batch,
#                         mod = model.matrix( ~ as.factor(trt))))
#  
#    # global variance (RDA)
#    rda.combat = varpart(scale(X.combat), ~ Treatment, ~ Batch,
#                         data = Batch_Trt.factors)
#    gvar.combat[i, ] <- rda.combat$part$indfract$Adj.R.squared
#  
#    # precision & recall & F1 (ANOVA)
#    fit.combat <- lmFit(t(scale(X.combat)),
#                        design = model.matrix( ~ as.factor(trt)))
#    fit.result.combat <- topTable(eBayes(fit.combat), coef = 2, number = p_total)
#    otu.sig.combat <-
#      rownames(fit.result.combat)[fit.result.combat$adj.P.Val <= 0.05]
#  
#    precision_limma.combat <-
#      length(intersect(colnames(X)[true.trt], otu.sig.combat))/
#      length(otu.sig.combat)
#    recall_limma.combat <-
#      length(intersect(colnames(X)[true.trt], otu.sig.combat))/
#      length(true.trt)
#    F1_limma.combat <-
#      (2*precision_limma.combat*recall_limma.combat)/
#      (precision_limma.combat + recall_limma.combat)
#  
#    ## replace NA value with 0
#    if(precision_limma.combat == 'NaN'){
#      precision_limma.combat = 0
#    }
#    if(F1_limma.combat == 'NaN'){
#      F1_limma.combat = 0
#    }
#  
#    # individual variance (R2)
#    indiv.trt.combat <- c()
#    indiv.batch.combat <- c()
#    for(c in seq_len(ncol(X.combat))){
#      fit.res1 <- lm(scale(X.combat)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X.combat)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.combat <- c(indiv.trt.combat, fit.summary1$r.squared)
#      indiv.batch.combat <- c(indiv.batch.combat, fit.summary2$r.squared)
#    }
#    r2.trt.combat[ ,i] <-  indiv.trt.combat
#    r2.batch.combat[ ,i] <-  indiv.batch.combat
#  
#  
#    # auc (sPLSDA)
#    fit.combat_plsda <- splsda(X = X.combat, Y = trt, ncomp = 1)
#  
#    combat.predictor <- as.numeric(abs(fit.combat_plsda$loadings$X))
#    roc.combat_splsda <- roc(true.response, combat.predictor, auc = TRUE)
#    auc.combat_splsda <- roc.combat_splsda$auc
#  
#  
#    ##############################################################################
#    ### wPLSDA-batch corrected data ###
#    X.wplsda_batch.correct <- PLSDA_batch(X = X,
#                                          Y.trt = trt, Y.bat = batch,
#                                          ncomp.trt = 1, ncomp.bat = 2,
#                                          balance = FALSE)
#    X.wplsda_batch <- X.wplsda_batch.correct$X.nobatch
#  
#    # global variance (RDA)
#    rda.wplsda_batch = varpart(scale(X.wplsda_batch), ~ Treatment, ~ Batch,
#                               data = Batch_Trt.factors)
#    gvar.wplsdab[i, ] <- rda.wplsda_batch$part$indfract$Adj.R.squared
#  
#    # precision & recall & F1 (ANOVA)
#    fit.wplsda_batch <- lmFit(t(scale(X.wplsda_batch)),
#                              design = model.matrix( ~ as.factor(trt)))
#    fit.result.wplsda_batch <- topTable(eBayes(fit.wplsda_batch),
#                                        coef = 2, number = p_total)
#    otu.sig.wplsda_batch <- rownames(fit.result.wplsda_batch)[
#      fit.result.wplsda_batch$adj.P.Val <= 0.05]
#  
#    precision_limma.wplsda_batch <-
#      length(intersect(colnames(X)[true.trt], otu.sig.wplsda_batch))/
#      length(otu.sig.wplsda_batch)
#    recall_limma.wplsda_batch <-
#      length(intersect(colnames(X)[true.trt], otu.sig.wplsda_batch))/
#      length(true.trt)
#    F1_limma.wplsda_batch <-
#      (2*precision_limma.wplsda_batch*recall_limma.wplsda_batch)/
#      (precision_limma.wplsda_batch + recall_limma.wplsda_batch)
#  
#    ## replace NA value with 0
#    if(precision_limma.wplsda_batch == 'NaN'){
#      precision_limma.wplsda_batch = 0
#    }
#    if(F1_limma.wplsda_batch == 'NaN'){
#      F1_limma.wplsda_batch = 0
#    }
#  
#    # individual variance (R2)
#    indiv.trt.wplsda_batch <- c()
#    indiv.batch.wplsda_batch <- c()
#    for(c in seq_len(ncol(X.wplsda_batch))){
#      fit.res1 <- lm(scale(X.wplsda_batch)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X.wplsda_batch)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.wplsda_batch <- c(indiv.trt.wplsda_batch,
#                                  fit.summary1$r.squared)
#      indiv.batch.wplsda_batch <- c(indiv.batch.wplsda_batch,
#                                    fit.summary2$r.squared)
#    }
#    r2.trt.wplsdab[ ,i] <-  indiv.trt.wplsda_batch
#    r2.batch.wplsdab[ ,i] <-  indiv.batch.wplsda_batch
#  
#    # auc (sPLSDA)
#    fit.wplsda_batch_plsda <- splsda(X = X.wplsda_batch, Y = trt, ncomp = 1)
#  
#    wplsda_batch.predictor <- as.numeric(abs(fit.wplsda_batch_plsda$loadings$X))
#    roc.wplsda_batch_splsda <- roc(true.response,
#                                   wplsda_batch.predictor, auc = TRUE)
#    auc.wplsda_batch_splsda <- roc.wplsda_batch_splsda$auc
#  
#    ##############################################################################
#    ### sPLSDA-batch corrected data ###
#    X.swplsda_batch.correct <- PLSDA_batch(X = X,
#                                           Y.trt = trt,
#                                           Y.bat = batch,
#                                           ncomp.trt = 1,
#                                           keepX.trt = length(true.trt),
#                                           ncomp.bat = 2,
#                                           balance = FALSE)
#    X.swplsda_batch <- X.swplsda_batch.correct$X.nobatch
#  
#    # global variance (RDA)
#    rda.swplsda_batch = varpart(scale(X.swplsda_batch), ~ Treatment, ~ Batch,
#                                data = Batch_Trt.factors)
#    gvar.swplsdab[i, ] <- rda.swplsda_batch$part$indfract$Adj.R.squared
#  
#    # precision & recall & F1 (ANOVA)
#    fit.swplsda_batch <- lmFit(t(scale(X.swplsda_batch)),
#                               design = model.matrix( ~ as.factor(trt)))
#    fit.result.swplsda_batch <- topTable(eBayes(fit.swplsda_batch), coef = 2,
#                                         number = p_total)
#    otu.sig.swplsda_batch <- rownames(fit.result.swplsda_batch)[
#      fit.result.swplsda_batch$adj.P.Val <= 0.05]
#  
#    precision_limma.swplsda_batch <-
#      length(intersect(colnames(X)[true.trt], otu.sig.swplsda_batch))/
#      length(otu.sig.swplsda_batch)
#    recall_limma.swplsda_batch <-
#      length(intersect(colnames(X)[true.trt], otu.sig.swplsda_batch))/
#      length(true.trt)
#    F1_limma.swplsda_batch <-
#      (2*precision_limma.swplsda_batch*recall_limma.swplsda_batch)/
#      (precision_limma.swplsda_batch + recall_limma.swplsda_batch)
#  
#    ## replace NA value with 0
#    if(precision_limma.swplsda_batch == 'NaN'){
#      precision_limma.swplsda_batch = 0
#    }
#    if(F1_limma.swplsda_batch == 'NaN'){
#      F1_limma.swplsda_batch = 0
#    }
#  
#  
#    # individual variance (R2)
#    indiv.trt.swplsda_batch <- c()
#    indiv.batch.swplsda_batch <- c()
#    for(c in seq_len(ncol(X.swplsda_batch))){
#      fit.res1 <- lm(scale(X.swplsda_batch)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X.swplsda_batch)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.swplsda_batch <- c(indiv.trt.swplsda_batch,
#                                   fit.summary1$r.squared)
#      indiv.batch.swplsda_batch <- c(indiv.batch.swplsda_batch,
#                                     fit.summary2$r.squared)
#    }
#    r2.trt.swplsdab[ ,i] <-  indiv.trt.swplsda_batch
#    r2.batch.swplsdab[ ,i] <-  indiv.batch.swplsda_batch
#  
#    # auc (sPLSDA)
#    fit.swplsda_batch_plsda <- splsda(X = X.swplsda_batch, Y = trt, ncomp = 1)
#  
#    swplsda_batch.predictor <- as.numeric(abs(fit.swplsda_batch_plsda$loadings$X))
#    roc.swplsda_batch_splsda <- roc(true.response,
#                                    swplsda_batch.predictor, auc = TRUE)
#    auc.swplsda_batch_splsda <- roc.swplsda_batch_splsda$auc
#  
#    ##############################################################################
#    ### PLSDA-batch corrected data ###
#    X.plsda_batch.correct <- PLSDA_batch(X = X,
#                                         Y.trt = trt, Y.bat = batch,
#                                         ncomp.trt = 1, ncomp.bat = 2)
#    X.plsda_batch <- X.plsda_batch.correct$X.nobatch
#  
#    # global variance (RDA)
#    rda.plsda_batch = varpart(scale(X.plsda_batch), ~ Treatment, ~ Batch,
#                              data = Batch_Trt.factors)
#    gvar.plsdab[i, ] <- rda.plsda_batch$part$indfract$Adj.R.squared
#  
#    # precision & recall & F1 (ANOVA)
#    fit.plsda_batch <- lmFit(t(scale(X.plsda_batch)),
#                             design = model.matrix( ~ as.factor(trt)))
#    fit.result.plsda_batch <- topTable(eBayes(fit.plsda_batch),
#                                       coef = 2, number = p_total)
#    otu.sig.plsda_batch <- rownames(fit.result.plsda_batch)[
#      fit.result.plsda_batch$adj.P.Val <= 0.05]
#  
#    precision_limma.plsda_batch <-
#      length(intersect(colnames(X)[true.trt], otu.sig.plsda_batch))/
#      length(otu.sig.plsda_batch)
#    recall_limma.plsda_batch <-
#      length(intersect(colnames(X)[true.trt], otu.sig.plsda_batch))/
#      length(true.trt)
#    F1_limma.plsda_batch <-
#      (2*precision_limma.plsda_batch*recall_limma.plsda_batch)/
#      (precision_limma.plsda_batch + recall_limma.plsda_batch)
#  
#    ## replace NA value with 0
#    if(precision_limma.plsda_batch == 'NaN'){
#      precision_limma.plsda_batch = 0
#    }
#    if(F1_limma.plsda_batch == 'NaN'){
#      F1_limma.plsda_batch = 0
#    }
#  
#    # individual variance (R2)
#    indiv.trt.plsda_batch <- c()
#    indiv.batch.plsda_batch <- c()
#    for(c in seq_len(ncol(X.plsda_batch))){
#      fit.res1 <- lm(scale(X.plsda_batch)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X.plsda_batch)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.plsda_batch <- c(indiv.trt.plsda_batch,
#                                 fit.summary1$r.squared)
#      indiv.batch.plsda_batch <- c(indiv.batch.plsda_batch,
#                                   fit.summary2$r.squared)
#    }
#    r2.trt.plsdab[ ,i] <-  indiv.trt.plsda_batch
#    r2.batch.plsdab[ ,i] <-  indiv.batch.plsda_batch
#  
#    # auc (sPLSDA)
#    fit.plsda_batch_plsda <- splsda(X = X.plsda_batch, Y = trt, ncomp = 1)
#  
#    plsda_batch.predictor <- as.numeric(abs(fit.plsda_batch_plsda$loadings$X))
#    roc.plsda_batch_splsda <- roc(true.response,
#                                  plsda_batch.predictor, auc = TRUE)
#    auc.plsda_batch_splsda <- roc.plsda_batch_splsda$auc
#  
#    ##############################################################################
#    ### sPLSDA-batch corrected data ###
#    X.splsda_batch.correct <- PLSDA_batch(X = X,
#                                          Y.trt = trt,
#                                          Y.bat = batch,
#                                          ncomp.trt = 1,
#                                          keepX.trt = length(true.trt),
#                                          ncomp.bat = 2)
#    X.splsda_batch <- X.splsda_batch.correct$X.nobatch
#  
#    # global variance (RDA)
#    rda.splsda_batch = varpart(scale(X.splsda_batch), ~ Treatment, ~ Batch,
#                               data = Batch_Trt.factors)
#    gvar.splsdab[i, ] <- rda.splsda_batch$part$indfract$Adj.R.squared
#  
#    # precision & recall & F1 (ANOVA)
#    fit.splsda_batch <- lmFit(t(scale(X.splsda_batch)),
#                              design = model.matrix( ~ as.factor(trt)))
#    fit.result.splsda_batch <- topTable(eBayes(fit.splsda_batch), coef = 2,
#                                        number = p_total)
#    otu.sig.splsda_batch <- rownames(fit.result.splsda_batch)[
#      fit.result.splsda_batch$adj.P.Val <= 0.05]
#  
#    precision_limma.splsda_batch <-
#      length(intersect(colnames(X)[true.trt], otu.sig.splsda_batch))/
#      length(otu.sig.splsda_batch)
#    recall_limma.splsda_batch <-
#      length(intersect(colnames(X)[true.trt], otu.sig.splsda_batch))/
#      length(true.trt)
#    F1_limma.splsda_batch <-
#      (2*precision_limma.splsda_batch*recall_limma.splsda_batch)/
#      (precision_limma.splsda_batch + recall_limma.splsda_batch)
#  
#    ## replace NA value with 0
#    if(precision_limma.splsda_batch == 'NaN'){
#      precision_limma.splsda_batch = 0
#    }
#    if(F1_limma.splsda_batch == 'NaN'){
#      F1_limma.splsda_batch = 0
#    }
#  
#  
#    # individual variance (R2)
#    indiv.trt.splsda_batch <- c()
#    indiv.batch.splsda_batch <- c()
#    for(c in seq_len(ncol(X.splsda_batch))){
#      fit.res1 <- lm(scale(X.splsda_batch)[ ,c] ~ trt)
#      fit.summary1 <- summary(fit.res1)
#      fit.res2 <- lm(scale(X.splsda_batch)[ ,c] ~ batch)
#      fit.summary2 <- summary(fit.res2)
#      indiv.trt.splsda_batch <- c(indiv.trt.splsda_batch,
#                                  fit.summary1$r.squared)
#      indiv.batch.splsda_batch <- c(indiv.batch.splsda_batch,
#                                    fit.summary2$r.squared)
#    }
#    r2.trt.splsdab[ ,i] <-  indiv.trt.splsda_batch
#    r2.batch.splsdab[ ,i] <-  indiv.batch.splsda_batch
#  
#    # auc (sPLSDA)
#    fit.splsda_batch_plsda <- splsda(X = X.splsda_batch, Y = trt, ncomp = 1)
#  
#    splsda_batch.predictor <- as.numeric(abs(fit.splsda_batch_plsda$loadings$X))
#    roc.splsda_batch_splsda <- roc(true.response,
#                                   splsda_batch.predictor, auc = TRUE)
#    auc.splsda_batch_splsda <- roc.splsda_batch_splsda$auc
#  
#    ##############################################################################
#    ### SVA ###
#    X.mod <- model.matrix(~ as.factor(trt))
#    X.mod0 <- model.matrix(~ 1, data = as.factor(trt))
#    X.sva.n <- num.sv(dat = t(X), mod = X.mod, method = 'leek')
#    X.sva <- sva(t(X), X.mod, X.mod0, n.sv = X.sva.n)
#  
#    X.mod.batch <- cbind(X.mod, X.sva$sv)
#    X.mod0.batch <- cbind(X.mod0, X.sva$sv)
#    X.sva.p <- f.pvalue(t(X), X.mod.batch, X.mod0.batch)
#    X.sva.p.adj <- p.adjust(X.sva.p, method = 'fdr')
#  
#    otu.sig.sva <- which(X.sva.p.adj <= 0.05)
#  
#    # precision & recall & F1 (ANOVA)
#    precision_limma.sva <-
#      length(intersect(true.trt, otu.sig.sva))/length(otu.sig.sva)
#    recall_limma.sva <-
#      length(intersect(true.trt, otu.sig.sva))/length(true.trt)
#    F1_limma.sva <-
#      (2*precision_limma.sva*recall_limma.sva)/
#      (precision_limma.sva + recall_limma.sva)
#  
#    ## replace NA value with 0
#    if(precision_limma.sva == 'NaN'){
#      precision_limma.sva = 0
#    }
#    if(F1_limma.sva == 'NaN'){
#      F1_limma.sva = 0
#    }
#  
#  
#    # summary
#    # precision & recall & F1 (ANOVA)
#    precision_limma[i, ] <- c(`Before correction` = precision_limma.before,
#                              `Ground-truth data` = precision_limma.clean,
#                              `removeBatchEffect` = precision_limma.rbe,
#                              ComBat = precision_limma.combat,
#                              `wPLSDA-batch` = precision_limma.wplsda_batch,
#                              `swPLSDA-batch` = precision_limma.swplsda_batch,
#                              SVA = precision_limma.sva)
#  
#    recall_limma[i, ] <- c(`Before correction` = recall_limma.before,
#                           `Ground-truth data` = recall_limma.clean,
#                           `removeBatchEffect` = recall_limma.rbe,
#                           ComBat = recall_limma.combat,
#                           `wPLSDA-batch` = recall_limma.wplsda_batch,
#                           `swPLSDA-batch` = recall_limma.swplsda_batch,
#                           SVA = recall_limma.sva)
#  
#    F1_limma[i, ] <- c(`Before correction` = F1_limma.before,
#                       `Ground-truth data` = F1_limma.clean,
#                       `removeBatchEffect` = F1_limma.rbe,
#                       ComBat = F1_limma.combat,
#                       `wPLSDA-batch` = F1_limma.wplsda_batch,
#                       `swPLSDA-batch` = F1_limma.swplsda_batch,
#                       SVA = F1_limma.sva)
#  
#    # auc (splsda)
#    auc_splsda[i, ] <- c(`Before correction` = auc.before_splsda,
#                         `Ground-truth data` = auc.clean_splsda,
#                         `removeBatchEffect` = auc.rbe_splsda,
#                         ComBat = auc.combat_splsda,
#                         `wPLSDA-batch` = auc.wplsda_batch_splsda,
#                         `swPLSDA-batch` = auc.swplsda_batch_splsda)
#  
#    #  print(i)
#  
#  }
#  

## ---- echo = F----------------------------------------------------------------
# save(gvar.before, gvar.clean, gvar.rbe, gvar.combat, gvar.wplsdab, gvar.swplsdab, gvar.plsdab, gvar.splsdab, nitr, p_total, p_trt_relevant, p_bat_relevant, true.trt, true.batch, r2.trt.before, r2.batch.before, r2.trt.clean, r2.batch.clean, r2.trt.rbe, r2.batch.rbe, r2.trt.combat, r2.batch.combat, r2.trt.wplsdab, r2.batch.wplsdab, r2.trt.swplsdab, r2.batch.swplsdab, r2.trt.plsdab, r2.batch.plsdab, r2.trt.splsdab, r2.batch.splsdab, precision_limma, recall_limma, F1_limma, auc_splsda, file = './SimulationData/unbalanced_mnegbinom_3batches.rda')

load(file = './SimulationData/unbalanced_mnegbinom_3batches.rda')

## ---- fig.cap = 'Figure 10: Simulation studies (three batch groups): comparison of explained variance before and after batch effect correction for the unbalanced batch × treatment design.'----
# global variance (RDA)
prop.gvar.all <- rbind(`Before correction` = colMeans(gvar.before),
                       `Ground-truth data` = colMeans(gvar.clean),
                       removeBatchEffect = colMeans(gvar.rbe),
                       ComBat = colMeans(gvar.combat),
                       `wPLSDA-batch` = colMeans(gvar.wplsdab),
                       `swPLSDA-batch` = colMeans(gvar.swplsdab),
                       `PLSDA-batch` = colMeans(gvar.plsdab),
                       `sPLSDA-batch` = colMeans(gvar.splsdab))

prop.gvar.all[prop.gvar.all < 0] = 0
prop.gvar.all <- t(apply(prop.gvar.all, 1, function(x){x/sum(x)}))
colnames(prop.gvar.all) <- c('Treatment', 'Intersection', 'Batch', 'Residuals')

partVar_plot(prop.df = prop.gvar.all)


## ---- fig.width = 14, fig.height = 12, out.width = '100%', fig.cap = 'Figure 11: Simulation studies (three batch groups): R2 values for each microbial variable before and after batch effect correction for the unbalanced batch × treatment design.'----
################################################################################
# individual variance (R2)
## boxplot
# class
gclass <- c(rep('Treatment only', p_trt_relevant), 
            rep('Batch only', (p_total - p_trt_relevant)))
gclass[intersect(true.trt, true.batch)] = 'Treatment & batch'
gclass[setdiff(1:p_total, union(true.trt, true.batch))] = 'No effect'

gclass <- factor(gclass, levels = c('Treatment & batch', 
                                    'Treatment only', 
                                    'Batch only', 
                                    'No effect'))

before.r2.df.ggp <- data.frame(r2 = c(rowMeans(r2.trt.before), 
                                      rowMeans(r2.batch.before)), 
                               type = as.factor(rep(c('Treatment','Batch'), 
                                                    each = 300)),
                               class = rep(gclass,2))
clean.r2.df.ggp <- data.frame(r2 = c(rowMeans(r2.trt.clean), 
                                     rowMeans(r2.batch.clean)), 
                              type = as.factor(rep(c('Treatment','Batch'), 
                                                   each = 300)),
                              class = rep(gclass,2))
rbe.r2.df.ggp <- data.frame(r2 = c(rowMeans(r2.trt.rbe), 
                                   rowMeans(r2.batch.rbe)), 
                            type = as.factor(rep(c('Treatment','Batch'), 
                                                 each = 300)),
                            class = rep(gclass,2))
combat.r2.df.ggp <- data.frame(r2 = c(rowMeans(r2.trt.combat), 
                                      rowMeans(r2.batch.combat)), 
                               type = as.factor(rep(c('Treatment','Batch'), 
                                                    each = 300)),
                               class = rep(gclass,2))
wplsda_batch.r2.df.ggp <- 
  data.frame(r2 = c(rowMeans(r2.trt.wplsdab), 
                    rowMeans(r2.batch.wplsdab)), 
             type = as.factor(rep(c('Treatment','Batch'), 
                                  each = 300)),
             class = rep(gclass,2))
swplsda_batch.r2.df.ggp <- 
  data.frame(r2 = c(rowMeans(r2.trt.swplsdab), 
                    rowMeans(r2.batch.swplsdab)), 
             type = as.factor(rep(c('Treatment','Batch'),
                                  each = 300)),
             class = rep(gclass,2))

all.r2.df.ggp <- rbind(before.r2.df.ggp, clean.r2.df.ggp,
                       rbe.r2.df.ggp, combat.r2.df.ggp,
                       wplsda_batch.r2.df.ggp, swplsda_batch.r2.df.ggp)

all.r2.df.ggp$methods <- rep(c('Before correction', 
                               'Ground-truth data', 
                               'removeBatchEffect', 
                               'ComBat',
                               'wPLSDA-batch', 
                               'swPLSDA-batch'), each = 600)

all.r2.df.ggp$methods <- factor(all.r2.df.ggp$methods, 
                                levels = unique(all.r2.df.ggp$methods))

ggplot(all.r2.df.ggp, aes(x = type, y = r2, fill = class)) +
  geom_boxplot(alpha = 0.80) +
  theme_bw() + 
  theme(text = element_text(size = 18),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        panel.grid.minor.x = element_blank(),
        panel.grid.major.x = element_blank(),
        legend.position = "right") + facet_grid(class ~ methods) + 
  scale_fill_manual(values=c('dark gray', color.mixo(4), 
                             color.mixo(5), color.mixo(9)))

## ---- fig.width = 14, fig.height = 12, out.width = '100%', fig.cap = 'Figure 12: Simulation studies (three batch groups): the sum of R2 values for each microbial variable before and after batch effect correction for the unbalanced batch × treatment design.'----
################################################################################
## barplot
# class
before.r2.df.bp <- 
  data.frame(r2 = c(tapply(rowMeans(r2.trt.before), gclass, sum), 
                    tapply(rowMeans(r2.batch.before), gclass, sum)), 
             type = as.factor(rep(c('Treatment','Batch'), each = 4)),
             class = factor(rep(levels(gclass),2), levels = levels(gclass)))

clean.r2.df.bp <- 
  data.frame(r2 = c(tapply(rowMeans(r2.trt.clean), gclass, sum), 
                    tapply(rowMeans(r2.batch.clean), gclass, sum)), 
             type = as.factor(rep(c('Treatment','Batch'), each = 4)),
             class = factor(rep(levels(gclass),2), levels = levels(gclass)))

rbe.r2.df.bp <- 
  data.frame(r2 = c(tapply(rowMeans(r2.trt.rbe), gclass, sum), 
                    tapply(rowMeans(r2.batch.rbe), gclass, sum)), 
             type = as.factor(rep(c('Treatment','Batch'), each = 4)),
             class = factor(rep(levels(gclass),2), levels = levels(gclass)))

combat.r2.df.bp <- 
  data.frame(r2 = c(tapply(rowMeans(r2.trt.combat), gclass, sum), 
                    tapply(rowMeans(r2.batch.combat), gclass, sum)), 
             type = as.factor(rep(c('Treatment','Batch'), each = 4)),
             class = factor(rep(levels(gclass),2), levels = levels(gclass)))

wplsda_batch.r2.df.bp <- 
  data.frame(r2 = c(tapply(rowMeans(r2.trt.wplsdab), gclass, sum), 
                    tapply(rowMeans(r2.batch.wplsdab), gclass, sum)), 
             type = as.factor(rep(c('Treatment','Batch'), each = 4)),
             class = factor(rep(levels(gclass),2), levels = levels(gclass)))

swplsda_batch.r2.df.bp <- 
  data.frame(r2 = c(tapply(rowMeans(r2.trt.swplsdab), gclass, sum), 
                    tapply(rowMeans(r2.batch.swplsdab), gclass, sum)), 
             type = as.factor(rep(c('Treatment','Batch'), each = 4)),
             class = factor(rep(levels(gclass),2), levels = levels(gclass)))


all.r2.df.bp <- rbind(before.r2.df.bp, clean.r2.df.bp,
                      rbe.r2.df.bp, combat.r2.df.bp,
                      wplsda_batch.r2.df.bp, swplsda_batch.r2.df.bp)


all.r2.df.bp$methods <- rep(c('Before correction', 
                              'Ground-truth data', 
                              'removeBatchEffect', 
                              'ComBat',
                              'wPLSDA-batch', 'swPLSDA-batch'), each = 8)

all.r2.df.bp$methods <- factor(all.r2.df.bp$methods, 
                               levels = unique(all.r2.df.bp$methods))

ggplot(all.r2.df.bp, aes(x = type, y = r2, fill = class)) +
  geom_bar(stat="identity") + 
  theme_bw() + 
  theme(text = element_text(size = 18),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        panel.grid.minor.x = element_blank(),
        panel.grid.major.x = element_blank(),
        legend.position = "right") + facet_grid(class ~ methods) + 
  scale_fill_manual(values=c('dark gray', color.mixo(4), 
                             color.mixo(5), color.mixo(9)))


## -----------------------------------------------------------------------------
# precision & recall & F1 (ANOVA & sPLSDA)
## mean
acc_mean <- rbind(colMeans(precision_limma), colMeans(recall_limma), 
                  colMeans(F1_limma), c(colMeans(auc_splsda), sva = NA))
rownames(acc_mean) <- c('Precision', 'Recall', 'F1', 'AUC')
colnames(acc_mean) <- c('Before correction', 'Ground-truth data', 
                        'removeBatchEffect', 'ComBat', 
                        'wPLSDA-batch', 'swPLSDA-batch', 'SVA')
acc_mean <- format(acc_mean, digits = 3)
knitr::kable(acc_mean, caption = 'Table 12: Simulation studies (three batch groups): summary of accuracy measurements before and after batch effect correction for the unbalanced batch × treatment design (mean).')

## -----------------------------------------------------------------------------
## sd
acc_sd <- rbind(apply(precision_limma, 2, sd), apply(recall_limma, 2, sd), 
                apply(F1_limma, 2, sd), c(apply(auc_splsda, 2, sd), NA))
rownames(acc_sd) <- c('Precision', 'Recall', 'F1', 'AUC')
colnames(acc_sd) <- c('Before correction', 'Ground-truth data', 
                      'removeBatchEffect', 'ComBat', 
                      'wPLSDA-batch', 'swPLSDA-batch', 'SVA')
acc_sd <- format(acc_sd, digits = 1)
knitr::kable(acc_sd, caption = 'Table 13: Simulation studies (three batch groups): summary of accuracy measurements before and after batch effect correction for the unbalanced batch × treatment design (standard deviation).')

