## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(dpi = 300, echo = TRUE, warning = FALSE, message = FALSE, 
                      eval = TRUE, fig.show = TRUE, fig.width = 6, 
                      fig.height = 4, fig.align ='center', 
                      out.width = '60%', cache = FALSE)

## ---- include = FALSE---------------------------------------------------------
colorize <- function(x, color) {
  if (knitr::is_latex_output()) {
    sprintf("\\textcolor{%s}{%s}", color, x)
  } else if (knitr::is_html_output()) {
    htmlcolor = "black"
    if(color == "blue"){
      htmlcolor = "#0000FF"
    }
    if(color == "brown"){
      htmlcolor = "#964B00"
    }
    if(color == "olive"){
      htmlcolor = "#808000"
    }
    if(color == "violet"){
      htmlcolor = "#8601AF"
    }
    if(color == "orange"){
      htmlcolor = "#FF7F00"
    }
    sprintf("<span style='color: %s;'>%s</span>", htmlcolor, x)
  } else x
}

## -----------------------------------------------------------------------------
# CRAN
cran.pkgs <- c('pheatmap', 'vegan', 'ruv', 'UpSetR', 'gplots', 
               'ggplot2', 'gridExtra', 'performance')
# Bioconductor
bioc.pkgs <- c('mixOmics', 'sva', 'limma', 'Biobase', 'metagenomeSeq')
# GitHub
github.pkg <- 'PLSDAbatch' 
# devtools::install_github("https://github.com/EvaYiwenWang/PLSDAbatch")

# load packages 
sapply(c(cran.pkgs, bioc.pkgs, github.pkg), require, character.only = TRUE)

# print package versions
sapply(c(cran.pkgs, bioc.pkgs, github.pkg), package.version)

## -----------------------------------------------------------------------------
# Sponge data
data('sponge_data') 
sponge.tss <- sponge_data$X.tss
dim(sponge.tss)
# zero proportion
mean(sponge.tss == 0)

## -----------------------------------------------------------------------------
sponge.clr <- logratio.transfo(X = sponge.tss, logratio = 'CLR', offset = 0.01)

class(sponge.clr) <- 'matrix'

## ----SpongepcaBefore, fig.align = 'center', fig.cap = 'Figure 1: The PCA sample plot with densities in the sponge data.'----
sponge.pca.before <- pca(sponge.clr, ncomp = 3, scale = TRUE)

sponge.batch <- sponge_data$Y.bat
sponge.trt <- sponge_data$Y.trt

Scatter_Density(object = sponge.pca.before, 
                batch = sponge.batch, 
                trt = sponge.trt, title = 'Sponge data', 
                trt.legend.title = 'Tissue types')

## ----Spongeheatmap, out.width = '90%', fig.align = 'center', fig.cap = 'Figure 2: Hierarchical clustering for samples in the sponge data.'----
# scale the clr data on both OTUs and samples
sponge.clr.s <- scale(sponge.clr, center = T, scale = T)
sponge.clr.ss <- scale(t(sponge.clr.s), center = T, scale = T)

sponge.anno_col <- data.frame(Batch = sponge.batch, Tissue = sponge.trt)
sponge.anno_colors <- list(Batch = color.mixo(1:2), 
                           Tissue = pb_color(1:2))
names(sponge.anno_colors$Batch) = levels(sponge.batch)
names(sponge.anno_colors$Tissue) = levels(sponge.trt)

pheatmap(sponge.clr.ss, 
         cluster_rows = F, 
         fontsize_row = 4, 
         fontsize_col = 6,
         fontsize = 8,
         clustering_distance_rows = 'euclidean',
         clustering_method = 'ward.D',
         treeheight_row = 30,
         annotation_col = sponge.anno_col,
         annotation_colors = sponge.anno_colors,
         border_color = 'NA',
         main = 'Sponge data - Scaled')


## -----------------------------------------------------------------------------
sponge.factors.df <- data.frame(trt = sponge.trt, 
                                batch = sponge.batch)
sponge.rda.before <- varpart(sponge.clr, ~ trt, ~ batch, 
                             data = sponge.factors.df, 
                             scale = T)
sponge.rda.before$part$indfract

## ----Spongelm, fig.height = 13, fig.width = 12, out.width = '100%', fig.align = 'center', fig.cap = 'Figure 3: Diagnostic plots for the model fitted with batch effects of "OTU2" in the sponge data.'----
sponge.clr <- sponge.clr[1:nrow(sponge.clr), 1:ncol(sponge.clr)]
sponge.lm <- linear_regres(data = sponge.clr, 
                           trt = sponge.trt, 
                           batch.fix = sponge.batch, 
                           type = 'linear model')

sponge.p <- sapply(sponge.lm$lm.table, function(x){x$coefficients[2,4]})
sponge.p.adj <- p.adjust(p = sponge.p, method = 'fdr')

check_model(sponge.lm$model$OTU2)

## -----------------------------------------------------------------------------
head(sponge.lm$adj.R2)

## -----------------------------------------------------------------------------
head(sponge.lm$AIC)

## -----------------------------------------------------------------------------
# estimate batch matrix
sponge.mod <- model.matrix( ~ sponge.trt)
sponge.mod0 <- model.matrix( ~ 1, data = sponge.trt)
sponge.sva.n <- num.sv(dat = t(sponge.clr), mod = sponge.mod, method = 'leek')
sponge.sva <- sva(t(sponge.clr), sponge.mod, sponge.mod0, n.sv = sponge.sva.n)

## -----------------------------------------------------------------------------
# include estimated batch effects in the linear model
sponge.mod.batch <- cbind(sponge.mod, sponge.sva$sv)
sponge.mod0.batch <- cbind(sponge.mod0, sponge.sva$sv)
sponge.sva.p <- f.pvalue(t(sponge.clr), sponge.mod.batch, sponge.mod0.batch)
sponge.sva.p.adj <- p.adjust(sponge.sva.p, method = 'fdr')

## -----------------------------------------------------------------------------
# empirical negative controls
sponge.empir.p <- c()
for(e in 1:ncol(sponge.clr)){
  sponge.empir.lm <- lm(sponge.clr[,e] ~ sponge.trt)
  sponge.empir.p[e] <- summary(sponge.empir.lm)$coefficients[2,4]
}
sponge.empir.p.adj <- p.adjust(p = sponge.empir.p, method = 'fdr')
sponge.nc <- sponge.empir.p.adj > 0.05

## -----------------------------------------------------------------------------
# estimate k
sponge.k.res <- getK(Y = sponge.clr, X = sponge.trt, ctl = sponge.nc)
sponge.k <- sponge.k.res$k
sponge.k <- ifelse(sponge.k != 0, sponge.k, 1)

## -----------------------------------------------------------------------------
sponge.ruv4 <- RUV4(Y = sponge.clr, X = sponge.trt, 
                    ctl = sponge.nc, k = sponge.k) 
sponge.ruv4.p <- sponge.ruv4$p
sponge.ruv4.p.adj <- p.adjust(sponge.ruv4.p, method = "fdr")

## -----------------------------------------------------------------------------
sponge.rBE <- t(removeBatchEffect(t(sponge.clr), batch = sponge.batch, 
                                  design = sponge.mod))

## -----------------------------------------------------------------------------
sponge.ComBat <- t(ComBat(t(sponge.clr), batch = sponge.batch, 
                          mod = sponge.mod, par.prior = F))


## -----------------------------------------------------------------------------
# estimate the number of treatment components
sponge.trt.tune <- plsda(X = sponge.clr, Y = sponge.trt, ncomp = 5)
sponge.trt.tune$prop_expl_var #1

## -----------------------------------------------------------------------------
# estimate the number of batch components
sponge.batch.tune <- PLSDA_batch(X = sponge.clr, 
                                 Y.trt = sponge.trt, 
                                 Y.bat = sponge.batch,
                                 ncomp.trt = 1, 
                                 ncomp.bat = 5)
sponge.batch.tune$explained_variance.bat #1

## -----------------------------------------------------------------------------
sponge.PLSDA_batch.res <- PLSDA_batch(X = sponge.clr, 
                                      Y.trt = sponge.trt, 
                                      Y.bat = sponge.batch,
                                      ncomp.trt = 1, 
                                      ncomp.bat = 1)
sponge.PLSDA_batch <- sponge.PLSDA_batch.res$X.nobatch

## -----------------------------------------------------------------------------
# estimate the number of variables to select per treatment component
set.seed(777)
sponge.test.keepX = seq(1, 24, 1)
sponge.trt.tune.v <- tune.splsda(X = sponge.clr, 
                                 Y = sponge.trt, 
                                 ncomp = 1, 
                                 test.keepX = sponge.test.keepX, 
                                 validation = 'Mfold', 
                                 folds = 4, nrepeat = 50)
sponge.trt.tune.v$choice.keepX #1

## -----------------------------------------------------------------------------
# estimate the number of batch components
sponge.batch.tune <- PLSDA_batch(X = sponge.clr, 
                                 Y.trt = sponge.trt, 
                                 Y.bat = sponge.batch,
                                 ncomp.trt = 1, 
                                 keepX.trt = 1,
                                 ncomp.bat = 5)
sponge.batch.tune$explained_variance.bat #1

## -----------------------------------------------------------------------------
sponge.sPLSDA_batch.res <- PLSDA_batch(X = sponge.clr, 
                                       Y.trt = sponge.trt, 
                                       Y.bat = sponge.batch,
                                       ncomp.trt = 1, 
                                       keepX.trt = 1,
                                       ncomp.bat = 1)
sponge.sPLSDA_batch <- sponge.sPLSDA_batch.res$X.nobatch

## -----------------------------------------------------------------------------
sponge.PN <- percentile_norm(data = sponge.clr, 
                             batch = sponge.batch, 
                             trt = sponge.trt, 
                             ctrl.grp = 'C')

## -----------------------------------------------------------------------------
sponge.pca.before <- pca(sponge.clr, ncomp = 3, 
                         scale = TRUE)
sponge.pca.rBE <- pca(sponge.rBE, ncomp = 3, 
                      scale = TRUE)
sponge.pca.ComBat <- pca(sponge.ComBat, ncomp = 3, 
                         scale = TRUE)
sponge.pca.PLSDA_batch <- pca(sponge.PLSDA_batch, ncomp = 3, 
                              scale = TRUE)
sponge.pca.sPLSDA_batch <- pca(sponge.sPLSDA_batch, ncomp = 3, 
                               scale = TRUE)
sponge.pca.PN <- pca(sponge.PN, ncomp = 3, 
                     scale = TRUE)

## ---- fig.show='hide'---------------------------------------------------------
sponge.pca.before.plot <- 
  Scatter_Density(object = sponge.pca.before, 
                  batch = sponge.batch, 
                  trt = sponge.trt, 
                  title = 'Before', 
                  trt.legend.title = 'Tissue')
sponge.pca.rBE.plot <- 
  Scatter_Density(object = sponge.pca.rBE, 
                  batch = sponge.batch, 
                  trt = sponge.trt, 
                  title = 'removeBatchEffect', 
                  trt.legend.title = 'Tissue')
sponge.pca.ComBat.plot <- 
  Scatter_Density(object = sponge.pca.ComBat, 
                  batch = sponge.batch, 
                  trt = sponge.trt, 
                  title = 'ComBat', 
                  trt.legend.title = 'Tissue')
sponge.pca.PLSDA_batch.plot <- 
  Scatter_Density(object = sponge.pca.PLSDA_batch, 
                  batch = sponge.batch, 
                  trt = sponge.trt, 
                  title = 'PLSDA-batch', 
                  trt.legend.title = 'Tissue')
sponge.pca.sPLSDA_batch.plot <- 
  Scatter_Density(object = sponge.pca.sPLSDA_batch, 
                  batch = sponge.batch, 
                  trt = sponge.trt, 
                  title = 'sPLSDA-batch', 
                  trt.legend.title = 'Tissue')
sponge.pca.PN.plot <- 
  Scatter_Density(object = sponge.pca.PN, 
                  batch = sponge.batch, 
                  trt = sponge.trt, 
                  title = 'Percentile Normalisation', 
                  trt.legend.title = 'Tissue')

## ----Spongepca, fig.height = 13, fig.width = 12, out.width = '100%', echo = F, fig.align = 'center', fig.cap = 'Figure 4: The PCA sample plots with densities before and after batch effect correction in the sponge data.'----
grid.arrange(sponge.pca.before.plot, sponge.pca.rBE.plot, 
             sponge.pca.ComBat.plot, sponge.pca.PLSDA_batch.plot, 
             sponge.pca.sPLSDA_batch.plot, sponge.pca.PN.plot, ncol = 2)

## ----Spongeprda, fig.height = 6, fig.align = 'center', fig.cap = 'Figure 5: Global explained variance before and after batch effect correction for the sponge data.'----
sponge.corrected.list <- list(`Before correction` = sponge.clr, 
                              removeBatchEffect = sponge.rBE, 
                              ComBat = sponge.ComBat, 
                              `PLSDA-batch` = sponge.PLSDA_batch, 
                              `sPLSDA-batch` = sponge.sPLSDA_batch, 
                              `Percentile Normalisation` = sponge.PN)

sponge.prop.df <- data.frame(Treatment = NA, Batch = NA, 
                             Intersection = NA, 
                             Residuals = NA) 
for(i in 1:length(sponge.corrected.list)){
  rda.res = varpart(sponge.corrected.list[[i]], ~ trt, ~ batch,
                    data = sponge.factors.df, scale = T)
  sponge.prop.df[i, ] <- rda.res$part$indfract$Adj.R.squared}

rownames(sponge.prop.df) = names(sponge.corrected.list)

sponge.prop.df <- sponge.prop.df[, c(1,3,2,4)]

sponge.prop.df[sponge.prop.df < 0] = 0
sponge.prop.df <- as.data.frame(t(apply(sponge.prop.df, 1, 
                                        function(x){x/sum(x)})))


partVar_plot(prop.df = sponge.prop.df)


## ----Sponger2_1, fig.height = 10, fig.width = 14, out.width = '100%', fig.align = 'center', fig.cap = 'Figure 6: Sponge study: $R^2$ values for each microbial variable before and after batch effect correction.'----
# scale
sponge.corr_scale.list <- lapply(sponge.corrected.list, 
                                 function(x){apply(x, 2, scale)})

sponge.r_values.list <- list()
for(i in 1:length(sponge.corr_scale.list)){
  sponge.r_values <- data.frame(trt = NA, batch = NA)
  for(c in 1:ncol(sponge.corr_scale.list[[i]])){
    sponge.fit.res.trt <- lm(sponge.corr_scale.list[[i]][,c] ~ sponge.trt)
    sponge.r_values[c,1] <- summary(sponge.fit.res.trt)$r.squared
    sponge.fit.res.batch <- lm(sponge.corr_scale.list[[i]][,c] ~ sponge.batch)
    sponge.r_values[c,2] <- summary(sponge.fit.res.batch)$r.squared
  }
  sponge.r_values.list[[i]] <- sponge.r_values
}
names(sponge.r_values.list) <- names(sponge.corr_scale.list)

sponge.boxp.list <- list()
for(i in seq_len(length(sponge.r_values.list))){
  sponge.boxp.list[[i]] <- 
    data.frame(r2 = c(sponge.r_values.list[[i]][ ,'trt'],
                      sponge.r_values.list[[i]][ ,'batch']), 
               Effects = as.factor(rep(c('Treatment','Batch'), 
                                       each = 24)))
}
names(sponge.boxp.list) <- names(sponge.r_values.list)

sponge.r2.boxp <- rbind(sponge.boxp.list$`Before correction`,
                        sponge.boxp.list$removeBatchEffect,
                        sponge.boxp.list$ComBat,
                        sponge.boxp.list$`PLSDA-batch`,
                        sponge.boxp.list$`sPLSDA-batch`,
                        sponge.boxp.list$`Percentile Normalisation`,
                        sponge.boxp.list$RUVIII)

sponge.r2.boxp$methods <- rep(c('Before correction', ' removeBatchEffect', 
                                'ComBat','PLSDA-batch', 'sPLSDA-batch',
                                'Percentile Normalisation'), each = 48)

sponge.r2.boxp$methods <- factor(sponge.r2.boxp$methods, 
                                 levels = unique(sponge.r2.boxp$methods))

ggplot(sponge.r2.boxp, aes(x = Effects, y = r2, fill = Effects)) +
  geom_boxplot(alpha = 0.80) +
  theme_bw() + 
  theme(text = element_text(size = 18),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        axis.text.x = element_text(angle = 60, hjust = 1, size = 18),
        axis.text.y = element_text(size = 18),
        panel.grid.minor.x = element_blank(),
        panel.grid.major.x = element_blank(),
        legend.position = "right") + facet_grid( ~ methods) + 
  scale_fill_manual(values=pb_color(c(12,14))) 

## ----Sponger2_2, fig.height = 10, fig.width = 14, out.width = '100%', fig.align = 'center', fig.cap = 'Figure 7: Sponge study: the sum of $R^2$ values for each microbial variable before and after batch effect correction.'----
##################################
sponge.barp.list <- list()
for(i in seq_len(length(sponge.r_values.list))){
  sponge.barp.list[[i]] <- 
    data.frame(r2 = c(sum(sponge.r_values.list[[i]][ ,'trt']),
                      sum(sponge.r_values.list[[i]][ ,'batch'])), 
               Effects = c('Treatment','Batch'))
}
names(sponge.barp.list) <- names(sponge.r_values.list)

sponge.r2.barp <- rbind(sponge.barp.list$`Before correction`,
                        sponge.barp.list$removeBatchEffect,
                        sponge.barp.list$ComBat,
                        sponge.barp.list$`PLSDA-batch`,
                        sponge.barp.list$`sPLSDA-batch`,
                        sponge.barp.list$`Percentile Normalisation`,
                        sponge.barp.list$RUVIII)


sponge.r2.barp$methods <- rep(c('Before correction', ' removeBatchEffect', 
                                'ComBat','PLSDA-batch', 'sPLSDA-batch',
                                'Percentile Normalisation'), each = 2)

sponge.r2.barp$methods <- factor(sponge.r2.barp$methods, 
                                 levels = unique(sponge.r2.barp$methods))


ggplot(sponge.r2.barp, aes(x = Effects, y = r2, fill = Effects)) +
  geom_bar(stat="identity") + 
  theme_bw() + 
  theme(text = element_text(size = 18),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        axis.text.x = element_text(angle = 60, hjust = 1, size = 18),
        axis.text.y = element_text(size = 18),
        panel.grid.minor.x = element_blank(),
        panel.grid.major.x = element_blank(),
        legend.position = "right") + facet_grid( ~ methods) + 
  scale_fill_manual(values=pb_color(c(12,14)))


## ----Spongealignment, fig.align = 'center', fig.cap = 'Figure 8: Comparison of alignment scores before and after batch effect correction using different methods for the sponge data.'----
sponge.var = 0.95
sponge.k = 3

sponge.scores <- c()
for(i in 1:length(sponge.corrected.list)){
  res <- alignment_score(data = sponge.corrected.list[[i]], 
                         batch = sponge.batch, 
                         var = sponge.var, 
                         k = sponge.k, 
                         ncomp = 20)
  sponge.scores <- c(sponge.scores, res)
}

sponge.scores.df <- data.frame(scores = sponge.scores, 
                               methods = names(sponge.corrected.list))

sponge.scores.df$methods <- factor(sponge.scores.df$methods, 
                                   levels = rev(names(sponge.corrected.list)))


ggplot() + geom_col(aes(x = sponge.scores.df$methods, 
                        y = sponge.scores.df$scores)) + 
  geom_text(aes(x = sponge.scores.df$methods, 
                y = sponge.scores.df$scores/2, 
                label = round(sponge.scores.df$scores, 3)), 
            size = 3, col = 'white') + 
  coord_flip() + theme_bw() + ylab('Alignment Scores') + 
  xlab('') + ylim(0,0.4)

## ----SpongeupsetR, out.width = '100%', fig.align = 'center', fig.cap = 'Figure 9: UpSet plot showing overlap between variables selected from different corrected data for the sponge study.'----
sponge.splsda.select <- list()
for(i in 1:length(sponge.corrected.list)){
  splsda.res <- splsda(X = sponge.corrected.list[[i]], 
                       Y = sponge.trt, 
                       ncomp = 3, keepX = rep(5,3))
  select.res <- selectVar(splsda.res, comp = 1)$name
  sponge.splsda.select[[i]] <- select.res
}
names(sponge.splsda.select) <- names(sponge.corrected.list)

# can only visualise 5 methods
sponge.splsda.select <- sponge.splsda.select[c(1:5)]

sponge.splsda.upsetR <- fromList(sponge.splsda.select)

upset(sponge.splsda.upsetR, main.bar.color = 'gray36',
      sets.bar.color = pb_color(c(25:22,20)), matrix.color = 'gray36',
      order.by = 'freq', empty.intersections = 'on',
      queries = 
        list(list(query = intersects, params = list('Before correction'), 
                  color = pb_color(20), active = T),
             list(query = intersects, params = list('removeBatchEffect'), 
                  color = pb_color(22), active = T),
             list(query = intersects, params = list('ComBat'), 
                  color = pb_color(23), active = T),
             list(query = intersects, params = list('PLSDA-batch'), 
                  color = pb_color(24), active = T),
             list(query = intersects, params = list('sPLSDA-batch'), 
                  color = pb_color(25), active = T)))


## -----------------------------------------------------------------------------
data('HFHS_data') 
hfhs.count <- HFHS_data$FullData$X.count
dim(hfhs.count)

hfhs.filter.res <- PreFL(data = hfhs.count)
hfhs.filter <- hfhs.filter.res$data.filter
dim(hfhs.filter)

# zero proportion before filtering
hfhs.filter.res$zero.prob
# zero proportion after filtering
sum(hfhs.filter == 0)/(nrow(hfhs.filter) * ncol(hfhs.filter))

## -----------------------------------------------------------------------------
hfhs.clr <- logratio.transfo(X = hfhs.filter, logratio = 'CLR', offset = 1)

class(hfhs.clr) <- 'matrix'

## ----HFHSpcaBefore1, fig.align = 'center', fig.cap = 'Figure 10: The PCA sample plot with densities coloured by cages in the HFHS data.'----
hfhs.pca.before <- pca(hfhs.clr, ncomp = 3, scale = TRUE)

hfhs.metadata <- HFHS_data$FullData$metadata
rownames(hfhs.metadata) <- hfhs.metadata$SampleID
hfhs.metadata <- hfhs.metadata[rownames(hfhs.clr),]

hfhs.cage <- as.factor(hfhs.metadata$DietCage)
hfhs.day <- as.factor(hfhs.metadata$Day)
hfhs.trt <- as.factor(hfhs.metadata$Diet)
names(hfhs.cage) = names(hfhs.day) = names(hfhs.trt) = hfhs.metadata$SampleID

hfhs.pca.before.cage.plot <- 
  Scatter_Density(object = hfhs.pca.before, 
                  batch = hfhs.cage, 
                  trt = hfhs.trt, 
                  title = 'HFHS data', 
                  trt.legend.title = 'Diet',
                  batch.legend.title = 'Cage')

## ----HFHSpcaBefore2, fig.align = 'center', fig.cap = 'Figure 11: The PCA sample plot with densities coloured by days in the HFHS data.'----
hfhs.pca.before.day.plot <- 
  Scatter_Density(object = hfhs.pca.before, 
                  batch = hfhs.day, 
                  trt = hfhs.trt, 
                  title = 'HFHS data', 
                  trt.legend.title = 'Diet',
                  batch.legend.title = 'Day')

## ----HFHSpcaBeforeNew1, fig.align = 'center', fig.cap = 'Figure 12: The PCA sample plot with densities coloured by cages in the reduced HFHS data.'----
# remove samples from arrival day and day0
hfhs.dA0.idx <- c(which(hfhs.day == 'A'), which(hfhs.day == 'Day0'))
hfhs.clr.less <- hfhs.clr[-hfhs.dA0.idx,]
hfhs.metadata.less <- hfhs.metadata[-hfhs.dA0.idx,]

hfhs.cage.less <- as.factor(hfhs.metadata.less$DietCage)
hfhs.day.less <- as.factor(hfhs.metadata.less$Day)
hfhs.trt.less <- as.factor(hfhs.metadata.less$Diet)
names(hfhs.cage.less) = names(hfhs.day.less) = 
  names(hfhs.trt.less) = hfhs.metadata.less$SampleID

hfhs.less.pca.before <- pca(hfhs.clr.less, ncomp = 3, scale = TRUE)

hfhs.less.pca.before.cage.plot <- 
  Scatter_Density(object = hfhs.less.pca.before, 
                  batch = hfhs.cage.less, 
                  trt = hfhs.trt.less, 
                  title = 'HFHS data', 
                  trt.legend.title = 'Diet',
                  batch.legend.title = 'Cage')

## ----HFHSpcaBeforeNew2, fig.align = 'center', fig.cap = 'Figure 13: The PCA sample plot with densities coloured by days in the reduced HFHS data.'----
hfhs.less.pca.before.day.plot <- 
  Scatter_Density(object = hfhs.less.pca.before, 
                  batch = hfhs.day.less, 
                  trt = hfhs.trt.less, 
                  title = 'HFHS data', 
                  trt.legend.title = 'Diet',
                  batch.legend.title = 'Day')

## ----HFHSheatmapS, out.width = '90%', fig.align = 'center', fig.cap = 'Figure 14: Hierarchical clustering for samples in the HFHS data.'----
# scale the clr data on both OTUs and samples
hfhs.clr.s <- scale(hfhs.clr.less, center = T, scale = T)
hfhs.clr.ss <- scale(t(hfhs.clr.s), center = T, scale = T)

# The cage effect
hfhs.anno_col <- data.frame(Cage = hfhs.cage.less, 
                            Day = hfhs.day.less, 
                            Treatment = hfhs.trt.less)
hfhs.anno_colors <- list(Cage = color.mixo(1:8), 
                         Day = color.mixo(1:3),
                         Treatment = pb_color(1:2))
names(hfhs.anno_colors$Cage) = levels(hfhs.cage.less)
names(hfhs.anno_colors$Day) = levels(hfhs.day.less)
names(hfhs.anno_colors$Treatment) = levels(hfhs.trt.less)

pheatmap(hfhs.clr.ss, 
         cluster_rows = F, 
         fontsize_row = 4, 
         fontsize_col = 6,
         fontsize = 8,
         clustering_distance_rows = 'euclidean',
         clustering_method = 'ward.D',
         treeheight_row = 30,
         annotation_col = hfhs.anno_col,
         annotation_colors = hfhs.anno_colors,
         border_color = 'NA',
         main = 'HFHS data - Scaled')


## -----------------------------------------------------------------------------
hfhs.factors.df <- data.frame(trt = hfhs.trt.less, 
                              cage = hfhs.cage.less, 
                              day = hfhs.day.less)
hfhs.rda.cage.before <- varpart(hfhs.clr.less, ~ trt, ~ cage, 
                                data = hfhs.factors.df, scale = T)
hfhs.rda.cage.before$part$indfract

## -----------------------------------------------------------------------------
hfhs.rda.day.before <- varpart(hfhs.clr.less, ~ trt, ~ day, 
                               data = hfhs.factors.df, scale = T)
hfhs.rda.day.before$part$indfract

## -----------------------------------------------------------------------------
# Creating a MRexperiment object (make sure no NA in metadata)
rownames(HFHS_data$FullData$metadata) <- rownames(HFHS_data$FullData$X.count)
HFHS.phenotypeData = 
  AnnotatedDataFrame(data = HFHS_data$FullData$metadata[-hfhs.dA0.idx,])
HFHS.taxaData = 
  AnnotatedDataFrame(data = as.data.frame(HFHS_data$FullData$taxa))
HFHS.obj = newMRexperiment(counts = 
                             t(HFHS_data$FullData$X.count[-hfhs.dA0.idx,]),
                           phenoData = HFHS.phenotypeData, 
                           featureData = HFHS.taxaData)
HFHS.obj

## -----------------------------------------------------------------------------
# filtering data to maintain a threshold of minimum depth or OTU presence
dim(MRcounts(HFHS.obj))
HFHS.obj = filterData(obj = HFHS.obj, present = 20, depth = 5)
dim(MRcounts(HFHS.obj))

## -----------------------------------------------------------------------------
# calculate the percentile for CSS normalisation
HFHS.pctl = cumNormStatFast(obj = HFHS.obj)
# CSS normalisation
HFHS.obj <- cumNorm(obj = HFHS.obj, p = HFHS.pctl)
# export normalised data
HFHS.norm.data <- MRcounts(obj = HFHS.obj, norm = TRUE)

# normalisation scaling factors for each sample 
HFHS.normFactor = normFactors(object = HFHS.obj)
HFHS.normFactor = log2(HFHS.normFactor/median(HFHS.normFactor) + 1)

## -----------------------------------------------------------------------------
# treatment variable
Diet_effect = pData(object = HFHS.obj)$Diet

# batch variable
Day_effect = pData(object = HFHS.obj)$Day

# build a design matrix
HFHS.mod.full = model.matrix(~ Diet_effect + Day_effect + HFHS.normFactor)

# settings for the fitZig() function
HFHS.settings <- zigControl(maxit = 10, verbose = TRUE)

# apply the ZIG model
HFHSfit <- fitZig(obj = HFHS.obj, mod = HFHS.mod.full, 
                  useCSSoffset = FALSE, control = HFHS.settings)


## -----------------------------------------------------------------------------
HFHScoefs <- MRcoefs(HFHSfit, coef = 2, group = 3, number = 50, eff = 0.5)
head(HFHScoefs)

## ----HFHSlm, fig.height = 13, fig.width = 12, out.width = '100%', fig.align = 'center', fig.cap = 'Figure 15: Diagnostic plots for the model fitted with the day effect of "OTU 541135" in the HFHS data.'----
hfhs.lm <- linear_regres(data = hfhs.clr.less, 
                         trt = hfhs.trt.less, 
                         batch.fix = hfhs.day.less, 
                         type = 'linear model')

hfhs.p <- sapply(hfhs.lm$lm.table, function(x){x$coefficients[2,4]})
hfhs.p.adj <- p.adjust(p = hfhs.p, method = 'fdr')

check_model(hfhs.lm$model$`541135`)

## -----------------------------------------------------------------------------
head(hfhs.lm$adj.R2)

## -----------------------------------------------------------------------------
head(hfhs.lm$AIC)

## ---- results = 'hide'--------------------------------------------------------
hfhs.lmm <- linear_regres(data = hfhs.clr.less, 
                          trt = hfhs.trt.less, 
                          batch.fix = hfhs.day.less, 
                          batch.random = hfhs.cage.less,
                          type = 'linear mixed model')

## ----HFHSlmm, fig.height = 13, fig.width = 12, out.width = '100%', fig.align = 'center', fig.cap = 'Figure 16: Diagnostic plots for the model fitted with the day and cage effects of "OTU541135" in the HFHS data.'----
hfhs.p <- sapply(hfhs.lmm$lmm.table, function(x){x$coefficients[2,5]})
hfhs.p.adj <- p.adjust(p = hfhs.p, method = 'fdr')

check_model(hfhs.lmm$model$`541135`)

## -----------------------------------------------------------------------------
head(hfhs.lmm$AIC)

## ---- fig.height = 13, fig.width = 12, out.width = '100%'---------------------
head(hfhs.lmm$cond.R2)
head(hfhs.lmm$marg.R2)

## -----------------------------------------------------------------------------
# estimate batch matrix
hfhs.mod <- model.matrix( ~ hfhs.trt.less)
hfhs.mod0 <- model.matrix( ~ 1, data = hfhs.trt.less)
hfhs.sva.n <- num.sv(dat = t(hfhs.clr.less), mod = hfhs.mod, 
                     method = 'leek')
hfhs.sva <- sva(t(hfhs.clr.less), hfhs.mod, hfhs.mod0, n.sv = hfhs.sva.n)

## -----------------------------------------------------------------------------
# include estimated batch effects in the linear model
hfhs.mod.batch <- cbind(hfhs.mod, hfhs.sva$sv)
hfhs.mod0.batch <- cbind(hfhs.mod0, hfhs.sva$sv)
hfhs.sva.p <- f.pvalue(t(hfhs.clr.less), hfhs.mod.batch, hfhs.mod0.batch)
hfhs.sva.p.adj <- p.adjust(hfhs.sva.p, method = 'fdr')

## -----------------------------------------------------------------------------
# empirical negative controls
hfhs.empir.p <- c()
for(e in 1:ncol(hfhs.clr.less)){
  hfhs.empir.lm <- lm(hfhs.clr.less[,e] ~ hfhs.trt.less)
  hfhs.empir.p[e] <- summary(hfhs.empir.lm)$coefficients[2,4]
}
hfhs.empir.p.adj <- p.adjust(p = hfhs.empir.p, method = 'fdr')
hfhs.nc <- hfhs.empir.p.adj > 0.05

## -----------------------------------------------------------------------------
# estimate k
hfhs.k.res <- getK(Y = hfhs.clr.less, X = hfhs.trt.less, ctl = hfhs.nc)
hfhs.k <- hfhs.k.res$k
hfhs.k <- ifelse(hfhs.k != 0, hfhs.k, 1)

## -----------------------------------------------------------------------------
hfhs.ruv4 <- RUV4(Y = hfhs.clr.less, X = hfhs.trt.less, 
                  ctl = hfhs.nc, k = hfhs.k) 
hfhs.ruv4.p <- hfhs.ruv4$p
hfhs.ruv4.p.adj <- p.adjust(hfhs.ruv4.p, method = "fdr")

## -----------------------------------------------------------------------------
hfhs.rBE <- t(removeBatchEffect(t(hfhs.clr.less), batch = hfhs.day.less, 
                                design = hfhs.mod))

## -----------------------------------------------------------------------------
hfhs.ComBat <- t(ComBat(t(hfhs.clr.less), batch = hfhs.day.less, 
                        mod = hfhs.mod, par.prior = F))

## -----------------------------------------------------------------------------
# estimate the number of treatment components
hfhs.trt.tune <- plsda(X = hfhs.clr.less, Y = hfhs.trt.less, ncomp = 5)
hfhs.trt.tune$prop_expl_var #1

## -----------------------------------------------------------------------------
# estimate the number of batch components
hfhs.batch.tune <- PLSDA_batch(X = hfhs.clr.less, 
                               Y.trt = hfhs.trt.less, 
                               Y.bat = hfhs.day.less,
                               ncomp.trt = 1, ncomp.bat = 10)
hfhs.batch.tune$explained_variance.bat #2
sum(hfhs.batch.tune$explained_variance.bat$Y[1:2])

## -----------------------------------------------------------------------------
##########
hfhs.PLSDA_batch.res <- PLSDA_batch(X = hfhs.clr.less, 
                                    Y.trt = hfhs.trt.less, 
                                    Y.bat = hfhs.day.less,
                                    ncomp.trt = 1, ncomp.bat = 2)
hfhs.PLSDA_batch <- hfhs.PLSDA_batch.res$X.nobatch

## -----------------------------------------------------------------------------
# estimate the number of variables to select per treatment component
set.seed(777)
hfhs.test.keepX = c(seq(1, 10, 1), seq(20, 200, 10), 
                    seq(250, 500, 50), 515)
hfhs.trt.tune.v <- tune.splsda(X = hfhs.clr.less, 
                               Y = hfhs.trt.less, 
                               ncomp = 1, 
                               test.keepX = hfhs.test.keepX, 
                               validation = 'Mfold', 
                               folds = 4, nrepeat = 50)
hfhs.trt.tune.v$choice.keepX # 2

## -----------------------------------------------------------------------------
# estimate the number of batch components
hfhs.batch.tune <- PLSDA_batch(X = hfhs.clr.less, 
                               Y.trt = hfhs.trt.less, 
                               Y.bat = hfhs.day.less,
                               ncomp.trt = 1, 
                               keepX.trt = 2,
                               ncomp.bat = 10)
hfhs.batch.tune$explained_variance.bat #2
sum(hfhs.batch.tune$explained_variance.bat$Y[1:2])

## -----------------------------------------------------------------------------
##########
hfhs.sPLSDA_batch.res <- PLSDA_batch(X = hfhs.clr.less, 
                                     Y.trt = hfhs.trt.less, 
                                     Y.bat = hfhs.day.less,
                                     ncomp.trt = 1, 
                                     keepX.trt = 2,
                                     ncomp.bat = 2)
hfhs.sPLSDA_batch <- hfhs.sPLSDA_batch.res$X.nobatch

## -----------------------------------------------------------------------------
# HFHS data
hfhs.PN <- percentile_norm(data = hfhs.clr.less, 
                           batch = hfhs.day.less, 
                           trt = hfhs.trt.less, 
                           ctrl.grp = 'Normal')

## -----------------------------------------------------------------------------
hfhs.replicates <- hfhs.metadata.less$MouseID
hfhs.replicates.matrix <- replicate.matrix(hfhs.replicates)

hfhs.RUVIII <- RUVIII(Y = hfhs.clr.less, 
                      M = hfhs.replicates.matrix, 
                      ctl = hfhs.nc, k = hfhs.k)
rownames(hfhs.RUVIII) <- rownames(hfhs.clr.less)

## -----------------------------------------------------------------------------
hfhs.pca.before <- pca(hfhs.clr.less, ncomp = 3, 
                       scale = TRUE)
hfhs.pca.rBE <- pca(hfhs.rBE, ncomp = 3, 
                    scale = TRUE)
hfhs.pca.ComBat <- pca(hfhs.ComBat, ncomp = 3, 
                       scale = TRUE)
hfhs.pca.PLSDA_batch <- pca(hfhs.PLSDA_batch, ncomp = 3, 
                            scale = TRUE)
hfhs.pca.sPLSDA_batch <- pca(hfhs.sPLSDA_batch, ncomp = 3, 
                             scale = TRUE)
hfhs.pca.PN <- pca(hfhs.PN, ncomp = 3, 
                   scale = TRUE)
hfhs.pca.RUVIII <- pca(hfhs.RUVIII, ncomp = 3, 
                       scale = TRUE)

## ---- fig.show='hide'---------------------------------------------------------
hfhs.pca.before.plot <- 
  Scatter_Density(object = hfhs.pca.before, 
                  batch = hfhs.day.less, 
                  trt = hfhs.trt.less, 
                  title = 'Before')
hfhs.pca.rBE.plot <- 
  Scatter_Density(object = hfhs.pca.rBE, 
                  batch = hfhs.day.less, 
                  trt = hfhs.trt.less, 
                  title = 'removeBatchEffect')
hfhs.pca.ComBat.plot <- 
  Scatter_Density(object = hfhs.pca.ComBat, 
                  batch = hfhs.day.less, 
                  trt = hfhs.trt.less,
                  title = 'ComBat')
hfhs.pca.PLSDA_batch.plot <- 
  Scatter_Density(object = hfhs.pca.PLSDA_batch, 
                  batch = hfhs.day.less, 
                  trt = hfhs.trt.less, 
                  title = 'PLSDA-batch')
hfhs.pca.sPLSDA_batch.plot <- 
  Scatter_Density(object = hfhs.pca.sPLSDA_batch, 
                  batch = hfhs.day.less, 
                  trt = hfhs.trt.less, 
                  title = 'sPLSDA-batch')
hfhs.pca.PN.plot <- 
  Scatter_Density(object = hfhs.pca.PN, 
                  batch = hfhs.day.less, 
                  trt = hfhs.trt.less, 
                  title = 'Percentile Normalisation')
hfhs.pca.RUVIII.plot <- 
  Scatter_Density(object = hfhs.pca.RUVIII, 
                  batch = hfhs.day.less, 
                  trt = hfhs.trt.less, 
                  title = 'RUVIII')

## ----HFHSpca, fig.height = 17, fig.width = 12, out.width = '100%', echo = F, fig.align = 'center', fig.cap = 'Figure 17: The PCA sample plots with densities before and after batch effect correction in the HFHS data.'----
grid.arrange(hfhs.pca.before.plot, hfhs.pca.rBE.plot, 
             hfhs.pca.ComBat.plot, hfhs.pca.PLSDA_batch.plot, 
             hfhs.pca.sPLSDA_batch.plot, hfhs.pca.PN.plot, 
             hfhs.pca.RUVIII.plot, ncol = 2)

## ----HFHSprda, fig.height = 6, fig.align = 'center', fig.cap = 'Figure 18: Global explained variance before and after batch effect correction for the HFHS data.'----
# HFHS data
hfhs.corrected.list <- list(`Before correction` = hfhs.clr.less, 
                            removeBatchEffect = hfhs.rBE, 
                            ComBat = hfhs.ComBat, 
                            `PLSDA-batch` = hfhs.PLSDA_batch,
                            `sPLSDA-batch` = hfhs.sPLSDA_batch, 
                            `Percentile Normalisation` = hfhs.PN,
                            RUVIII = hfhs.RUVIII)

hfhs.prop.df <- data.frame(Treatment = NA, Batch = NA, 
                           Intersection = NA, 
                           Residuals = NA) 
for(i in 1:length(hfhs.corrected.list)){
  rda.res = varpart(hfhs.corrected.list[[i]], ~ trt, ~ day,
                    data = hfhs.factors.df, scale = T)
  hfhs.prop.df[i, ] <- rda.res$part$indfract$Adj.R.squared}

rownames(hfhs.prop.df) = names(hfhs.corrected.list)

hfhs.prop.df <- hfhs.prop.df[, c(1,3,2,4)]

hfhs.prop.df[hfhs.prop.df < 0] = 0
hfhs.prop.df <- as.data.frame(t(apply(hfhs.prop.df, 1, 
                                      function(x){x/sum(x)})))


partVar_plot(prop.df = hfhs.prop.df)

## ----HFHSr2_1, fig.height = 10, fig.width = 14, out.width = '100%', fig.align = 'center', fig.cap = 'Figure 19: HFHS study: $R^2$ values for each microbial variable before and after batch effect correction.'----
# scale
hfhs.corr_scale.list <- lapply(hfhs.corrected.list, 
                               function(x){apply(x, 2, scale)})

# HFHS data
hfhs.r_values.list <- list()
for(i in 1:length(hfhs.corr_scale.list)){
  hfhs.r_values <- data.frame(trt = NA, batch = NA)
  for(c in 1:ncol(hfhs.corr_scale.list[[i]])){
    hfhs.fit.res.trt <- lm(hfhs.corr_scale.list[[i]][,c] ~ hfhs.trt.less)
    hfhs.r_values[c,1] <- summary(hfhs.fit.res.trt)$r.squared
    hfhs.fit.res.batch <- lm(hfhs.corr_scale.list[[i]][,c] ~ hfhs.day.less)
    hfhs.r_values[c,2] <- summary(hfhs.fit.res.batch)$r.squared
  }
  hfhs.r_values.list[[i]] <- hfhs.r_values
}
names(hfhs.r_values.list) <- names(hfhs.corr_scale.list)

hfhs.boxp.list <- list()
for(i in seq_len(length(hfhs.r_values.list))){
  hfhs.boxp.list[[i]] <- 
    data.frame(r2 = c(hfhs.r_values.list[[i]][ ,'trt'],
                      hfhs.r_values.list[[i]][ ,'batch']), 
               Effects = as.factor(rep(c('Treatment','Batch'), 
                                       each = 515)))
}
names(hfhs.boxp.list) <- names(hfhs.r_values.list)

hfhs.r2.boxp <- rbind(hfhs.boxp.list$`Before correction`,
                      hfhs.boxp.list$removeBatchEffect,
                      hfhs.boxp.list$ComBat,
                      hfhs.boxp.list$`PLSDA-batch`,
                      hfhs.boxp.list$`sPLSDA-batch`,
                      hfhs.boxp.list$`Percentile Normalisation`,
                      hfhs.boxp.list$RUVIII)

hfhs.r2.boxp$methods <- rep(c('Before correction', ' removeBatchEffect', 
                              'ComBat','PLSDA-batch', 'sPLSDA-batch',
                              'Percentile Normalisation', 'RUVIII'), 
                            each = 1030)

hfhs.r2.boxp$methods <- factor(hfhs.r2.boxp$methods, 
                               levels = unique(hfhs.r2.boxp$methods))

ggplot(hfhs.r2.boxp, aes(x = Effects, y = r2, fill = Effects)) +
  geom_boxplot(alpha = 0.80) +
  theme_bw() + 
  theme(text = element_text(size = 18),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        axis.text.x = element_text(angle = 60, hjust = 1, size = 18),
        axis.text.y = element_text(size = 18),
        panel.grid.minor.x = element_blank(),
        panel.grid.major.x = element_blank(),
        legend.position = "right") + facet_grid( ~ methods) + 
  scale_fill_manual(values=pb_color(c(12,14))) 

## ----HFHSr2_2, fig.height = 10, fig.width = 14, out.width = '100%', fig.align = 'center', fig.cap = 'Figure 20: HFHS study: the sum of $R^2$ values for each microbial variable before and after batch effect correction.'----
##################################
hfhs.barp.list <- list()
for(i in seq_len(length(hfhs.r_values.list))){
  hfhs.barp.list[[i]] <- 
    data.frame(r2 = c(sum(hfhs.r_values.list[[i]][ ,'trt']),
                      sum(hfhs.r_values.list[[i]][ ,'batch'])), 
               Effects = c('Treatment','Batch'))
}
names(hfhs.barp.list) <- names(hfhs.r_values.list)

hfhs.r2.barp <- rbind(hfhs.barp.list$`Before correction`,
                      hfhs.barp.list$removeBatchEffect,
                      hfhs.barp.list$ComBat,
                      hfhs.barp.list$`PLSDA-batch`,
                      hfhs.barp.list$`sPLSDA-batch`,
                      hfhs.barp.list$`Percentile Normalisation`,
                      hfhs.barp.list$RUVIII)


hfhs.r2.barp$methods <- rep(c('Before correction', ' removeBatchEffect', 
                              'ComBat','PLSDA-batch', 'sPLSDA-batch',
                              'Percentile Normalisation', 'RUVIII'), each = 2)

hfhs.r2.barp$methods <- factor(hfhs.r2.barp$methods, 
                               levels = unique(hfhs.r2.barp$methods))


ggplot(hfhs.r2.barp, aes(x = Effects, y = r2, fill = Effects)) +
  geom_bar(stat="identity") + 
  theme_bw() + 
  theme(text = element_text(size = 18),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        axis.text.x = element_text(angle = 60, hjust = 1, size = 18),
        axis.text.y = element_text(size = 18),
        panel.grid.minor.x = element_blank(),
        panel.grid.major.x = element_blank(),
        legend.position = "right") + facet_grid( ~ methods) + 
  scale_fill_manual(values=pb_color(c(12,14)))


## ----HFHSalignment, fig.align = 'center', fig.cap = 'Figure 21: Comparison of alignment scores before and after batch effect correction using different methods for the HFHS data.'----
# HFHS data
hfhs.var = 0.95
hfhs.k = 15

hfhs.scores <- c()
for(i in 1:length(hfhs.corrected.list)){
  res <- alignment_score(data = hfhs.corrected.list[[i]], 
                         batch = hfhs.day.less, 
                         var = hfhs.var, 
                         k = hfhs.k, 
                         ncomp = 130)
  hfhs.scores <- c(hfhs.scores, res)
}

hfhs.scores.df <- data.frame(scores = hfhs.scores, 
                             methods = names(hfhs.corrected.list))

hfhs.scores.df$methods <- factor(hfhs.scores.df$methods, 
                                 levels = rev(names(hfhs.corrected.list)))


ggplot() + geom_col(aes(x = hfhs.scores.df$methods, 
                        y = hfhs.scores.df$scores)) + 
  geom_text(aes(x = hfhs.scores.df$methods, 
                y = hfhs.scores.df$scores/2, 
                label = round(hfhs.scores.df$scores, 3)), 
            size = 3, col = 'white') + 
  coord_flip() + theme_bw() + ylab('Alignment Scores') + 
  xlab('') + ylim(0,0.85)

## ---- HFHSupsetR, out.width = '100%', fig.align = 'center', fig.cap = 'Figure 22: UpSet plot showing overlap between variables selected from different corrected data for the HFHS study.'----
hfhs.splsda.select <- list()
for(i in 1:length(hfhs.corrected.list)){
  splsda.res <- splsda(X = hfhs.corrected.list[[i]],
                       Y = hfhs.trt.less, 
                       ncomp = 3, keepX = rep(50,3))
  select.res <- selectVar(splsda.res, comp = 1)$name
  hfhs.splsda.select[[i]] <- select.res
}
names(hfhs.splsda.select) <- names(hfhs.corrected.list)

# can only visualise 5 methods
hfhs.splsda.select <- hfhs.splsda.select[c(1:4,7)]

hfhs.splsda.upsetR <- fromList(hfhs.splsda.select)

upset(hfhs.splsda.upsetR, main.bar.color = 'gray36',
      sets.bar.color = pb_color(c(25:22,20)), matrix.color = 'gray36',
      order.by = 'freq', empty.intersections = 'on',
      queries = 
        list(list(query = intersects, params = list('Before correction'), 
                  color = pb_color(20), active = T),
             list(query = intersects, params = list('removeBatchEffect'), 
                  color = pb_color(22), active = T),
             list(query = intersects, params = list('ComBat'), 
                  color = pb_color(23), active = T),
             list(query = intersects, params = list('PLSDA-batch'), 
                  color = pb_color(24), active = T),
             list(query = intersects, params = list('RUVIII'), 
                  color = pb_color(25), active = T)))


## -----------------------------------------------------------------------------
hfhs.splsda.select.overlap <- venn(hfhs.splsda.select, show.plot = F)
hfhs.inters.splsda <- attr(hfhs.splsda.select.overlap, 'intersections')
hfhs.inters.splsda.taxa <- 
  lapply(hfhs.inters.splsda, 
         FUN = function(x){as.data.frame(HFHS_data$FullData$taxa[x, ])})
capture.output(hfhs.inters.splsda.taxa, 
               file = "GeneratedData/HFHSselected_50_splsda.txt")

## -----------------------------------------------------------------------------
data('HD_data') 
hd.count <- HD_data$FullData$X.count
dim(hd.count)

hd.filter.res <- PreFL(data = hd.count)
hd.filter <- hd.filter.res$data.filter
dim(hd.filter)

# zero proportion before filtering
hd.filter.res$zero.prob
# zero proportion after filtering
sum(hd.filter == 0)/(nrow(hd.filter) * ncol(hd.filter))

## -----------------------------------------------------------------------------
hd.clr <- logratio.transfo(X = hd.filter, logratio = 'CLR', offset = 1)

class(hd.clr) <- 'matrix'

## ----HDpcaBefore, fig.align = 'center', fig.cap = 'Figure 23: The PCA sample plot with densities in the HD data.'----
# HD data
hd.pca.before <- pca(hd.clr, ncomp = 3, scale = TRUE)

hd.metadata <- HD_data$FullData$metadata

hd.batch <- as.factor(hd.metadata$Cage)
hd.trt <- as.factor(hd.metadata$Genotype)
names(hd.batch) = names(hd.trt) = rownames(hd.metadata) 

Scatter_Density(object = hd.pca.before, 
                batch = hd.batch, 
                trt = hd.trt, 
                title = 'HD data', 
                trt.legend.title = 'Genotype', 
                batch.legend.title = 'Cage', legend.cex = 0.6)


## ---- HDheatmap, out.width = '90%', fig.align = 'center', fig.cap = 'Figure 24: Hierarchical clustering for samples in the HD data.'----
# scale the clr data on both OTUs and samples
hd.clr.s <- scale(hd.clr, center = T, scale = T)
hd.clr.ss <- scale(t(hd.clr.s), center = T, scale = T)

hd.anno_col <- data.frame(Cage = hd.batch, Genotype = hd.trt)
hd.anno_colors <- list(Cage = color.mixo(1:10), 
                       Genotype = pb_color(1:2))
names(hd.anno_colors$Cage) = levels(hd.batch)
names(hd.anno_colors$Genotype) = levels(hd.trt)

pheatmap(hd.clr.ss, 
         cluster_rows = F, 
         fontsize_row = 4, 
         fontsize_col = 6,
         fontsize = 8,
         clustering_distance_rows = 'euclidean',
         clustering_method = 'ward.D',
         treeheight_row = 30,
         annotation_col = hd.anno_col,
         annotation_colors = hd.anno_colors,
         border_color = 'NA',
         main = 'HD data - Scaled')


## -----------------------------------------------------------------------------
hd.factors.df <- data.frame(trt = hd.trt, batch = hd.batch)
hd.rda.before <- varpart(hd.clr, ~ trt, ~ batch, 
                         data = hd.factors.df, scale = T)
hd.rda.before$part$indfract

## ---- results = 'hide'--------------------------------------------------------
# HD data
hd.clr <- hd.clr[1:nrow(hd.clr), 1:ncol(hd.clr)]

hd.lmm <- linear_regres(data = hd.clr, trt = hd.trt, 
                        batch.random = hd.batch, 
                        type = 'linear mixed model')

## ----HDlmmS, fig.height = 13, fig.width = 12, out.width = '100%', fig.align = 'center', fig.cap = 'Figure 25: Diagnostic plots for the model fitted with the cage effect of "OTU1" in the HD data.'----
hd.p <- sapply(hd.lmm$lmm.table, function(x){x$coefficients[2,5]})
hd.p.adj <- p.adjust(p = hd.p, method = 'fdr')

check_model(hd.lmm$model$OTU1)

## -----------------------------------------------------------------------------
head(hd.lmm$AIC)

## -----------------------------------------------------------------------------
head(hd.lmm$cond.R2)
head(hd.lmm$marg.R2)

