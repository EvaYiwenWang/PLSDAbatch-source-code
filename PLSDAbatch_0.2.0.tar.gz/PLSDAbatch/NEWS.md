# version 0.2.0

## new features / enhancements / changes

* new argument `color.set` to customise colors in function `Scatter_Density`, `box_plot` and `density_plot`

* new argument `batch.fix2` for a second batch fixed effect in function `linear_regres`

