## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(dpi = 300, echo = TRUE, warning = FALSE, message = FALSE, 
                      eval = TRUE, fig.show = TRUE, fig.width = 6, 
                      fig.height = 4, fig.align ='center', 
                      out.width = '60%', cache = FALSE)

## ---- include = FALSE---------------------------------------------------------
colorize <- function(x, color) {
  if (knitr::is_latex_output()) {
    sprintf("\\textcolor{%s}{%s}", color, x)
  } else if (knitr::is_html_output()) {
    htmlcolor = "black"
    if(color == "blue"){
      htmlcolor = "#0000FF"
    }
    if(color == "brown"){
      htmlcolor = "#964B00"
    }
    if(color == "olive"){
      htmlcolor = "#808000"
    }
    if(color == "violet"){
      htmlcolor = "#8601AF"
    }
    if(color == "orange"){
      htmlcolor = "#FF7F00"
    }
    sprintf("<span style='color: %s;'>%s</span>", htmlcolor, x)
  } else x
}

## -----------------------------------------------------------------------------
# CRAN
cran.pkgs <- c('pheatmap', 'vegan', 'ruv', 'UpSetR', 'gplots', 
               'ggplot2', 'gridExtra', 'performance')
# Bioconductor
bioc.pkgs <- c('mixOmics', 'sva', 'limma', 'Biobase', 'metagenomeSeq')
# GitHub
github.pkg <- 'PLSDAbatch' 
# devtools::install_github("https://github.com/EvaYiwenWang/PLSDAbatch")

# load packages 
sapply(c(cran.pkgs, bioc.pkgs, github.pkg), require, character.only = TRUE)

# print package versions
sapply(c(cran.pkgs, bioc.pkgs, github.pkg), package.version)

## -----------------------------------------------------------------------------
# AD data
data('AD_data') 
ad.count <- AD_data$FullData$X.count
dim(ad.count)

## -----------------------------------------------------------------------------
ad.filter.res <- PreFL(data = ad.count)
ad.filter <- ad.filter.res$data.filter
dim(ad.filter)

# zero proportion before filtering
ad.filter.res$zero.prob
# zero proportion after filtering
sum(ad.filter == 0)/(nrow(ad.filter) * ncol(ad.filter))

## -----------------------------------------------------------------------------
# Sponge data
data('sponge_data') 
sponge.tss <- sponge_data$X.tss
dim(sponge.tss)
# zero proportion
sum(sponge.tss == 0)/(nrow(sponge.tss) * ncol(sponge.tss))

## -----------------------------------------------------------------------------
ad.clr <- logratio.transfo(X = ad.filter, logratio = 'CLR', offset = 1) 

sponge.clr <- logratio.transfo(X = sponge.tss, logratio = 'CLR', offset = 0.01)

## ----ADpcaBefore, fig.align = 'center', fig.cap = 'The PCA sample plot with densities in the AD data.'----
# AD data
ad.pca.before <- pca(ad.clr, ncomp = 3, scale = TRUE)

ad.metadata <- AD_data$FullData$metadata
ad.batch = factor(ad.metadata$sequencing_run_date, 
                  levels = unique(ad.metadata$sequencing_run_date))
ad.trt = as.factor(ad.metadata$initial_phenol_concentration.regroup)
names(ad.batch) <- names(ad.trt) <- rownames(ad.metadata)

Scatter_Density(object = ad.pca.before, batch = ad.batch, trt = ad.trt, 
                title = 'AD data', trt.legend.title = 'Phenol conc.')

## ----ADboxBefore, out.width = '60%', fig.align = 'center', fig.cap = 'Boxplots of sample values in "OTU28" before batch effect correction in the AD data.'----
ad.OTU.name <- selectVar(ad.pca.before, comp = 1)$name[1]
ad.OTU_batch <- data.frame(value = ad.clr[,ad.OTU.name], batch = ad.batch)
box_plot(df = ad.OTU_batch, title = paste(ad.OTU.name, '(AD data)'), 
         x.angle = 30)

## ----ADdensityBefore, out.width = '60%', fig.align = 'center', fig.cap = 'Density plots of sample values in "OTU28" before batch effect correction in the AD data.'----
density_plot(df = ad.OTU_batch, title = paste(ad.OTU.name, '(AD data)'))

## -----------------------------------------------------------------------------
# reference batch: 14/04/2016
ad.batch <- relevel(x = ad.batch, ref = '14/04/2016')

ad.OTU.lm <- linear_regres(data = ad.clr[,ad.OTU.name], 
                           trt = ad.trt, batch.fix = ad.batch, 
                           type = 'linear model')
summary(ad.OTU.lm$model$data)

# reference batch: 21/09/2017
ad.batch <- relevel(x = ad.batch, ref = '21/09/2017')

ad.OTU.lm <- linear_regres(data = ad.clr[,ad.OTU.name], 
                           trt = ad.trt, batch.fix = ad.batch, 
                           type = 'linear model')
summary(ad.OTU.lm$model$data)

## ----ADheatmap, out.width = '90%', fig.align = 'center', fig.cap = 'Hierarchical clustering for samples in the AD data.'----
# scale the clr data on both OTUs and samples
ad.clr.s <- scale(ad.clr, center = TRUE, scale = TRUE)
ad.clr.ss <- scale(t(ad.clr.s), center = TRUE, scale = TRUE)

ad.anno_col <- data.frame(Batch = ad.batch, Treatment = ad.trt)
ad.anno_colors <- list(Batch = color.mixo(seq_len(5)), 
                      Treatment = pb_color(seq_len(2)))
names(ad.anno_colors$Batch) = levels(ad.batch)
names(ad.anno_colors$Treatment) = levels(ad.trt)

pheatmap(ad.clr.ss, 
         cluster_rows = FALSE, 
         fontsize_row = 4, 
         fontsize_col = 6,
         fontsize = 8,
         clustering_distance_rows = 'euclidean',
         clustering_method = 'ward.D',
         treeheight_row = 30,
         annotation_col = ad.anno_col,
         annotation_colors = ad.anno_colors,
         border_color = 'NA',
         main = 'AD data - Scaled')


## -----------------------------------------------------------------------------
# AD data
ad.factors.df <- data.frame(trt = ad.trt, batch = ad.batch)
ad.rda.before <- varpart(ad.clr, ~ trt, ~ batch, 
                         data = ad.factors.df, scale = TRUE)
ad.rda.before$part$indfract

## -----------------------------------------------------------------------------
# Sponge data
sponge.batch <- sponge_data$Y.bat
sponge.trt <- sponge_data$Y.trt

sponge.factors.df <- data.frame(trt = sponge.trt, batch = sponge.batch)
sponge.rda.before <- varpart(sponge.clr, ~ trt, ~ batch, 
                             data = sponge.factors.df, scale = TRUE)
sponge.rda.before$part$indfract

## -----------------------------------------------------------------------------
# HD data
data('HD_data')
hd.clr <- HD_data$EgData$X.clr
hd.trt <- HD_data$EgData$Y.trt
hd.batch <- HD_data$EgData$Y.bat

hd.factors.df <- data.frame(trt = hd.trt, batch = hd.batch)
hd.rda.before <- varpart(hd.clr, ~ trt, ~ batch, 
                         data = hd.factors.df, scale = TRUE)
hd.rda.before$part$indfract

## -----------------------------------------------------------------------------
# Creating a MRexperiment object (make sure no NA in metadata)
AD.phenotypeData = AnnotatedDataFrame(data = AD_data$FullData$metadata)
AD.taxaData = AnnotatedDataFrame(data = AD_data$FullData$taxa)
AD.obj = newMRexperiment(counts = t(AD_data$FullData$X.count), 
                         phenoData = AD.phenotypeData, 
                         featureData = AD.taxaData)
AD.obj

## -----------------------------------------------------------------------------
# filtering data to maintain a threshold of minimum depth or OTU presence
dim(MRcounts(AD.obj))
AD.obj = filterData(obj = AD.obj, present = 20, depth = 5)
dim(MRcounts(AD.obj))

## -----------------------------------------------------------------------------
# calculate the percentile for CSS normalisation
AD.pctl = cumNormStatFast(obj = AD.obj)
# CSS normalisation
AD.obj <- cumNorm(obj = AD.obj, p = AD.pctl)
# export normalised data
AD.norm.data <- MRcounts(obj = AD.obj, norm = TRUE)

# normalisation scaling factors for each sample 
AD.normFactor = normFactors(object = AD.obj)
AD.normFactor = log2(AD.normFactor/median(AD.normFactor) + 1)

## -----------------------------------------------------------------------------
# treatment variable
phenol_conc = pData(object = AD.obj)$initial_phenol_concentration.regroup
# batch variable
seq_run = pData(object = AD.obj)$sequencing_run_date

# build a design matrix
AD.mod.full = model.matrix(~ phenol_conc + seq_run + AD.normFactor)

# settings for the fitZig() function
AD.settings <- zigControl(maxit = 10, verbose = TRUE)

# apply the ZIG model
ADfit <- fitZig(obj = AD.obj, mod = AD.mod.full, 
                useCSSoffset = FALSE, control = AD.settings)


## -----------------------------------------------------------------------------
ADcoefs <- MRcoefs(ADfit, coef = 2, group = 3, number = 50, eff = 0.5)
head(ADcoefs)

## ----ADlm, fig.height = 13, fig.width = 12, out.width = '100%', fig.align = 'center', fig.cap = 'Diagnostic plots for the model fitted with batch effects of "OTU12" in the AD data.'----
# AD data
ad.clr <- ad.clr[seq_len(nrow(ad.clr)), seq_len(ncol(ad.clr))]
ad.lm <- linear_regres(data = ad.clr, trt = ad.trt, 
                       batch.fix = ad.batch, type = 'linear model')

ad.p <- sapply(ad.lm$lm.table, function(x){x$coefficients[2,4]})
ad.p.adj <- p.adjust(p = ad.p, method = 'fdr')

check_model(ad.lm$model$OTU12)

## -----------------------------------------------------------------------------
head(ad.lm$adj.R2)

## -----------------------------------------------------------------------------
head(ad.lm$AIC)

## ---- results = 'hide'--------------------------------------------------------
# HD data
hd.lmm <- linear_regres(data = hd.clr, trt = hd.trt, 
                        batch.random = hd.batch, 
                        type = 'linear mixed model')

## ----HDlmm, fig.height = 13, fig.width = 12, out.width = '100%', fig.align = 'center', fig.cap = 'Diagnostic plots for the model fitted with batch effects of "OTU1" in the HD data.'----
hd.p <- sapply(hd.lmm$lmm.table, function(x){x$coefficients[2,5]})
hd.p.adj <- p.adjust(p = hd.p, method = 'fdr')

check_model(hd.lmm$model$OTU1)

## -----------------------------------------------------------------------------
head(hd.lmm$AIC)

## -----------------------------------------------------------------------------
head(hd.lmm$cond.R2)
head(hd.lmm$marg.R2)

## -----------------------------------------------------------------------------
# estimate batch effects
ad.mod <- model.matrix( ~ ad.trt)
ad.mod0 <- model.matrix( ~ 1, data = ad.trt)
ad.sva.n <- num.sv(dat = t(ad.clr), mod = ad.mod, method = 'leek')
ad.sva <- sva(t(ad.clr), ad.mod, ad.mod0, n.sv = ad.sva.n)

## -----------------------------------------------------------------------------
# include estimated batch effects in the linear model
ad.mod.batch <- cbind(ad.mod, ad.sva$sv)
ad.mod0.batch <- cbind(ad.mod0, ad.sva$sv)
ad.sva.p <- f.pvalue(t(ad.clr), ad.mod.batch, ad.mod0.batch)
ad.sva.p.adj <- p.adjust(ad.sva.p, method = 'fdr')

## -----------------------------------------------------------------------------
# empirical negative controls
ad.empir.p <- c()
  for(e in seq_len(ncol(ad.clr))){
    ad.empir.lm <- lm(ad.clr[,e] ~ ad.trt)
    ad.empir.p[e] <- summary(ad.empir.lm)$coefficients[2,4]
  }
ad.empir.p.adj <- p.adjust(p = ad.empir.p, method = 'fdr')
ad.nc <- ad.empir.p.adj > 0.05


## -----------------------------------------------------------------------------
# estimate k
ad.k.res <- getK(Y = ad.clr, X = ad.trt, ctl = ad.nc)
ad.k <- ad.k.res$k

## -----------------------------------------------------------------------------
# RUV4
ad.ruv4 <- RUV4(Y = ad.clr, X = ad.trt, ctl = ad.nc, k = ad.k) 
ad.ruv4.p <- ad.ruv4$p
ad.ruv4.p.adj <- p.adjust(ad.ruv4.p, method = "fdr")

## -----------------------------------------------------------------------------
ad.rBE <- t(removeBatchEffect(t(ad.clr), batch = ad.batch, 
                                design = ad.mod))

## -----------------------------------------------------------------------------
ad.ComBat <- t(ComBat(t(ad.clr), batch = ad.batch, 
                      mod = ad.mod, par.prior = FALSE))


## -----------------------------------------------------------------------------
# estimate the number of treatment components
ad.trt.tune <- plsda(X = ad.clr, Y = ad.trt, ncomp = 5)
ad.trt.tune$explained_variance #1

## -----------------------------------------------------------------------------
# estimate the number of batch components
ad.batch.tune <- PLSDA_batch(X = ad.clr, 
                             Y.trt = ad.trt, Y.bat = ad.batch,
                             ncomp.trt = 1, ncomp.bat = 10)
ad.batch.tune$explained_variance.bat #4
sum(ad.batch.tune$explained_variance.bat$Y[seq_len(4)])


## -----------------------------------------------------------------------------
ad.PLSDA_batch.res <- PLSDA_batch(X = ad.clr, 
                                   Y.trt = ad.trt, Y.bat = ad.batch,
                                   ncomp.trt = 1, ncomp.bat = 4)
ad.PLSDA_batch <- ad.PLSDA_batch.res$X.nobatch

## ---- eval = F----------------------------------------------------------------
#  # estimate the number of variables to select per treatment component
#  set.seed(777)
#  ad.test.keepX = c(seq(1, 10, 1), seq(20, 100, 10),
#                    seq(150, 231, 50), 231)
#  ad.trt.tune.v <- tune.splsda(X = ad.clr, Y = ad.trt,
#                               ncomp = 1, test.keepX = ad.test.keepX,
#                               validation = 'Mfold', folds = 4,
#                               nrepeat = 50)
#  ad.trt.tune.v$choice.keepX #100
#  

## -----------------------------------------------------------------------------
# estimate the number of batch components
ad.batch.tune <- PLSDA_batch(X = ad.clr, 
                             Y.trt = ad.trt, Y.bat = ad.batch,
                             ncomp.trt = 1, keepX.trt = 100,
                             ncomp.bat = 10)
ad.batch.tune$explained_variance.bat #4
sum(ad.batch.tune$explained_variance.bat$Y[seq_len(4)])

## -----------------------------------------------------------------------------
ad.sPLSDA_batch.res <- PLSDA_batch(X = ad.clr, 
                                   Y.trt = ad.trt, Y.bat = ad.batch,
                                   ncomp.trt = 1, keepX.trt = 100,
                                   ncomp.bat = 4)
ad.sPLSDA_batch <- ad.sPLSDA_batch.res$X.nobatch

## -----------------------------------------------------------------------------
ad.PN <- percentile_norm(data = ad.clr, batch = ad.batch, 
                         trt = ad.trt, ctrl.grp = '0-0.5')

## -----------------------------------------------------------------------------
ad.replicates <- ad.metadata$sample_name.data.extraction
ad.replicates.matrix <- replicate.matrix(ad.replicates)

ad.RUVIII <- RUVIII(Y = ad.clr, M = ad.replicates.matrix, 
                    ctl = ad.nc, k = ad.k)
rownames(ad.RUVIII) <- rownames(ad.clr)

## -----------------------------------------------------------------------------
ad.pca.before <- pca(ad.clr, ncomp = 3, scale = TRUE)
ad.pca.rBE <- pca(ad.rBE, ncomp = 3, scale = TRUE)
ad.pca.ComBat <- pca(ad.ComBat, ncomp = 3, scale = TRUE)
ad.pca.PLSDA_batch <- pca(ad.PLSDA_batch, ncomp = 3, scale = TRUE)
ad.pca.sPLSDA_batch <- pca(ad.sPLSDA_batch, ncomp = 3, scale = TRUE)
ad.pca.PN <- pca(ad.PN, ncomp = 3, scale = TRUE)
ad.pca.RUVIII <- pca(ad.RUVIII, ncomp = 3, scale = TRUE)

## ---- fig.show='hide'---------------------------------------------------------
# order batches
ad.batch = factor(ad.metadata$sequencing_run_date, 
                  levels = unique(ad.metadata$sequencing_run_date))

ad.pca.before.plot <- Scatter_Density(object = ad.pca.before, 
                                      batch = ad.batch, 
                                      trt = ad.trt, 
                                      title = 'Before')
ad.pca.rBE.plot <- Scatter_Density(object = ad.pca.rBE, 
                                   batch = ad.batch, 
                                   trt = ad.trt, 
                                   title = 'removeBatchEffect')
ad.pca.ComBat.plot <- Scatter_Density(object = ad.pca.ComBat, 
                                      batch = ad.batch, 
                                      trt = ad.trt, 
                                      title = 'ComBat')
ad.pca.PLSDA_batch.plot <- Scatter_Density(object = ad.pca.PLSDA_batch, 
                                           batch = ad.batch, 
                                           trt = ad.trt, 
                                           title = 'PLSDA-batch')
ad.pca.sPLSDA_batch.plot <- Scatter_Density(object = ad.pca.sPLSDA_batch, 
                                            batch = ad.batch, 
                                            trt = ad.trt, 
                                            title = 'sPLSDA-batch')
ad.pca.PN.plot <- Scatter_Density(object = ad.pca.PN, 
                                  batch = ad.batch, 
                                  trt = ad.trt, 
                                  title = 'Percentile Normalisation')
ad.pca.RUVIII.plot <- Scatter_Density(object = ad.pca.RUVIII, 
                                      batch = ad.batch, 
                                      trt = ad.trt, 
                                      title = 'RUVIII')


## ----ADpca, fig.height = 17, fig.width = 12, out.width = '100%', echo = FALSE, fig.align = 'center', fig.cap = 'The PCA sample plots with densities before and after batch effect correction in the AD data.'----
grid.arrange(ad.pca.before.plot, ad.pca.rBE.plot, 
             ad.pca.ComBat.plot, ad.pca.PLSDA_batch.plot, 
             ad.pca.sPLSDA_batch.plot, ad.pca.PN.plot, 
             ad.pca.RUVIII.plot, ncol = 2)

## ----ADprda, fig.height = 6, fig.align = 'center', fig.cap = 'Global explained variance before and after batch effect correction for the AD data.'----
# AD data
ad.corrected.list <- list(Before = ad.clr, 
                          removeBatchEffect = ad.rBE, 
                          ComBat = ad.ComBat, 
                          `PLSDA-batch` = ad.PLSDA_batch, 
                          `sPLSDA-batch` = ad.sPLSDA_batch, 
                          `Percentile Normalisation` = ad.PN,
                          RUVIII = ad.RUVIII)

ad.prop.df <- data.frame(Treatment = NA, Intersection = NA, 
                         Batch = NA, Residuals = NA) 
for(i in seq_len(length(ad.corrected.list))){
  rda.res = varpart(ad.corrected.list[[i]], ~ trt, ~ batch,
                    data = ad.factors.df, scale = TRUE)
  ad.prop.df[i, ] <- rda.res$part$indfract$Adj.R.squared}

rownames(ad.prop.df) = names(ad.corrected.list)

ad.prop.df[ad.prop.df < 0] = 0
ad.prop.df <- as.data.frame(t(apply(ad.prop.df, 1, 
                                    function(x){x/sum(x)})))

partVar_plot(prop.df = ad.prop.df)

## ----HFHSprda, fig.height = 6, fig.align = 'center', fig.cap = 'Global explained variance before and after batch effect correction for the HFHS data.'----
# HFHS data
data('HFHS_data')
hfhs.corrected.list <- HFHS_data$CorrectData$data

hfhs.trt <- HFHS_data$CorrectData$Y.trt
hfhs.batch <- HFHS_data$CorrectData$Y.bat
hfhs.factors.df <- data.frame(trt = hfhs.trt, batch = hfhs.batch)

hfhs.prop.df <- data.frame(Treatment = NA, Intersection = NA, 
                           Batch = NA, Residuals = NA) 
for(i in seq_len(length(hfhs.corrected.list))){
  rda.res = varpart(hfhs.corrected.list[[i]], ~ trt, ~ batch,
                    data = hfhs.factors.df, scale = TRUE)
  hfhs.prop.df[i, ] <- rda.res$part$indfract$Adj.R.squared}

rownames(hfhs.prop.df) = names(hfhs.corrected.list)

hfhs.prop.df[hfhs.prop.df < 0] = 0
hfhs.prop.df <- as.data.frame(t(apply(hfhs.prop.df, 1, 
                                      function(x){x/sum(x)})))


partVar_plot(prop.df = hfhs.prop.df)

## ----ADr2, fig.height = 8, fig.width = 7, out.width = '100%', fig.align = 'center', fig.cap = '$R^2$ values for each microbial variable before and after batch effect correction in the AD data.'----
# AD data
# scale
ad.corr_scale.list <- lapply(ad.corrected.list, 
                             function(x){apply(x, 2, scale)})

ad.r_values.list <- list()
for(i in seq_len(length(ad.corr_scale.list))){
  ad.r_values <- data.frame(trt = NA, batch = NA)
  for(c in seq_len(ncol(ad.corr_scale.list[[i]]))){
    ad.fit.res.trt <- lm(ad.corr_scale.list[[i]][,c] ~ ad.trt)
    ad.r_values[c,1] <- summary(ad.fit.res.trt)$r.squared
    ad.fit.res.batch <- lm(ad.corr_scale.list[[i]][,c] ~ ad.batch)
    ad.r_values[c,2] <- summary(ad.fit.res.batch)$r.squared
  }
  ad.r_values.list[[i]] <- ad.r_values
}
names(ad.r_values.list) <- names(ad.corr_scale.list)

# plot
xlabs = 'R2(variable, treatment)'
ylabs = 'R2(variable, batch)'
edgex = 0.75
edgey = 1

symbol_vector <- c(expression('bad'), expression('good'), 
                   expression('bad'), expression('good'), 
                   expression('good'), expression('bad'), 
                   expression('bad'))
symbol_color <- c('red', 'dark green', 'red', 'dark green', 
                  'dark green', 'red', 'red')
par(mfrow = c(4,2))
for(i in seq_len(length(ad.r_values.list))){
  plot(ad.r_values.list[[i]]$trt, ad.r_values.list[[i]]$batch, 
     main = names(ad.r_values.list)[i], xlab = xlabs, ylab = ylabs,
     xlim = c(0, edgex), ylim = c(0, edgey))
  legend('topright', legend = symbol_vector[i], 
         text.col = symbol_color[i], cex = 1.5, bty = 'n')
}
par(mfrow = c(1,1))

# the sum of all variables
lapply(ad.r_values.list, colSums)[c(2,4,5)]

## ----ADalignment, fig.align = 'center', fig.cap = 'Comparison of alignment scores before and after batch effect correction using different methods for the AD data.'----
# AD data
ad.scores <- c()
names(ad.batch) <- rownames(ad.clr)
for(i in seq_len(length(ad.corrected.list))){
  res <- alignment_score(data = ad.corrected.list[[i]], 
                         batch = ad.batch, 
                         var = 0.95, 
                         k = 8, 
                         ncomp = 50)
  ad.scores <- c(ad.scores, res)
}

ad.scores.df <- data.frame(scores = ad.scores, 
                           methods = names(ad.corrected.list))

ad.scores.df$methods <- factor(ad.scores.df$methods, 
                               levels = rev(names(ad.corrected.list)))


ggplot() + geom_col(aes(x = ad.scores.df$methods, 
                        y = ad.scores.df$scores)) + 
  geom_text(aes(x = ad.scores.df$methods, 
                y = ad.scores.df$scores/2, 
                label = round(ad.scores.df$scores, 3)), 
            size = 3, col = 'white') + 
  coord_flip() + theme_bw() + ylab('Alignment Scores') + 
  xlab('') + ylim(0,0.85)

## ----ADupsetR, out.width = '100%', fig.align = 'center', fig.cap = 'UpSet plot showing overlap between variables selected from different corrected data for the AD study.'----
ad.splsda.select <- list()
for(i in seq_len(length(ad.corrected.list))){
  splsda.res <- splsda(X = ad.corrected.list[[i]], Y = ad.trt, 
                       ncomp = 3, keepX = rep(50,3))
  select.res <- selectVar(splsda.res, comp = 1)$name
  ad.splsda.select[[i]] <- select.res
}
names(ad.splsda.select) <- names(ad.corrected.list)

# can only visualise 5 methods
ad.splsda.select <- ad.splsda.select[seq_len(5)]

ad.splsda.upsetR <- fromList(ad.splsda.select)

upset(ad.splsda.upsetR, main.bar.color = 'gray36',
      sets.bar.color = pb_color(c(25:22,20)), matrix.color = 'gray36',
      order.by = 'freq', empty.intersections = 'on',
      queries = list(list(query = intersects, 
                          params = list('Before'), 
                          color = pb_color(20), active = TRUE),
                     list(query = intersects, 
                          params = list('removeBatchEffect'), 
                          color = pb_color(22), active = TRUE),
                     list(query = intersects, 
                          params = list('ComBat'), 
                          color = pb_color(23), active = TRUE),
                     list(query = intersects, 
                          params = list('PLSDA-batch'), 
                          color = pb_color(24), active = TRUE),
                     list(query = intersects, 
                          params = list('sPLSDA-batch'), 
                          color = pb_color(25), active = TRUE)))


## -----------------------------------------------------------------------------
ad.splsda.select.overlap <- venn(ad.splsda.select, show.plot = FALSE)
ad.inters.splsda <- attr(ad.splsda.select.overlap, 'intersections')
ad.inters.splsda.taxa <- lapply(ad.inters.splsda, 
                         FUN = function(x){as.data.frame(AD_data$FullData$taxa[x, ])})
capture.output(ad.inters.splsda.taxa, 
               file = "GeneratedData/ADselected_50_splsda.txt")

