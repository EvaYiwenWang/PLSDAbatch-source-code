# Version: 0.99.0
* Date: 2023-04-03
* Text: The first release on Bioconductor
* Details: This version is equal to the version 0.2.3 on GitHub (https://github.com/EvaYiwenWang/PLSDAbatch)
